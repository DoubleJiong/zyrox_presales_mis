'use client';

import ReactECharts from 'echarts-for-react';
import { techTheme } from '@/lib/tech-theme';
import { Award, Users, Target, Zap, FolderKanban, FileText } from 'lucide-react';
import type { 
  SalesPanelData, 
  CustomersPanelData, 
  ProjectsPanelData, 
  SolutionsPanelData 
} from '@/hooks/use-panel-data';
import type { MapRegionData } from '@/lib/map-types';

// ==================== 售前数据面板 ====================
interface SalesPanelProps {
  data: SalesPanelData | null;
}

export function SalesPanel({ data }: SalesPanelProps) {
  if (!data) {
    return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>加载中...</div>;
  }

  // 月度之星
  const renderTopPerformers = () => {
    const performers = data.topPerformers || [];
    if (performers.length === 0) {
      return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>暂无数据</div>;
    }

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '12px',
        }}>
          <Award size={16} style={{ color: techTheme.colors.primary }} />
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>月度之星</span>
        </div>
        {performers.map((p, i) => (
          <div key={p.id} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px',
            marginBottom: '8px',
            background: i === 0 ? 'rgba(255, 215, 0, 0.1)' : i === 1 ? 'rgba(192, 192, 192, 0.1)' : i === 2 ? 'rgba(205, 127, 50, 0.1)' : 'transparent',
            borderRadius: '6px',
            border: i === 0 ? '1px solid rgba(255, 215, 0, 0.3)' : i === 1 ? '1px solid rgba(192, 192, 192, 0.3)' : i === 2 ? '1px solid rgba(205, 127, 50, 0.3)' : '1px solid transparent',
          }}>
            <div style={{
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              background: i === 0 ? 'linear-gradient(135deg, #FFD700, #FFA500)' : i === 1 ? 'linear-gradient(135deg, #C0C0C0, #A0A0A0)' : i === 2 ? 'linear-gradient(135deg, #CD7F32, #8B4513)' : techTheme.colors.primary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#000',
              fontSize: '12px',
              fontWeight: 'bold',
            }}>
              {p.rank}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ color: techTheme.text.primary, fontSize: '13px', fontWeight: '500' }}>{p.name}</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{p.region}</div>
            </div>
            <div style={{ textAlign: 'right', minWidth: '60px' }}>
              <div style={{ color: i === 0 ? '#FFD700' : techTheme.colors.primary, fontSize: '14px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.score}</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{p.activities}个项目</div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  // 工作饱和度
  const renderWorkSaturation = () => {
    const saturation = data.workSaturation || [];
    
    const option = {
      grid: {
        top: 10,
        right: 20,
        bottom: 20,
        left: 60,
      },
      xAxis: {
        type: 'value',
        max: 100,
        axisLine: { show: false },
        axisLabel: { color: techTheme.text.secondary, fontSize: 10 },
        splitLine: { lineStyle: { color: 'rgba(0, 212, 255, 0.1)' } },
      },
      yAxis: {
        type: 'category',
        data: saturation.map(s => s.name).reverse(),
        axisLine: { show: false },
        axisLabel: { color: techTheme.text.secondary, fontSize: 10 },
      },
      series: [{
        type: 'bar',
        data: saturation.map(s => ({
          value: s.value,
          itemStyle: {
            color: {
              type: 'linear',
              x: 0, y: 0, x2: 1, y2: 0,
              colorStops: [
                { offset: 0, color: s.value > 80 ? '#FF6B6B' : s.value > 50 ? '#FFA500' : techTheme.colors.primary },
                { offset: 1, color: s.value > 80 ? '#FF8E8E' : s.value > 50 ? '#FFB732' : techTheme.colors.secondary },
              ],
            },
            borderRadius: [0, 4, 4, 0],
          },
        })).reverse(),
        barWidth: 12,
        label: {
          show: true,
          position: 'right',
          color: techTheme.text.secondary,
          fontSize: 10,
          formatter: '{c}%',
        },
      }],
    };

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '8px',
        }}>
          <Zap size={16} style={{ color: techTheme.colors.warning }} />
          <span style={{ color: techTheme.colors.warning, fontSize: '12px', fontWeight: '600' }}>工作饱和度</span>
        </div>
        <ReactECharts option={option} style={{ height: '150px' }} />
      </div>
    );
  };

  // 商机转化漏斗
  const renderConversionFunnel = () => {
    const stages = data.opportunityStages || [];
    const stageLabels: Record<string, string> = {
      prospecting: '挖掘中',
      qualified: '已验证',
      proposal: '方案阶段',
      negotiation: '谈判中',
      won: '赢单',
      lost: '输单',
    };
    
    const funnelData = stages
      .filter(s => s.stage && s.stage !== 'lost')
      .map(s => ({
        name: stageLabels[s.stage] || s.stage,
        value: s.count,
      }));

    const option = {
      series: [{
        type: 'funnel',
        data: funnelData,
        width: '70%',
        gap: 2,
        label: {
          show: true,
          position: 'inside',
          color: '#fff',
          fontSize: 10,
        },
        itemStyle: {
          borderWidth: 0,
        },
        emphasis: {
          label: {
            fontSize: 12,
          },
        },
      }],
      color: [techTheme.colors.primary, techTheme.colors.secondary, techTheme.colors.success, techTheme.colors.warning],
    };

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '8px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Target size={16} style={{ color: techTheme.colors.success }} />
            <span style={{ color: techTheme.colors.success, fontSize: '12px', fontWeight: '600' }}>商机转化</span>
          </div>
          <div style={{
            padding: '2px 8px',
            background: 'rgba(0, 255, 136, 0.2)',
            borderRadius: '4px',
            color: techTheme.colors.success,
            fontSize: '11px',
          }}>
            转化率: {data.conversionRate || 0}%
          </div>
        </div>
        <ReactECharts option={option} style={{ height: '120px' }} />
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {renderTopPerformers()}
      {renderWorkSaturation()}
      {renderConversionFunnel()}
    </div>
  );
}

// ==================== 客户数据面板 ====================
interface CustomersPanelProps {
  data: CustomersPanelData | null;
}

export function CustomersPanel({ data }: CustomersPanelProps) {
  if (!data) {
    return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>加载中...</div>;
  }

  // 重点客户
  const renderTopCustomers = () => {
    const customers = data.topCustomers || [];
    if (customers.length === 0) {
      return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>暂无数据</div>;
    }

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '12px',
        }}>
          <Users size={16} style={{ color: techTheme.colors.primary }} />
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>重点客户</span>
        </div>
        {customers.slice(0, 5).map((c, i) => (
          <div key={c.id} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px',
            marginBottom: '4px',
            borderBottom: i < 4 ? '1px solid rgba(0, 212, 255, 0.1)' : 'none',
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ color: techTheme.text.primary, fontSize: '12px' }}>{c.name}</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{c.region || '未分配区域'}</div>
            </div>
            <div style={{ textAlign: 'right', minWidth: '60px' }}>
              <div style={{ color: techTheme.colors.primary, fontSize: '12px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>¥{(c.amount / 10000).toFixed(0)}万</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{c.projectCount}个项目</div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  // 区域分布饼图
  const renderRegionPie = () => {
    const regions = data.regionDistribution || [];
    
    const option = {
      tooltip: {
        trigger: 'item',
        formatter: '{b}: {c}个 ({d}%)',
      },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['50%', '50%'],
        data: regions.slice(0, 6).map(r => ({
          name: r.name || '未知',
          value: r.value,
        })),
        label: {
          show: true,
          color: techTheme.text.secondary,
          fontSize: 10,
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 12,
            fontWeight: 'bold',
          },
        },
      }],
      color: [techTheme.colors.primary, techTheme.colors.secondary, techTheme.colors.success, techTheme.colors.warning, techTheme.colors.danger, '#9B59B6'],
    };

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '8px',
        }}>
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>区域分布</span>
        </div>
        <ReactECharts option={option} style={{ height: '150px' }} />
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {renderTopCustomers()}
      {renderRegionPie()}
    </div>
  );
}

// ==================== 项目数据面板 ====================
interface ProjectsPanelProps {
  data: ProjectsPanelData | null;
}

export function ProjectsPanel({ data }: ProjectsPanelProps) {
  if (!data) {
    return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>加载中...</div>;
  }

  const stageLabels: Record<string, string> = {
    opportunity: '商机',
    bidding: '投标',
    execution: '执行',
    settlement: '结算',
    archived: '归档',
  };

  // 最近项目
  const renderRecentProjects = () => {
    const projects = data.recentProjects || [];
    if (projects.length === 0) {
      return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>暂无数据</div>;
    }

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '12px',
        }}>
          <FolderKanban size={16} style={{ color: techTheme.colors.primary }} />
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>最近项目</span>
        </div>
        {projects.slice(0, 5).map((p, i) => (
          <div key={p.id} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px',
            marginBottom: '4px',
            borderBottom: i < 4 ? '1px solid rgba(0, 212, 255, 0.1)' : 'none',
          }}>
            <div style={{
              padding: '2px 6px',
              background: p.stage === 'execution' ? 'rgba(0, 255, 136, 0.2)' : 'rgba(0, 212, 255, 0.2)',
              borderRadius: '4px',
              color: p.stage === 'execution' ? techTheme.colors.success : techTheme.colors.primary,
              fontSize: '9px',
            }}>
              {stageLabels[p.stage] || p.stage}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ color: techTheme.text.primary, fontSize: '12px' }}>{p.name}</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{p.customerName}</div>
            </div>
            <div style={{ color: techTheme.colors.primary, fontSize: '12px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '80px' }}>¥{(p.amount / 10000).toFixed(0)}万</div>
          </div>
        ))}
      </div>
    );
  };

  // 阶段分布
  const renderStageDistribution = () => {
    const stages = data.stageDistribution || [];
    
    const option = {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
      },
      grid: {
        top: 10,
        right: 20,
        bottom: 30,
        left: 40,
      },
      xAxis: {
        type: 'category',
        data: stages.map(s => stageLabels[s.stage] || s.stage),
        axisLine: { lineStyle: { color: 'rgba(0, 212, 255, 0.3)' } },
        axisLabel: { color: techTheme.text.secondary, fontSize: 10 },
      },
      yAxis: {
        type: 'value',
        axisLine: { show: false },
        axisLabel: { color: techTheme.text.secondary, fontSize: 10 },
        splitLine: { lineStyle: { color: 'rgba(0, 212, 255, 0.1)' } },
      },
      series: [{
        type: 'bar',
        data: stages.map(s => s.count),
        itemStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: techTheme.colors.primary },
              { offset: 1, color: techTheme.colors.secondary },
            ],
          },
          borderRadius: [4, 4, 0, 0],
        },
        barWidth: 20,
      }],
    };

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '8px',
        }}>
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>阶段分布</span>
        </div>
        <ReactECharts option={option} style={{ height: '150px' }} />
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {renderRecentProjects()}
      {renderStageDistribution()}
    </div>
  );
}

// ==================== 解决方案数据面板 ====================
interface SolutionsPanelProps {
  data: SolutionsPanelData | null;
}

export function SolutionsPanel({ data }: SolutionsPanelProps) {
  if (!data) {
    return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>加载中...</div>;
  }

  // 热门方案
  const renderTopSolutions = () => {
    const solutions = data.topSolutions || [];
    if (solutions.length === 0) {
      return <div style={{ color: techTheme.text.secondary, textAlign: 'center', padding: '20px' }}>暂无数据</div>;
    }

    return (
      <div style={{
        background: 'rgba(0, 212, 255, 0.05)',
        border: '1px solid rgba(0, 212, 255, 0.2)',
        borderRadius: '8px',
        padding: '12px',
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          marginBottom: '12px',
        }}>
          <FileText size={16} style={{ color: techTheme.colors.primary }} />
          <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>热门方案</span>
        </div>
        {solutions.slice(0, 5).map((s, i) => (
          <div key={s.id} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px',
            marginBottom: '4px',
            borderBottom: i < 4 ? '1px solid rgba(0, 212, 255, 0.1)' : 'none',
          }}>
            <div style={{
              width: '20px',
              height: '20px',
              borderRadius: '4px',
              background: i === 0 ? 'linear-gradient(135deg, #FFD700, #FFA500)' : 'rgba(0, 212, 255, 0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: i === 0 ? '#000' : techTheme.colors.primary,
              fontSize: '10px',
              fontWeight: 'bold',
            }}>
              {s.rank}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ color: techTheme.text.primary, fontSize: '12px' }}>{s.name}</div>
              <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>{s.type}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ color: techTheme.colors.primary, fontSize: '12px' }}>{s.viewCount}次浏览</div>
              <div style={{ color: techTheme.colors.success, fontSize: '10px' }}>{s.status}</div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {renderTopSolutions()}
    </div>
  );
}

// ==================== 区域详情面板 ====================
interface RegionDetailPanelProps {
  regionData: MapRegionData;
  onClose: () => void;
}

export function RegionDetailPanel({ regionData, onClose }: RegionDetailPanelProps) {
  return (
    <div style={{
      position: 'absolute',
      top: '20px',
      right: '20px',
      width: '300px',
      background: 'rgba(10, 15, 26, 0.95)',
      border: '1px solid rgba(0, 212, 255, 0.3)',
      borderRadius: '8px',
      padding: '16px',
      zIndex: 100,
      animation: 'slideInRight 0.3s ease-out',
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '16px',
      }}>
        <h3 style={{ color: techTheme.colors.primary, fontSize: '14px', margin: 0 }}>{regionData.name}</h3>
        <button
          onClick={onClose}
          style={{
            background: 'transparent',
            border: 'none',
            color: techTheme.text.secondary,
            cursor: 'pointer',
          }}
        >
          ✕
        </button>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <div style={{
          padding: '12px',
          background: 'rgba(0, 212, 255, 0.1)',
          borderRadius: '6px',
        }}>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px', marginBottom: '4px' }}>客户数量</div>
          <div style={{ color: techTheme.colors.primary, fontSize: '18px', fontWeight: '600' }}>{regionData.customerCount || 0}</div>
        </div>
        <div style={{
          padding: '12px',
          background: 'rgba(0, 255, 136, 0.1)',
          borderRadius: '6px',
        }}>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px', marginBottom: '4px' }}>项目数量</div>
          <div style={{ color: techTheme.colors.success, fontSize: '18px', fontWeight: '600' }}>{regionData.projectCount || 0}</div>
        </div>
        <div style={{
          padding: '12px',
          background: 'rgba(255, 165, 0, 0.1)',
          borderRadius: '6px',
        }}>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px', marginBottom: '4px' }}>项目金额</div>
          <div style={{ color: techTheme.colors.warning, fontSize: '18px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>¥{((regionData.projectAmount || 0) / 10000).toFixed(0)}万</div>
        </div>
        <div style={{
          padding: '12px',
          background: 'rgba(255, 107, 107, 0.1)',
          borderRadius: '6px',
        }}>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px', marginBottom: '4px' }}>中标金额</div>
          <div style={{ color: techTheme.colors.danger, fontSize: '18px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>¥{((regionData.contractAmount || 0) / 10000).toFixed(0)}万</div>
        </div>
      </div>
    </div>
  );
}

// ==================== 实时数据面板 ====================
export function RealTimeDataPanel() {
  return (
    <div style={{
      background: 'rgba(0, 212, 255, 0.05)',
      border: '1px solid rgba(0, 212, 255, 0.2)',
      borderRadius: '8px',
      padding: '12px',
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        marginBottom: '12px',
      }}>
        <span style={{ color: techTheme.colors.success, fontSize: '12px', fontWeight: '600' }}>实时动态</span>
        <div style={{
          width: '6px',
          height: '6px',
          borderRadius: '50%',
          background: techTheme.colors.success,
          animation: 'pulse 2s infinite',
        }} />
      </div>
      <div style={{ color: techTheme.text.secondary, fontSize: '11px', textAlign: 'center', padding: '20px' }}>
        暂无实时数据
      </div>
    </div>
  );
}

// ==================== 快速统计面板 ====================
interface QuickStatsPanelProps {
  data: MapRegionData[];
}

export function QuickStatsPanel({ data }: QuickStatsPanelProps) {
  const totalCustomers = data.reduce((sum, d) => sum + (d.customerCount || 0), 0);
  const totalProjects = data.reduce((sum, d) => sum + (d.projectCount || 0), 0);
  const totalAmount = data.reduce((sum, d) => sum + (d.projectAmount || 0), 0);

  return (
    <div style={{
      background: 'rgba(0, 212, 255, 0.05)',
      border: '1px solid rgba(0, 212, 255, 0.2)',
      borderRadius: '8px',
      padding: '12px',
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        marginBottom: '12px',
      }}>
        <span style={{ color: techTheme.colors.primary, fontSize: '12px', fontWeight: '600' }}>快速统计</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: techTheme.colors.primary, fontSize: '16px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{totalCustomers}</div>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>客户</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: techTheme.colors.success, fontSize: '16px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{totalProjects}</div>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>项目</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ color: techTheme.colors.warning, fontSize: '16px', fontWeight: '600', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>¥{(totalAmount / 10000).toFixed(0)}万</div>
          <div style={{ color: techTheme.text.secondary, fontSize: '10px' }}>金额</div>
        </div>
      </div>
    </div>
  );
}
