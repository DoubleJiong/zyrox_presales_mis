import { hashPassword } from '../lib/auth';
import { db } from '../db/index';
import { users } from '../db/schema';
import { eq } from 'drizzle-orm';

async function updatePasswords() {
  // 更新所有用户的密码为 'password123'
  const password = 'password123';
  const passwordHash = await hashPassword(password);

  const allUsers = await db.select().from(users);

  for (const user of allUsers) {
    await db
      .update(users)
      .set({ passwordHash })
      .where(eq(users.id, user.id));
    console.log(`Updated password for user: ${user.email}`);
  }

  console.log('All passwords updated successfully!');
  process.exit(0);
}

updatePasswords().catch((error) => {
  console.error('Error updating passwords:', error);
  process.exit(1);
});
