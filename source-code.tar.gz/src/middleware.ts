import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Token 黑名单缓存（内存缓存，定期清理）
const tokenBlacklistCache = new Set<string>();
let lastCacheCleanup = Date.now();
const CACHE_CLEANUP_INTERVAL = 5 * 60 * 1000; // 5 分钟

/**
 * 使用 Web Crypto API 计算 SHA256 哈希（Edge Runtime 兼容）
 */
async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * 检查 Token 是否在黑名单中（通过 API 调用）
 * 注意：由于 Edge Runtime 限制，这里使用 fetch 调用内部 API
 */
async function isTokenBlacklisted(token: string, request: NextRequest): Promise<boolean> {
  try {
    // 使用 Web Crypto API 计算 Token 哈希
    const tokenHash = await sha256(token);

    // 检查内存缓存
    if (tokenBlacklistCache.has(tokenHash)) {
      return true;
    }

    // 调用内部 API 检查黑名单 - 使用 request.nextUrl.origin 获取正确的 origin
    const apiUrl = new URL('/api/auth/check-blacklist', request.nextUrl.origin);
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ tokenHash }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.blacklisted) {
        // 加入内存缓存
        tokenBlacklistCache.add(tokenHash);
        return true;
      }
    }

    return false;
  } catch (error) {
    console.error('Error checking token blacklist:', error);
    // 出错时不阻止请求，让后续验证处理
    return false;
  }
}

/**
 * 清理过期的缓存
 */
function cleanupCache() {
  const now = Date.now();
  if (now - lastCacheCleanup > CACHE_CLEANUP_INTERVAL) {
    tokenBlacklistCache.clear();
    lastCacheCleanup = now;
  }
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // 清理缓存
  cleanupCache();

  // 公共路径，无需认证
  const publicPaths = [
    '/login',
    '/register',
    '/api/auth/login',
    '/api/auth/register',
    '/api/auth/refresh',
    '/api/auth/check-blacklist',
    '/api/db/seed',
    '/api/events',  // SSE 端点自行处理认证，返回 SSE 格式的错误
    '/api/test/setup-user',  // 测试用户设置（仅限测试环境）
  ];

  // 静态资源和公共路径直接放行
  if (
    publicPaths.some(path => pathname.startsWith(path)) ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/favicon') ||
    pathname.includes('.') // 静态文件
  ) {
    return NextResponse.next();
  }

  // 从 Cookie 中获取 token
  let token = request.cookies.get('token')?.value;

  // 如果 Cookie 中没有，尝试从 Authorization header 获取
  if (!token) {
    const authHeader = request.headers.get('authorization');
    if (authHeader?.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    }
  }

  // 如果没有 token
  if (!token) {
    // API 请求返回 401 JSON 错误，不重定向
    if (pathname.startsWith('/api/')) {
      return NextResponse.json(
        { success: false, error: '请先登录', code: 'UNAUTHORIZED' },
        { status: 401 }
      );
    }

    // 页面请求重定向到登录页
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // 检查 Token 是否在黑名单中
  const isBlacklisted = await isTokenBlacklisted(token, request);
  if (isBlacklisted) {
    // API 请求返回 401
    if (pathname.startsWith('/api/')) {
      return NextResponse.json(
        { success: false, error: '登录已失效，请重新登录', code: 'TOKEN_REVOKED' },
        { status: 401 }
      );
    }

    // 页面请求重定向到登录页
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('error', 'token_revoked');
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
