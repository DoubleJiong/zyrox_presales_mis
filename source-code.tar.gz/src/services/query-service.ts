/**
 * 优化查询服务
 * 提供常用数据的优化查询方法
 * 
 * 注意：此文件提供查询优化工具和方法示例
 * 具体实现需要根据实际schema调整
 */

import { db } from '@/db';
import { sql, eq, and, or, desc, asc, inArray, gte, lte, like, between } from 'drizzle-orm';
import { users, customers, projects, leads, leadFollowRecords, roles } from '@/db/schema';

// =====================================================
// 类型定义
// =====================================================

interface PaginationOptions {
  page?: number;
  pageSize?: number;
}

interface UserQueryOptions extends PaginationOptions {
  department?: string;
  status?: string;
  roleId?: number;
}

interface CustomerQueryOptions extends PaginationOptions {
  region?: string;
  status?: string;
  customerTypeId?: number;
  search?: string;
}

interface ProjectQueryOptions extends PaginationOptions {
  customerId?: number;
  status?: string;
  stage?: string;
  search?: string;
  minAmount?: number;
  maxAmount?: number;
}

// =====================================================
// 用户查询优化
// =====================================================

export async function getUsersWithStats(options: UserQueryOptions = {}) {
  const { department, status, roleId, page = 1, pageSize = 10 } = options;
  const offset = (page - 1) * pageSize;

  const conditions = [];
  if (department) conditions.push(eq(users.department, department));
  if (status) conditions.push(eq(users.status, status));
  if (roleId) conditions.push(eq(users.roleId, roleId));

  // 使用子查询统计项目数
  const result = await db
    .select({
      id: users.id,
      realName: users.realName,
      username: users.username,
      email: users.email,
      status: users.status,
      department: users.department,
      createdAt: users.createdAt,
      // 子查询计算项目数（需要根据实际项目表结构调整）
      projectCount: sql<number>`0`.as('projectCount'),
    })
    .from(users)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .limit(pageSize)
    .offset(offset)
    .orderBy(desc(users.createdAt));

  // 获取总数
  const countResult = await db
    .select({ count: sql<number>`count(*)` })
    .from(users)
    .where(conditions.length > 0 ? and(...conditions) : undefined);

  return { data: result, total: countResult[0]?.count || 0 };
}

// =====================================================
// 客户查询优化
// =====================================================

export async function getCustomersWithProjects(options: CustomerQueryOptions = {}) {
  const { region, status, customerTypeId, search, page = 1, pageSize = 10 } = options;
  const offset = (page - 1) * pageSize;

  const conditions = [];
  if (region) conditions.push(eq(customers.region, region));
  if (status) conditions.push(eq(customers.status, status));
  if (customerTypeId) conditions.push(eq(customers.customerTypeId, customerTypeId));
  if (search) {
    conditions.push(
      or(
        like(customers.customerName, `%${search}%`),
        like(customers.contactName, `%${search}%`)
      )
    );
  }

  const result = await db
    .select({
      id: customers.id,
      customerId: customers.customerId,
      customerName: customers.customerName,
      status: customers.status,
      region: customers.region,
      contactName: customers.contactName,
      contactPhone: customers.contactPhone,
      totalAmount: customers.totalAmount,
      currentProjectCount: customers.currentProjectCount,
      createdAt: customers.createdAt,
    })
    .from(customers)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .limit(pageSize)
    .offset(offset)
    .orderBy(desc(customers.createdAt));

  const countResult = await db
    .select({ count: sql<number>`count(*)` })
    .from(customers)
    .where(conditions.length > 0 ? and(...conditions) : undefined);

  return { data: result, total: countResult[0]?.count || 0 };
}

// =====================================================
// 项目查询优化
// =====================================================

export async function getProjectsDetailed(options: ProjectQueryOptions = {}) {
  const {
    customerId,
    status,
    stage,
    search,
    minAmount,
    maxAmount,
    page = 1,
    pageSize = 10,
  } = options;
  const offset = (page - 1) * pageSize;

  const conditions = [];
  if (customerId) conditions.push(eq(projects.customerId, customerId));
  if (status) conditions.push(eq(projects.status, status));
  if (stage) conditions.push(eq(projects.projectStage, stage));
  if (search) conditions.push(like(projects.projectName, `%${search}%`));
  if (minAmount !== undefined && maxAmount !== undefined) {
    conditions.push(between(projects.estimatedAmount, minAmount.toString(), maxAmount.toString()));
  }

  // 使用JOIN减少查询次数
  const result = await db
    .select({
      id: projects.id,
      projectCode: projects.projectCode,
      projectName: projects.projectName,
      status: projects.status,
      projectStage: projects.projectStage,
      estimatedAmount: projects.estimatedAmount,
      customerId: projects.customerId,
      createdAt: projects.createdAt,
      customerName: customers.customerName,
    })
    .from(projects)
    .leftJoin(customers, eq(projects.customerId, customers.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .limit(pageSize)
    .offset(offset)
    .orderBy(desc(projects.createdAt));

  const countResult = await db
    .select({ count: sql<number>`count(*)` })
    .from(projects)
    .where(conditions.length > 0 ? and(...conditions) : undefined);

  return { data: result, total: countResult[0]?.count || 0 };
}

// =====================================================
// 聚合查询优化
// =====================================================

export async function getDashboardStats(userId?: number) {
  // 并行执行多个查询
  const [userStats, customerStats, projectStats, leadStats] = await Promise.all([
    // 用户统计
    db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(userId ? eq(users.id, userId) : undefined),

    // 客户统计
    db
      .select({
        total: sql<number>`count(*)`,
        active: sql<number>`count(*) filter (where status = 'active')`,
      })
      .from(customers),

    // 项目统计
    db
      .select({
        total: sql<number>`count(*)`,
        inProgress: sql<number>`count(*) filter (where status = '进行中')`,
        totalAmount: sql<string>`coalesce(sum(expected_amount), 0)`,
      })
      .from(projects),

    // 线索统计
    db
      .select({
        total: sql<number>`count(*)`,
        new: sql<number>`count(*) filter (where status = 'new')`,
      })
      .from(leads),
  ]);

  return {
    users: userStats[0] || { count: 0 },
    customers: customerStats[0] || { total: 0, active: 0 },
    projects: projectStats[0] || { total: 0, inProgress: 0, totalAmount: '0' },
    leads: leadStats[0] || { total: 0, new: 0 },
  };
}

// 按时间段统计
export async function getStatsByPeriod(
  tableName: 'projects' | 'customers' | 'leads',
  startDate: Date,
  endDate: Date,
  groupBy: 'day' | 'week' | 'month' = 'day'
) {
  const dateFormat = {
    day: 'YYYY-MM-DD',
    week: 'YYYY-"W"WW',
    month: 'YYYY-MM',
  }[groupBy];

  const tableMap = {
    projects: projects,
    customers: customers,
    leads: leads,
  };

  const table = tableMap[tableName];

  const result = await db
    .select({
      period: sql<string>`to_char(created_at, ${dateFormat})`,
      count: sql<number>`count(*)`,
    })
    .from(table)
    .where(
      and(
        gte(table.createdAt, startDate),
        lte(table.createdAt, endDate)
      )
    )
    .groupBy(sql`to_char(created_at, ${dateFormat})`)
    .orderBy(sql`period`);

  return result;
}

// =====================================================
// 批量查询优化
// =====================================================

export async function getCustomersByIds(ids: number[]) {
  if (ids.length === 0) return [];
  
  return await db
    .select()
    .from(customers)
    .where(inArray(customers.id, ids));
}

export async function getProjectsByIds(ids: number[]) {
  if (ids.length === 0) return [];
  
  return await db
    .select({
      id: projects.id,
      projectName: projects.projectName,
      status: projects.status,
      customerName: customers.customerName,
    })
    .from(projects)
    .leftJoin(customers, eq(projects.customerId, customers.id))
    .where(inArray(projects.id, ids));
}

export async function getUsersByIds(ids: number[]) {
  if (ids.length === 0) return [];
  
  return await db
    .select({
      id: users.id,
      realName: users.realName,
      email: users.email,
      status: users.status,
    })
    .from(users)
    .where(inArray(users.id, ids));
}

// =====================================================
// 搜索优化
// =====================================================

export async function globalSearch(query: string, limit = 10) {
  const searchPattern = `%${query}%`;

  // 并行搜索多个表
  const [customerResults, projectResults, userResults, leadResults] = await Promise.all([
    // 搜索客户
    db
      .select({
        type: sql<string>`'customer'`,
        id: customers.id,
        name: customers.customerName,
        description: customers.contactName,
      })
      .from(customers)
      .where(
        or(
          like(customers.customerName, searchPattern),
          like(customers.contactName, searchPattern)
        )
      )
      .limit(limit),

    // 搜索项目
    db
      .select({
        type: sql<string>`'project'`,
        id: projects.id,
        name: projects.projectName,
        description: projects.status,
      })
      .from(projects)
      .where(like(projects.projectName, searchPattern))
      .limit(limit),

    // 搜索用户
    db
      .select({
        type: sql<string>`'user'`,
        id: users.id,
        name: users.realName,
        description: users.email,
      })
      .from(users)
      .where(
        or(
          like(users.realName, searchPattern),
          like(users.email, searchPattern)
        )
      )
      .limit(limit),

    // 搜索线索
    db
      .select({
        type: sql<string>`'lead'`,
        id: leads.id,
        name: leads.customerName,
        description: leads.contactName,
      })
      .from(leads)
      .where(
        or(
          like(leads.customerName, searchPattern),
          like(leads.contactName, searchPattern)
        )
      )
      .limit(limit),
  ]);

  return {
    customers: customerResults,
    projects: projectResults,
    users: userResults,
    leads: leadResults,
    total: customerResults.length + projectResults.length + userResults.length + leadResults.length,
  };
}

// =====================================================
// 查询辅助工具
// =====================================================

// 解析排序参数
export function parseSortParams<T extends string>(
  sortBy: string | undefined,
  sortOrder: string | undefined,
  allowedFields: T[]
): { sortBy: T; sortOrder: 'asc' | 'desc' } {
  const sort = (sortOrder?.toLowerCase() === 'asc' ? 'asc' : 'desc') as 'asc' | 'desc';
  const field = allowedFields.includes(sortBy as T) ? (sortBy as T) : allowedFields[0];
  
  return { sortBy: field, sortOrder: sort };
}

// 构建分页响应
export function buildPaginatedResponse<T>(
  data: T[],
  total: number,
  page: number,
  pageSize: number
) {
  return {
    data,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.ceil(total / pageSize),
    },
  };
}
