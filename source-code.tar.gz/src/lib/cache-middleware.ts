import { NextRequest, NextResponse } from 'next/server';

/**
 * API响应缓存中间件
 * 用于缓存GET请求的响应，减少数据库查询
 */

// 内存缓存存储
const cache = new Map<string, {
  data: any;
  timestamp: number;
  ttl: number;
  etag: string;
}>();

// 缓存配置
const CACHE_CONFIG = {
  // 默认缓存时间（毫秒）
  defaultTTL: 60 * 1000, // 1分钟
  
  // 特定API的缓存配置
  routes: {
    '/api/customers': { ttl: 2 * 60 * 1000, methods: ['GET'] }, // 2分钟
    '/api/projects': { ttl: 2 * 60 * 1000, methods: ['GET'] },
    '/api/opportunities': { ttl: 60 * 1000, methods: ['GET'] }, // 1分钟
    '/api/solutions': { ttl: 5 * 60 * 1000, methods: ['GET'] }, // 5分钟
    '/api/users': { ttl: 60 * 1000, methods: ['GET'] },
    '/api/dashboard': { ttl: 30 * 1000, methods: ['GET'] }, // 30秒
    '/api/data-screen': { ttl: 60 * 1000, methods: ['GET'] },
    '/api/performance': { ttl: 5 * 60 * 1000, methods: ['GET'] }, // 5分钟
  } as Record<string, { ttl: number; methods: string[] }>,
};

// 生成缓存键
function getCacheKey(request: NextRequest): string {
  const url = new URL(request.url);
  const pathname = url.pathname;
  const search = url.search;
  const headers = request.headers.get('authorization') || '';
  
  // 对敏感API，将用户信息纳入缓存键
  return `${pathname}${search}:${headers.slice(0, 50)}`;
}

// 生成ETag
function generateETag(data: any): string {
  const hash = JSON.stringify(data).split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  return `"${Math.abs(hash).toString(36)}"`;
}

// 检查是否应该缓存
function shouldCache(request: NextRequest): { should: boolean; ttl: number } {
  const method = request.method.toUpperCase();
  const url = new URL(request.url);
  const pathname = url.pathname;

  // 只缓存GET请求
  if (method !== 'GET') {
    return { should: false, ttl: 0 };
  }

  // 检查是否有特定配置
  for (const [route, config] of Object.entries(CACHE_CONFIG.routes)) {
    if (pathname.startsWith(route)) {
      if (config.methods.includes(method)) {
        return { should: true, ttl: config.ttl };
      }
    }
  }

  // 默认不缓存
  return { should: false, ttl: 0 };
}

// 获取缓存
export function getCache(request: NextRequest): { data: any; etag: string } | null {
  const key = getCacheKey(request);
  const cached = cache.get(key);

  if (!cached) {
    return null;
  }

  // 检查是否过期
  if (Date.now() > cached.timestamp + cached.ttl) {
    cache.delete(key);
    return null;
  }

  // 检查 If-None-Match 头
  const ifNoneMatch = request.headers.get('if-none-match');
  if (ifNoneMatch === cached.etag) {
    return { data: 'NOT_MODIFIED', etag: cached.etag };
  }

  return { data: cached.data, etag: cached.etag };
}

// 设置缓存
export function setCache(request: NextRequest, data: any, ttl?: number): void {
  const { should, ttl: configTTL } = shouldCache(request);
  
  if (!should && !ttl) {
    return;
  }

  const key = getCacheKey(request);
  const etag = generateETag(data);

  cache.set(key, {
    data,
    timestamp: Date.now(),
    ttl: ttl || configTTL || CACHE_CONFIG.defaultTTL,
    etag,
  });
}

// 清除缓存
export function clearCache(pattern?: string): void {
  if (!pattern) {
    cache.clear();
    return;
  }

  // 清除匹配模式的缓存
  for (const key of cache.keys()) {
    if (key.includes(pattern)) {
      cache.delete(key);
    }
  }
}

// 清除过期缓存
export function cleanExpiredCache(): void {
  const now = Date.now();
  
  for (const [key, value] of cache.entries()) {
    if (now > value.timestamp + value.ttl) {
      cache.delete(key);
    }
  }
}

// 获取缓存统计
export function getCacheStats(): {
  size: number;
  keys: string[];
  hitRate: number;
} {
  return {
    size: cache.size,
    keys: Array.from(cache.keys()),
    hitRate: 0, // 需要单独追踪
  };
}

// 创建缓存响应
export function createCachedResponse(data: any, etag: string, status = 200): NextResponse {
  const response = NextResponse.json(data, { status });
  
  response.headers.set('ETag', etag);
  response.headers.set('Cache-Control', 'private, must-revalidate');
  
  return response;
}

// 创建 Not Modified 响应
export function createNotModifiedResponse(): NextResponse {
  return new NextResponse(null, { status: 304 });
}

// 定期清理过期缓存
if (typeof setInterval !== 'undefined') {
  setInterval(cleanExpiredCache, 60 * 1000); // 每分钟清理一次
}

/**
 * 使用示例:
 * 
 * // 在API路由中使用
 * export async function GET(request: NextRequest) {
 *   // 检查缓存
 *   const cached = getCache(request);
 *   if (cached) {
 *     if (cached.data === 'NOT_MODIFIED') {
 *       return createNotModifiedResponse();
 *     }
 *     return createCachedResponse(cached.data, cached.etag);
 *   }
 * 
 *   // 获取数据
 *   const data = await fetchData();
 * 
 *   // 设置缓存
 *   setCache(request, data);
 * 
 *   return NextResponse.json(data);
 * }
 * 
 * // 数据变更时清除相关缓存
 * export async function POST(request: NextRequest) {
 *   const result = await createData();
 *   clearCache('/api/customers'); // 清除客户相关缓存
 *   return NextResponse.json(result);
 * }
 */
