/**
 * 数据库索引分析工具
 * 用于分析和监控数据库索引使用情况
 */

import { db } from '@/db';
import { sql } from 'drizzle-orm';

export interface IndexUsageStats {
  schemaname: string;
  relname: string;        // 表名
  indexrelname: string;   // 索引名
  idx_scan: number;       // 索引扫描次数
  idx_tup_read: number;   // 通过索引读取的行数
  idx_tup_fetch: number;  // 通过索引获取的行数
  usage_ratio: number;    // 使用率（相对于表扫描的比例）
}

export interface UnusedIndex {
  schemaname: string;
  relname: string;
  indexrelname: string;
  idx_scan: number;
  index_size: string;
}

export interface DuplicateIndex {
  schemaname: string;
  relname: string;
  indexrelname: string;
  redundant_index: string;
  index_size: string;
}

export interface TableScanStats {
  schemaname: string;
  relname: string;
  seq_scan: number;       // 顺序扫描次数
  idx_scan: number;       // 索引扫描次数
  seq_tup_read: number;   // 顺序扫描读取的行数
  idx_tup_read: number;   // 索引扫描读取的行数
  scan_ratio: number;     // 索引扫描比例
}

/**
 * 获取索引使用统计
 */
export async function getIndexUsageStats(): Promise<IndexUsageStats[]> {
  const result = await db.execute(sql`
    SELECT 
      schemaname,
      relname,
      indexrelname,
      idx_scan,
      idx_tup_read,
      idx_tup_fetch,
      CASE 
        WHEN (idx_scan + seq_scan) = 0 THEN 0
        ELSE ROUND((idx_scan::numeric / (idx_scan + seq_scan)) * 100, 2)
      END as usage_ratio
    FROM pg_stat_user_indexes
    JOIN pg_stat_user_tables ON pg_stat_user_indexes.relname = pg_stat_user_tables.relname
    WHERE schemaname = 'public'
    ORDER BY idx_scan DESC
    LIMIT 50
  `);

  // Drizzle 返回的是 RowList，可以直接作为数组处理
  const rows = Array.isArray(result) ? result : (result as any).rows || [];
  return rows as IndexUsageStats[];
}

/**
 * 获取未使用的索引
 * 这些索引占用了空间但从未或很少被使用
 */
export async function getUnusedIndexes(): Promise<UnusedIndex[]> {
  const result = await db.execute(sql`
    SELECT 
      schemaname,
      relname,
      indexrelname,
      idx_scan,
      pg_size_pretty(pg_relation_size(indexrelid)) as index_size
    FROM pg_stat_user_indexes
    JOIN pg_class ON pg_class.oid = pg_stat_user_indexes.indexrelid
    WHERE schemaname = 'public'
      AND idx_scan < 50
      AND indexrelname NOT LIKE '%_pkey'
    ORDER BY pg_relation_size(indexrelid) DESC
    LIMIT 20
  `);

  const rows = Array.isArray(result) ? result : (result as any).rows || [];
  return rows as UnusedIndex[];
}

/**
 * 检测重复索引
 */
export async function getDuplicateIndexes(): Promise<DuplicateIndex[]> {
  const result = await db.execute(sql`
    WITH index_info AS (
      SELECT 
        schemaname,
        tablename as relname,
        indexname as indexrelname,
        indexdef,
        pg_size_pretty(pg_relation_size(schemaname || '.' || indexname)) as index_size
      FROM pg_indexes
      WHERE schemaname = 'public'
    ),
    duplicate_check AS (
      SELECT 
        a.schemaname,
        a.relname,
        a.indexrelname,
        b.indexrelname as redundant_index,
        a.index_size,
        a.indexdef,
        b.indexdef as redundant_def
      FROM index_info a
      JOIN index_info b ON a.relname = b.relname
        AND a.indexrelname != b.indexrelname
        AND position(b.indexrelname in a.indexdef) > 0
    )
    SELECT 
      schemaname,
      relname,
      indexrelname,
      redundant_index,
      index_size
    FROM duplicate_check
    LIMIT 20
  `);

  const rows = Array.isArray(result) ? result : (result as any).rows || [];
  return rows as DuplicateIndex[];
}

/**
 * 获取表扫描统计
 * 高比例的顺序扫描可能表示缺少索引
 */
export async function getTableScanStats(): Promise<TableScanStats[]> {
  const result = await db.execute(sql`
    SELECT 
      schemaname,
      relname,
      seq_scan,
      idx_scan,
      seq_tup_read,
      idx_tup_read,
      CASE 
        WHEN (seq_scan + idx_scan) = 0 THEN 0
        ELSE ROUND((idx_scan::numeric / (seq_scan + idx_scan)) * 100, 2)
      END as scan_ratio
    FROM pg_stat_user_tables
    WHERE schemaname = 'public'
    ORDER BY seq_scan DESC
    LIMIT 30
  `);

  const rows = Array.isArray(result) ? result : (result as any).rows || [];
  return rows as TableScanStats[];
}

/**
 * 获取慢查询日志
 * 注意：需要开启 pg_stat_statements 扩展
 */
export async function getSlowQueries(limit: number = 20): Promise<any[]> {
  try {
    const result = await db.execute(sql`
      SELECT 
        query,
        calls,
        total_exec_time,
        mean_exec_time,
        min_exec_time,
        max_exec_time,
        rows
      FROM pg_stat_statements
      WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
      ORDER BY total_exec_time DESC
      LIMIT ${limit}
    `);
    const rows = Array.isArray(result) ? result : (result as any).rows || [];
    return rows;
  } catch {
    // pg_stat_statements 可能未启用
    return [];
  }
}

/**
 * 生成索引优化建议
 */
export async function generateIndexRecommendations(): Promise<{
  critical: string[];
  warnings: string[];
  info: string[];
}> {
  const recommendations: {
    critical: string[];
    warnings: string[];
    info: string[];
  } = {
    critical: [],
    warnings: [],
    info: []
  };

  // 检查表扫描比例
  const scanStats = await getTableScanStats();
  for (const stat of scanStats) {
    if (stat.seq_scan > 1000 && stat.scan_ratio < 20) {
      recommendations.critical.push(
        `表 "${stat.relname}" 存在高频顺序扫描（${stat.seq_scan}次），索引扫描比例仅 ${stat.scan_ratio}%，建议添加适当索引`
      );
    } else if (stat.seq_scan > 100 && stat.scan_ratio < 50) {
      recommendations.warnings.push(
        `表 "${stat.relname}" 顺序扫描次数较多（${stat.seq_scan}次），索引扫描比例 ${stat.scan_ratio}%`
      );
    }
  }

  // 检查未使用的索引
  const unusedIndexes = await getUnusedIndexes();
  for (const idx of unusedIndexes) {
    if (idx.idx_scan === 0) {
      recommendations.warnings.push(
        `索引 "${idx.indexrelname}" 在表 "${idx.relname}" 上从未被使用，占用空间 ${idx.index_size}，建议评估是否删除`
      );
    } else if (idx.idx_scan < 10) {
      recommendations.info.push(
        `索引 "${idx.indexrelname}" 在表 "${idx.relname}" 上使用率很低（${idx.idx_scan}次），占用空间 ${idx.index_size}`
      );
    }
  }

  // 检查重复索引
  const duplicates = await getDuplicateIndexes();
  for (const dup of duplicates) {
    recommendations.warnings.push(
      `索引 "${dup.indexrelname}" 可能与 "${dup.redundant_index}" 重复，占用空间 ${dup.index_size}`
    );
  }

  return recommendations;
}

/**
 * 获取索引大小统计
 */
export async function getIndexSizeStats(): Promise<{
  totalSize: string;
  indexes: Array<{
    relname: string;
    indexrelname: string;
    size: string;
  }>;
}> {
  const result = await db.execute(sql`
    SELECT 
      schemaname,
      relname,
      indexrelname,
      pg_size_pretty(pg_relation_size(indexrelid)) as size
    FROM pg_stat_user_indexes
    WHERE schemaname = 'public'
    ORDER BY pg_relation_size(indexrelid) DESC
    LIMIT 30
  `);

  // 计算总大小
  const totalResult = await db.execute(sql`
    SELECT COALESCE(SUM(pg_relation_size(indexrelid)), 0) as total_size
    FROM pg_stat_user_indexes
    WHERE schemaname = 'public'
  `);

  const totalRows = Array.isArray(totalResult) ? totalResult : (totalResult as any).rows || [];
  const totalBytes = (totalRows[0] as any)?.total_size || 0;
  const totalSize = formatBytes(totalBytes);

  const rows = Array.isArray(result) ? result : (result as any).rows || [];
  return {
    totalSize,
    indexes: rows.map((row: any) => ({
      relname: row.relname,
      indexrelname: row.indexrelname,
      size: row.size
    }))
  };
}

/**
 * 格式化字节数
 */
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 执行 ANALYZE 更新统计信息
 */
export async function analyzeTables(tables?: string[]): Promise<void> {
  if (tables && tables.length > 0) {
    for (const table of tables) {
      await db.execute(sql.raw(`ANALYZE ${table}`));
    }
  } else {
    await db.execute(sql`ANALYZE`);
  }
}

/**
 * 获取数据库统计信息摘要
 */
export async function getDatabaseStatsSummary(): Promise<{
  totalTables: number;
  totalIndexes: number;
  totalIndexSize: string;
  unusedIndexCount: number;
  lowUsageTables: number;
  lastAnalyze: string;
}> {
  // 获取表数量
  const tablesResult = await db.execute(sql`
    SELECT COUNT(*) as count FROM pg_stat_user_tables
  `);
  const tablesRows = Array.isArray(tablesResult) ? tablesResult : (tablesResult as any).rows || [];
  const totalTables = (tablesRows[0] as any)?.count || 0;

  // 获取索引数量
  const indexesResult = await db.execute(sql`
    SELECT COUNT(*) as count FROM pg_stat_user_indexes
  `);
  const indexesRows = Array.isArray(indexesResult) ? indexesResult : (indexesResult as any).rows || [];
  const totalIndexes = (indexesRows[0] as any)?.count || 0;

  // 获取总索引大小
  const sizeResult = await db.execute(sql`
    SELECT COALESCE(SUM(pg_relation_size(indexrelid)), 0) as total_size
    FROM pg_stat_user_indexes
    WHERE schemaname = 'public'
  `);
  const sizeRows = Array.isArray(sizeResult) ? sizeResult : (sizeResult as any).rows || [];
  const totalIndexSize = formatBytes((sizeRows[0] as any)?.total_size || 0);

  // 获取未使用索引数量
  const unusedResult = await db.execute(sql`
    SELECT COUNT(*) as count
    FROM pg_stat_user_indexes
    WHERE schemaname = 'public'
      AND idx_scan < 50
      AND indexrelname NOT LIKE '%_pkey'
  `);
  const unusedRows = Array.isArray(unusedResult) ? unusedResult : (unusedResult as any).rows || [];
  const unusedIndexCount = (unusedRows[0] as any)?.count || 0;

  // 获取低索引使用率表数量
  const lowUsageResult = await db.execute(sql`
    SELECT COUNT(*) as count
    FROM pg_stat_user_tables
    WHERE schemaname = 'public'
      AND seq_scan > 100
      AND CASE 
        WHEN (seq_scan + idx_scan) = 0 THEN 0
        ELSE (idx_scan::numeric / (seq_scan + idx_scan)) * 100
      END < 50
  `);
  const lowUsageRows = Array.isArray(lowUsageResult) ? lowUsageResult : (lowUsageResult as any).rows || [];
  const lowUsageTables = (lowUsageRows[0] as any)?.count || 0;

  return {
    totalTables,
    totalIndexes,
    totalIndexSize,
    unusedIndexCount,
    lowUsageTables,
    lastAnalyze: new Date().toISOString()
  };
}
