/**
 * 项目状态转换规则
 * 基于 docs/项目管理模块优化/02-详细设计文档.md 实现
 */

// 项目状态类型
export type ProjectStatus = 'lead' | 'in_progress' | 'won' | 'lost' | 'on_hold' | 'cancelled';

// 项目阶段类型（售前管理系统：商机 → 投标 → 归档）
export type ProjectStage = 'opportunity' | 'bidding' | 'archived';

// 状态转换矩阵
export const STATUS_TRANSITIONS: Record<ProjectStatus, ProjectStatus[]> = {
  lead: ['in_progress', 'on_hold', 'cancelled'],
  in_progress: ['lead', 'won', 'lost', 'on_hold', 'cancelled'],
  won: ['on_hold', 'cancelled'],
  lost: ['on_hold', 'cancelled'],
  on_hold: ['lead', 'in_progress', 'won', 'lost'],
  cancelled: [] // 终态
};

// 阶段转换矩阵（售前管理系统）
// 支持正向推进和回退操作
export const STAGE_TRANSITIONS: Record<ProjectStage, ProjectStage[]> = {
  opportunity: ['bidding'],                    // 商机 → 投标
  bidding: ['opportunity', 'archived'],        // 投标 → 商机（回退）或 归档
  archived: ['bidding', 'opportunity']         // 归档 → 投标或商机（特殊回退）
};

// 阶段顺序（用于判断前后关系）
export const STAGE_ORDER: ProjectStage[] = [
  'opportunity', 'bidding', 'archived'
];

// 状态配置
export const PROJECT_STATUS_CONFIG: Record<ProjectStatus, { label: string; color: string; description: string }> = {
  lead: { label: '商机线索', color: 'slate', description: '有项目线索和消息，但主观判断并不一定会形成项目' },
  in_progress: { label: '跟进中', color: 'blue', description: '售前大多数项目为此状态，涵盖整个项目生命周期' },
  won: { label: '已中标', color: 'emerald', description: '收到中标通知书后可改为此状态' },
  lost: { label: '已丢标', color: 'red', description: '项目已经丢标的明确状态' },
  on_hold: { label: '已暂停', color: 'amber', description: '项目暂时搁置' },
  cancelled: { label: '已取消', color: 'gray', description: '项目已取消' }
};

// 阶段配置（售前管理系统）
export const PROJECT_STAGE_CONFIG: Record<ProjectStage, { label: string; shortLabel: string; color: string; description: string }> = {
  opportunity: { label: '商机阶段', shortLabel: '商机', color: 'blue', description: '线索跟进、需求调研、方案设计' },
  bidding: { label: '招标投标', shortLabel: '投标', color: 'orange', description: '投标文件准备、开标评标' },
  archived: { label: '归档', shortLabel: '归档', color: 'gray', description: '项目归档、经验总结' }
};

/**
 * 获取当前状态可以变更到的目标状态列表
 */
export function getAvailableStatuses(currentStatus: ProjectStatus): ProjectStatus[] {
  return STATUS_TRANSITIONS[currentStatus] || [];
}

/**
 * 检查状态变更是否允许
 */
export function isStatusTransitionAllowed(from: ProjectStatus, to: ProjectStatus): boolean {
  const allowedStatuses = getAvailableStatuses(from);
  return allowedStatuses.includes(to);
}

/**
 * 获取状态变更时的必填字段
 */
export function getRequiredFieldsForStatus(status: ProjectStatus): string[] {
  const baseFields = ['projectName', 'customerId'];
  
  const statusFields: Partial<Record<ProjectStatus, string[]>> = {
    won: ['winAmount', 'winDate'],
    lost: ['lostReason'],
    on_hold: ['holdReason'],
    cancelled: ['cancelReason']
  };
  
  return [...baseFields, ...(statusFields[status] || [])];
}

/**
 * 获取状态变更时的提示信息
 */
export function getStatusChangeMessage(from: ProjectStatus, to: ProjectStatus): string | null {
  const messages: Record<string, string> = {
    'lead->in_progress': '确认开始正式跟进此项目？',
    'in_progress->won': '确认已中标？请填写中标金额和日期，建议将阶段切换为实施阶段。',
    'in_progress->lost': '确认已丢标？此操作将标记项目失败。',
    '->on_hold': '项目将暂停，可随时恢复。',
    '->cancelled': '确认取消此项目？取消后状态不可恢复。'
  };
  
  const key = `${from}->${to}`;
  if (messages[key]) return messages[key];
  
  if (to === 'on_hold') return messages['->on_hold'];
  if (to === 'cancelled') return messages['->cancelled'];
  
  return null;
}

/**
 * 检查状态变更是否需要弹出确认对话框
 */
export function requiresStatusConfirmDialog(status: ProjectStatus): boolean {
  // 已中标、已丢标、已暂停、已取消都需要弹出对话框
  return ['won', 'lost', 'on_hold', 'cancelled'].includes(status);
}

/**
 * 获取状态变更需要填写的额外字段
 */
export function getAdditionalFieldsForStatus(status: ProjectStatus): Array<{ field: string; label: string; type: string; required: boolean }> {
  const fieldsMap: Record<string, Array<{ field: string; label: string; type: string; required: boolean }>> = {
    won: [
      { field: 'winAmount', label: '中标金额', type: 'number', required: true },
      { field: 'winDate', label: '中标日期', type: 'date', required: true }
    ],
    lost: [
      { field: 'lostReason', label: '丢标原因', type: 'select', required: false }
    ],
    on_hold: [
      { field: 'holdReason', label: '暂停原因', type: 'text', required: true }
    ],
    cancelled: [
      { field: 'cancelReason', label: '取消原因', type: 'text', required: true }
    ]
  };
  
  return fieldsMap[status] || [];
}

/**
 * 获取可用的状态选项列表（带禁用信息）
 */
export function getStatusOptions(currentStatus: ProjectStatus): Array<{
  status: ProjectStatus;
  label: string;
  disabled: boolean;
  reason?: string;
}> {
  const availableStatuses = getAvailableStatuses(currentStatus);
  const allStatuses: ProjectStatus[] = ['lead', 'in_progress', 'won', 'lost', 'on_hold', 'cancelled'];
  
  return allStatuses.map(status => {
    const isAvailable = availableStatuses.includes(status);
    const config = PROJECT_STATUS_CONFIG[status];
    
    let reason: string | undefined;
    if (!isAvailable) {
      if (status === 'won' || status === 'lost') {
        reason = '需先转为跟进中';
      } else if (currentStatus === 'cancelled') {
        reason = '已取消状态不可变更';
      } else if (currentStatus === 'won' && ['lead', 'in_progress', 'lost'].includes(status)) {
        reason = '已中标状态不可变更为此状态';
      }
    }
    
    return {
      status,
      label: config.label,
      disabled: !isAvailable,
      reason
    };
  });
}
