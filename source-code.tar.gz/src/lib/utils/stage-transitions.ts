/**
 * 项目阶段转换规则
 * 基于 docs/项目管理模块优化/02-详细设计文档.md 实现
 */

import { ProjectStage, ProjectStatus, STAGE_ORDER, STAGE_TRANSITIONS, PROJECT_STAGE_CONFIG } from './status-transitions';

/**
 * 阶段回退规则配置
 */
export interface StageRollbackRule {
  canRollbackTo: ProjectStage[];       // 可回退到的目标阶段
  requiresReason: boolean;              // 是否必须填写回退原因
  requiresApproval: boolean;            // 是否需要审批
  preserveData: boolean;                // 是否保留当前阶段数据
  notifyRoles: string[];                // 需要通知的角色
  warningMessage?: string;              // 回退警告信息
}

// 阶段回退规则矩阵
export const STAGE_ROLLBACK_RULES: Record<ProjectStage, StageRollbackRule> = {
  opportunity: {
    canRollbackTo: [],                  // 商机阶段无法回退
    requiresReason: false,
    requiresApproval: false,
    preserveData: false,
    notifyRoles: [],
  },
  bidding: {
    canRollbackTo: ['opportunity'],     // 投标阶段可回退到商机
    requiresReason: true,               // 必须填写原因
    requiresApproval: false,
    preserveData: true,                 // 保留招投标数据
    notifyRoles: ['manager', 'members'],
    warningMessage: '回退到商机阶段后，招投标信息将保留但不可编辑，再次进入投标阶段时可复用。',
  },
  archived: {
    canRollbackTo: ['bidding', 'opportunity'], // 归档可回退
    requiresReason: true,
    requiresApproval: true,             // 归档回退需要审批
    preserveData: true,
    notifyRoles: ['manager', 'supervisor'],
    warningMessage: '归档回退需要主管审批，请确认是否继续。',
  },
};

/**
 * 常见回退原因选项
 */
export const ROLLBACK_REASONS: Record<string, string[]> = {
  'bidding->opportunity': [
    '招标文件变更，需重新评估',
    '投标延期，需等待新招标时间',
    '内部审批驳回，需重新准备',
    '竞争策略调整',
    '客户需求变更',
    '预算或资源问题',
    '其他原因',
  ],
  'archived->bidding': [
    '项目重新启动',
    '归档信息有误',
    '客户要求重新投标',
  ],
  'archived->opportunity': [
    '商机重新激活',
    '归档信息有误',
    '客户重新发起需求',
  ],
};

/**
 * 判断阶段变更是否为回退操作
 */
export function isStageRollback(fromStage: ProjectStage, toStage: ProjectStage): boolean {
  const fromIndex = STAGE_ORDER.indexOf(fromStage);
  const toIndex = STAGE_ORDER.indexOf(toStage);
  return toIndex < fromIndex;
}

/**
 * 检查阶段回退是否允许
 */
export function validateStageRollback(
  fromStage: ProjectStage,
  toStage: ProjectStage,
  currentStatus: ProjectStatus
): { valid: boolean; reason?: string; warning?: string; rule?: StageRollbackRule } {
  // 规则1：检查是否为回退操作
  if (!isStageRollback(fromStage, toStage)) {
    return { valid: true }; // 不是回退，走正常变更流程
  }

  // 规则2：获取回退规则
  const rule = STAGE_ROLLBACK_RULES[fromStage];
  
  // 规则3：检查是否允许回退到目标阶段
  if (!rule.canRollbackTo.includes(toStage)) {
    return { 
      valid: false, 
      reason: `「${PROJECT_STAGE_CONFIG[fromStage].label}」不允许回退到「${PROJECT_STAGE_CONFIG[toStage].label}」` 
    };
  }

  // 规则4：丢标和取消状态不允许回退
  if (currentStatus === 'lost' || currentStatus === 'cancelled') {
    return { 
      valid: false, 
      reason: '已丢标或已取消的项目不允许阶段回退' 
    };
  }

  // 规则5：中标后回退需要特殊审批
  if (currentStatus === 'won' && fromStage === 'archived') {
    return { 
      valid: false, 
      reason: '已中标归档的项目回退需要联系管理员处理' 
    };
  }

  return { 
    valid: true, 
    warning: rule.warningMessage,
    rule 
  };
}

/**
 * 获取阶段回退原因选项
 */
export function getRollbackReasonOptions(fromStage: ProjectStage, toStage: ProjectStage): string[] {
  const key = `${fromStage}->${toStage}`;
  return ROLLBACK_REASONS[key] || ['其他原因'];
}

/**
 * 获取当前阶段可回退的状态变更目标状态
 */
export function getRollbackTargetStatuses(
  fromStage: ProjectStage,
  toStage: ProjectStage
): Array<{ status: ProjectStatus; label: string; recommended: boolean }> {
  // 回退到商机阶段，建议状态改为跟进中
  if (toStage === 'opportunity') {
    return [
      { status: 'in_progress', label: '跟进中', recommended: true },
      { status: 'lead', label: '商机线索', recommended: false },
      { status: 'on_hold', label: '已暂停', recommended: false },
    ];
  }
  
  // 回退到投标阶段，保持原状态或改为跟进中
  if (toStage === 'bidding') {
    return [
      { status: 'in_progress', label: '跟进中', recommended: true },
      { status: 'on_hold', label: '已暂停', recommended: false },
    ];
  }
  
  return [];
}

/**
 * 获取当前阶段可以变更到的目标阶段列表
 */
export function getAvailableStages(currentStage: ProjectStage): ProjectStage[] {
  return STAGE_TRANSITIONS[currentStage] || [];
}

/**
 * 检查阶段变更是否允许（考虑状态约束）
 */
export function validateStageTransition(
  fromStage: ProjectStage,
  toStage: ProjectStage,
  currentStatus: ProjectStatus
): { valid: boolean; reason?: string; warning?: string } {
  // 规则1：归档后不允许变更
  if (fromStage === 'archived') {
    return { valid: false, reason: '归档后阶段不可变更' };
  }

  // 规则2：检查是否在允许的转换列表中
  const allowedStages = getAvailableStages(fromStage);
  if (!allowedStages.includes(toStage)) {
    return { valid: false, reason: '不支持的阶段变更' };
  }

  // 规则3：中标后不允许退回到前期阶段
  if (currentStatus === 'won') {
    const backwardStages: ProjectStage[] = ['opportunity', 'bidding'];
    const fromIndex = STAGE_ORDER.indexOf(fromStage);
    const toIndex = STAGE_ORDER.indexOf(toStage);
    
    // 如果尝试退回到商机或投标阶段，且当前不在这些阶段
    if (backwardStages.includes(toStage) && !backwardStages.includes(fromStage)) {
      return { valid: false, reason: '中标后不可退回商机阶段或招标投标阶段' };
    }
  }

  // 规则4：进入归档需要确认
  if (toStage === 'archived') {
    return { 
      valid: true, 
      warning: '归档后项目将不可修改，确定要归档吗？' 
    };
  }

  // 规则5：阶段推进提示
  const warnings: Partial<Record<ProjectStage, string>> = {
    bidding: '进入招标投标阶段前，请确保招标信息完整',
    archived: '归档前，请确保项目状态已更新（中标/丢标/取消）'
  };

  if (warnings[toStage]) {
    return { valid: true, warning: warnings[toStage] };
  }

  return { valid: true };
}

/**
 * 检查是否可以跳过某个阶段
 */
export function canSkipStage(fromStage: ProjectStage, toStage: ProjectStage): boolean {
  const fromIndex = STAGE_ORDER.indexOf(fromStage);
  const toIndex = STAGE_ORDER.indexOf(toStage);
  
  // 只能顺序推进，不能跳过
  return toIndex <= fromIndex + 1;
}

/**
 * 获取阶段变更时的必填字段
 */
export function getRequiredFieldsForStage(stage: ProjectStage, status: ProjectStatus): string[] {
  const baseFields = ['projectName', 'customerId'];
  
  const stageFields: Partial<Record<ProjectStage, string[]>> = {
    opportunity: ['budget', 'region'],
    bidding: ['bidDeadline', 'bidMethod']
  };
  
  return [...baseFields, ...(stageFields[stage] || [])];
}

/**
 * 获取可用的阶段选项列表（带禁用信息）
 */
export function getStageOptions(
  currentStage: ProjectStage,
  currentStatus: ProjectStatus
): Array<{
  stage: ProjectStage;
  label: string;
  shortLabel: string;
  disabled: boolean;
  reason?: string;
  warning?: string;
}> {
  const allStages: ProjectStage[] = ['opportunity', 'bidding', 'archived'];
  
  return allStages.map(stage => {
    const config = PROJECT_STAGE_CONFIG[stage];
    const validation = validateStageTransition(currentStage, stage, currentStatus);
    
    return {
      stage,
      label: config.label,
      shortLabel: config.shortLabel,
      disabled: !validation.valid,
      reason: validation.reason,
      warning: validation.warning
    };
  });
}

/**
 * 判断投标信息选项卡是否可访问
 */
export function canAccessBiddingTab(currentStage: ProjectStage): boolean {
  const stageIndex = STAGE_ORDER.indexOf(currentStage);
  return stageIndex >= 1; // 索引 >= 1 表示到达招标投标阶段
}

/**
 * 获取应该显示的选项卡列表
 */
export function getVisibleTabs(stage: ProjectStage, status: ProjectStatus): string[] {
  // 基础选项卡
  const baseTabs = ['basic', 'opportunity'];
  
  // 根据阶段添加选项卡
  if (canAccessBiddingTab(stage)) {
    baseTabs.push('bidding');
  }
  
  return baseTabs;
}

/**
 * 判断项目是否只读
 */
export function isProjectReadOnly(stage: ProjectStage, status: ProjectStatus): boolean {
  return stage === 'archived' || status === 'cancelled';
}
