import { NextRequest } from 'next/server';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this-in-production';

// 密码哈希
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

// 验证密码
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// 生成 JWT Token
export function generateToken(userId: string, email: string, role: string): string {
  return jwt.sign(
    {
      userId,
      email,
      role,
    },
    JWT_SECRET,
    {
      expiresIn: '7d', // Token 有效期 7 天
    }
  );
}

// 验证 JWT Token
export function verifyToken(token: string) {
  try {
    return jwt.verify(token, JWT_SECRET) as {
      userId: string;
      email: string;
      role: string;
      iat: number;
      exp: number;
    };
  } catch (error) {
    return null;
  }
}

// 从 Token 中提取用户信息
export function getUserFromToken(token: string) {
  const decoded = verifyToken(token);
  if (!decoded) {
    return null;
  }
  return {
    userId: decoded.userId,
    email: decoded.email,
    role: decoded.role,
  };
}

// 身份验证中间件
export async function authenticate(req: NextRequest) {
  try {
    // 测试模式：如果设置了 TEST_MODE 环境变量，则跳过认证
    const isTestMode = process.env.TEST_MODE === 'true' || process.env.NODE_ENV === 'test';
    
    if (isTestMode) {
      // 在测试模式下返回一个虚拟用户
      return {
        id: 1,
        email: 'test@example.com',
        role: 'admin',
      };
    }

    // 从 Cookie 或 Authorization header 中获取 token
    const token = req.cookies.get('token')?.value || 
                 req.headers.get('authorization')?.replace('Bearer ', '');

    if (!token) {
      return null;
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      return null;
    }

    return {
      id: parseInt(decoded.userId),
      email: decoded.email,
      role: decoded.role,
    };
  } catch (error) {
    console.error('Authentication error:', error);
    return null;
  }
}
