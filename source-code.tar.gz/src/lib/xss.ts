import DOMPurify from 'isomorphic-dompurify';

// BUG-035: 搜索字符串最大长度限制
const MAX_SEARCH_LENGTH = 200;

/**
 * 清理字符串中的HTML标签，防止XSS攻击
 */
export function sanitizeString(input: string): string {
  if (!input || typeof input !== 'string') return input;
  // 移除所有HTML标签
  const cleaned = DOMPurify.sanitize(input, { ALLOWED_TAGS: [] });
  return cleaned.trim();
}

/**
 * 清理搜索字符串，限制长度并移除危险字符
 */
export function sanitizeSearchString(input: string): string {
  if (!input || typeof input !== 'string') return '';
  // 限制长度
  let cleaned = input.slice(0, MAX_SEARCH_LENGTH);
  // 移除HTML标签
  cleaned = DOMPurify.sanitize(cleaned, { ALLOWED_TAGS: [] });
  // BUG-036: 移除潜在危险的SQL注入字符
  cleaned = cleaned.replace(/['";\\]/g, '');
  return cleaned.trim();
}

/**
 * 验证字符串是否包含潜在危险的HTML内容
 */
export function containsHtml(input: string): boolean {
  if (!input || typeof input !== 'string') return false;
  const htmlPattern = /<[^>]+>|<script|<\/script|javascript:|on\w+=/i;
  return htmlPattern.test(input);
}

/**
 * 验证邮箱格式
 */
export function isValidEmail(email: string): boolean {
  if (!email) return false;
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}

/**
 * 验证手机号格式（中国大陆）
 */
export function isValidPhone(phone: string): boolean {
  if (!phone) return false;
  const phonePattern = /^1[3-9]\d{9}$/;
  return phonePattern.test(phone);
}
