'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Calendar,
  Plus,
  Search,
  Clock,
  MapPin,
  Users,
  MessageSquare,
  Lightbulb,
  Building2,
  Trash2,
  Edit,
  ChevronLeft,
  ChevronRight,
  Video,
  Phone,
  AlertCircle,
  Star,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

// 类型定义
interface Schedule {
  id: number;
  title: string;
  type: string;
  startDate: string;
  startTime: string;
  endDate: string;
  endTime: string;
  allDay: boolean;
  location: string;
  participants: string;
  scheduleStatus: string;
  description: string;
  createdAt: string;
}

interface StarredProject {
  id: number;
  projectCode: string;
  projectName: string;
  customerName: string;
  status: string;
  progress: number;
}

// 获取日程类型图标
const getScheduleIcon = (type: string) => {
  const icons: Record<string, React.ReactNode> = {
    meeting: <Users className="h-4 w-4" />,
    visit: <Building2 className="h-4 w-4" />,
    call: <Phone className="h-4 w-4" />,
    presentation: <Lightbulb className="h-4 w-4" />,
    online: <Video className="h-4 w-4" />,
    other: <Calendar className="h-4 w-4" />,
  };
  return icons[type] || icons.other;
};

// 获取日程类型标签
const getScheduleTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    meeting: '会议',
    visit: '拜访',
    call: '电话',
    presentation: '演示',
    online: '线上会议',
    other: '其他',
  };
  return labels[type] || '其他';
};

// 获取类型颜色
const getTypeColor = (type: string) => {
  const colors: Record<string, string> = {
    meeting: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    visit: 'bg-green-500/10 text-green-600 border-green-500/20',
    call: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    presentation: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
    online: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20',
    other: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
  };
  return colors[type] || colors.other;
};

// 获取状态样式
const getStatusStyle = (status: string) => {
  const styles: Record<string, string> = {
    scheduled: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    completed: 'bg-green-500/10 text-green-600 border-green-500/20',
    cancelled: 'bg-red-500/10 text-red-600 border-red-500/20',
    postponed: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  };
  return styles[status] || styles.scheduled;
};

// 获取状态标签
const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    scheduled: '已安排',
    completed: '已完成',
    cancelled: '已取消',
    postponed: '已延期',
  };
  return labels[status] || '已安排';
};

// 统计类型
type StatsType = 'total' | 'today' | 'pending' | 'urgent';

export default function SchedulesPage() {
  const router = useRouter();
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [starredProjects, setStarredProjects] = useState<StarredProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [currentDate, setCurrentDate] = useState<string>('');
  const [mounted, setMounted] = useState(false);

  // 弹窗状态
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState<StatsType>('total');
  const [dialogSchedules, setDialogSchedules] = useState<Schedule[]>([]);

  useEffect(() => {
    // 初始化日期，避免 hydration 错误
    const now = new Date();
    setCurrentDate(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`);
    setMounted(true);
  }, []);

  useEffect(() => {
    if (currentDate) {
      fetchSchedules();
      fetchStarredProjects();
    }
  }, [currentDate]);

  const fetchSchedules = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('startDate', `${currentDate}-01`);
      params.set('endDate', `${currentDate}-31`);

      const response = await fetch(`/api/schedules?${params.toString()}`);
      const result = await response.json();

      if (result.success) {
        setSchedules(result.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch schedules:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStarredProjects = async () => {
    try {
      const response = await fetch('/api/starred-projects');
      const result = await response.json();
      if (result.success) {
        setStarredProjects(result.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch starred projects:', error);
    }
  };

  const handleDeleteSchedule = async (scheduleId: number) => {
    if (!confirm('确定要删除这个日程吗？')) return;

    try {
      await fetch(`/api/schedules/${scheduleId}`, {
        method: 'DELETE',
      });
      fetchSchedules();
      // 刷新弹窗数据
      setDialogSchedules(getSchedulesByType(dialogType));
    } catch (error) {
      console.error('Failed to delete schedule:', error);
    }
  };

  // 完成日程
  const handleCompleteSchedule = async (scheduleId: number) => {
    try {
      const response = await fetch(`/api/schedules/${scheduleId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scheduleStatus: 'completed' }),
      });
      const result = await response.json();
      if (result.success) {
        fetchSchedules();
        // 刷新弹窗数据
        setDialogSchedules(getSchedulesByType(dialogType));
      }
    } catch (error) {
      console.error('Failed to complete schedule:', error);
    }
  };

  // 打开明细弹窗
  const openDetailDialog = (type: StatsType) => {
    setDialogType(type);
    setDialogSchedules(getSchedulesByType(type));
    setDialogOpen(true);
  };

  // 根据类型获取日程
  const getSchedulesByType = (type: StatsType): Schedule[] => {
    const todayStr = new Date().toISOString().split('T')[0];

    switch (type) {
      case 'total':
        return schedules;
      case 'today':
        return schedules.filter(s => s.startDate === todayStr);
      case 'pending':
        return schedules.filter(s => s.scheduleStatus === 'scheduled');
      case 'urgent':
        // 紧急任务：高优先级或今天截止的待处理任务
        return schedules.filter(s =>
          s.scheduleStatus === 'scheduled' &&
          (s.startDate === todayStr || s.type === 'meeting')
        );
      default:
        return schedules;
    }
  };

  // 过滤日程
  const filteredSchedules = schedules.filter(schedule => {
    const matchesSearch = (schedule.title?.toLowerCase() || '').includes(searchKeyword.toLowerCase()) ||
      (schedule.location?.toLowerCase() || '').includes(searchKeyword.toLowerCase());
    const matchesType = typeFilter === 'all' || schedule.type === typeFilter;
    return matchesSearch && matchesType;
  });

  // 按日期分组
  const groupedSchedules = filteredSchedules.reduce((acc, schedule) => {
    const date = schedule.startDate;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(schedule);
    return acc;
  }, {} as Record<string, Schedule[]>);

  // 排序日期
  const sortedDates = Object.keys(groupedSchedules).sort((a, b) => a.localeCompare(b));

  // 统计
  const todayStr = typeof window !== 'undefined' ? new Date().toISOString().split('T')[0] : '';
  const stats = {
    total: schedules.length,
    today: schedules.filter(s => s.startDate === todayStr).length,
    pending: schedules.filter(s => s.scheduleStatus === 'scheduled').length,
    urgent: schedules.filter(s =>
      s.scheduleStatus === 'scheduled' &&
      (s.startDate === todayStr || s.type === 'meeting')
    ).length,
  };

  // 切换月份
  const changeMonth = (direction: 'prev' | 'next') => {
    const [year, month] = currentDate.split('-').map(Number);
    const date = new Date(year, month - 1, 1);
    if (direction === 'prev') {
      date.setMonth(date.getMonth() - 1);
    } else {
      date.setMonth(date.getMonth() + 1);
    }
    setCurrentDate(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`);
  };

  // 获取弹窗标题
  const getDialogTitle = (type: StatsType) => {
    const titles: Record<StatsType, string> = {
      total: '全部事项',
      today: '今日事项',
      pending: '待处理事项',
      urgent: '紧急任务',
    };
    return titles[type];
  };

  // 获取弹窗图标
  const getDialogIcon = (type: StatsType) => {
    const icons: Record<StatsType, React.ReactNode> = {
      total: <Calendar className="h-5 w-5" />,
      today: <Clock className="h-5 w-5" />,
      pending: <AlertCircle className="h-5 w-5" />,
      urgent: <AlertCircle className="h-5 w-5 text-red-500" />,
    };
    return icons[type];
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">日程管理</h1>
          <p className="text-muted-foreground">管理您的日程安排</p>
        </div>
        <Button asChild>
          <Link href="/schedules/new">
            <Plus className="h-4 w-4 mr-2" />
            新建日程
          </Link>
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => openDetailDialog('total')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">全部事项</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">点击查看详情</p>
          </CardContent>
        </Card>
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => openDetailDialog('today')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">今日事项</CardTitle>
            <Clock className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.today}</div>
            <p className="text-xs text-muted-foreground">点击查看详情</p>
          </CardContent>
        </Card>
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => openDetailDialog('pending')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">待处理事项</CardTitle>
            <AlertCircle className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.pending}</div>
            <p className="text-xs text-muted-foreground">点击查看详情</p>
          </CardContent>
        </Card>
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => openDetailDialog('urgent')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">紧急任务</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.urgent}</div>
            <p className="text-xs text-muted-foreground">点击查看详情</p>
          </CardContent>
        </Card>
      </div>

      {/* 主要内容区域：左侧日程列表 + 右侧重点项目 */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* 左侧：日程列表 */}
        <div className="lg:col-span-2 space-y-6">
          {/* 搜索和筛选 */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="搜索日程..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="类型筛选" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="meeting">会议</SelectItem>
                    <SelectItem value="visit">拜访</SelectItem>
                    <SelectItem value="call">电话</SelectItem>
                    <SelectItem value="presentation">演示</SelectItem>
                    <SelectItem value="online">线上会议</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" onClick={() => changeMonth('prev')}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium min-w-[100px] text-center">
                    {currentDate}
                  </span>
                  <Button variant="outline" size="icon" onClick={() => changeMonth('next')}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 日程列表 */}
          <Card>
            <CardContent className="pt-6">
              {loading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : sortedDates.length > 0 ? (
                <div className="space-y-6">
                  {sortedDates.map((date) => (
                    <div key={date}>
                      <div className="flex items-center gap-2 mb-3">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">{date}</span>
                        <Badge variant="outline" className="text-xs">
                          {groupedSchedules[date].length} 个日程
                        </Badge>
                      </div>
                      <div className="space-y-3">
                        {groupedSchedules[date].map((schedule) => (
                          <div
                            key={schedule.id}
                            className="flex items-start gap-3 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                          >
                            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                              {getScheduleIcon(schedule.type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="font-medium truncate">{schedule.title}</span>
                                <Badge variant="outline" className={`text-xs ${getTypeColor(schedule.type)}`}>
                                  {getScheduleTypeLabel(schedule.type)}
                                </Badge>
                                <Badge variant="outline" className={`text-xs ${getStatusStyle(schedule.scheduleStatus)}`}>
                                  {getStatusLabel(schedule.scheduleStatus)}
                                </Badge>
                              </div>
                              <div className="flex flex-wrap items-center gap-4 mt-2 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {schedule.allDay ? '全天' : `${schedule.startTime || ''}${schedule.endTime ? ' - ' + schedule.endTime : ''}`}
                                </span>
                                {schedule.location && (
                                  <span className="flex items-center gap-1">
                                    <MapPin className="h-3 w-3" />
                                    {schedule.location}
                                  </span>
                                )}
                                {schedule.participants && (
                                  <span className="flex items-center gap-1">
                                    <Users className="h-3 w-3" />
                                    {schedule.participants}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => router.push(`/schedules/${schedule.id}/edit`)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteSchedule(schedule.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Calendar className="h-12 w-12 text-muted-foreground/30 mb-3" />
                  <p className="text-muted-foreground">暂无日程安排</p>
                  <Button variant="link" size="sm" className="mt-2" asChild>
                    <Link href="/schedules/new">
                      <Plus className="h-4 w-4 mr-1" />
                      创建日程
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 右侧：重点项目 */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="h-4 w-4 text-yellow-500" />
                重点项目
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/projects">
                  查看全部
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                {starredProjects.length > 0 ? (
                  <div className="space-y-3">
                    {starredProjects.map((project) => (
                      <Link
                        key={project.id}
                        href={`/projects/${project.id}`}
                        className="block p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium truncate">{project.projectName}</span>
                          <Badge variant="outline" className="text-xs">
                            {project.status === 'ongoing' ? '进行中' : project.status === 'completed' ? '已完成' : project.status}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between mt-2 text-sm">
                          <span className="text-muted-foreground truncate">{project.customerName}</span>
                          <span className="font-medium">{project.progress}%</span>
                        </div>
                        <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${project.progress}%` }}
                          />
                        </div>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center py-8">
                    <Star className="h-12 w-12 text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">暂无重点项目</p>
                    <Button variant="link" size="sm" className="mt-2" asChild>
                      <Link href="/projects">
                        <Plus className="h-4 w-4 mr-1" />
                        去标记重点项目
                      </Link>
                    </Button>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 明细弹窗 */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {getDialogIcon(dialogType)}
              {getDialogTitle(dialogType)}
              <Badge variant="outline" className="ml-2">{dialogSchedules.length}</Badge>
            </DialogTitle>
            <DialogDescription>
              {dialogType === 'total' && '本月所有日程事项'}
              {dialogType === 'today' && '今日需要处理的日程'}
              {dialogType === 'pending' && '待处理状态的日程'}
              {dialogType === 'urgent' && '今日截止或重要的紧急任务'}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[50vh]">
            {dialogSchedules.length > 0 ? (
              <div className="space-y-3 pr-4">
                {dialogSchedules.map((schedule) => (
                  <div
                    key={schedule.id}
                    className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      {getScheduleIcon(schedule.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium truncate">{schedule.title}</span>
                        <Badge variant="outline" className={`text-xs ${getTypeColor(schedule.type)}`}>
                          {getScheduleTypeLabel(schedule.type)}
                        </Badge>
                        <Badge variant="outline" className={`text-xs ${getStatusStyle(schedule.scheduleStatus)}`}>
                          {getStatusLabel(schedule.scheduleStatus)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {schedule.startDate}
                        </span>
                        {schedule.startTime && (
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {schedule.startTime}
                          </span>
                        )}
                        {schedule.location && (
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {schedule.location}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {schedule.scheduleStatus === 'scheduled' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-green-600 hover:text-green-700"
                          onClick={() => handleCompleteSchedule(schedule.id)}
                          title="标记完成"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setDialogOpen(false);
                          router.push(`/schedules/${schedule.id}/edit`);
                        }}
                        title="编辑"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDeleteSchedule(schedule.id)}
                        title="删除"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Calendar className="h-12 w-12 text-muted-foreground/30 mb-3" />
                <p className="text-muted-foreground">暂无{getDialogTitle(dialogType)}</p>
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
