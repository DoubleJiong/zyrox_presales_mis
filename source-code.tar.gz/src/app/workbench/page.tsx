'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { WeeklyReportDialog } from '@/components/weekly-report-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useAuth } from '@/contexts/auth-context';
import {
  Calendar,
  CheckSquare,
  TrendingUp,
  Users,
  FileText,
  Briefcase,
  MessageSquare,
  Bell,
  Plus,
  ArrowRight,
  Clock,
  AlertCircle,
  Target,
  Lightbulb,
  Building2,
  Settings,
  Sparkles,
  FileSpreadsheet,
  DollarSign,
  Trophy,
  Star,
} from 'lucide-react';
import Link from 'next/link';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// 类型定义
interface Todo {
  id: number;
  title: string;
  type: string;
  priority: string;
  dueDate: string;
  dueTime: string;
  todoStatus: string;
  relatedName: string;
}

interface Schedule {
  id: number;
  title: string;
  type: string;
  startDate: string;
  startTime: string;
  location: string;
}

interface StarredProject {
  id: number;
  projectCode: string;
  projectName: string;
  customerName: string;
  status: string;
  progress: number;
}

interface WeeklyActivity {
  week: string;
  count: number;
}

interface Stats {
  pendingTodos: number;
  myTasks: number;
  myProjects: number;
  myBudget: number;
  myWinAmount: number;
}

// 动态项接口
interface Activity {
  id: string;
  type: string;
  action: string;
  title: string;
  description: string;
  actorId: number;
  actorName: string;
  actorAvatar?: string;
  relatedType?: string;
  relatedId?: number;
  relatedName?: string;
  createdAt: string;
  style?: {
    icon: string;
    color: string;
    bgColor: string;
  };
  timeAgo?: string;
}

// 获取动态类型图标
const getActivityIcon = (type: string) => {
  const iconMap: Record<string, React.ReactNode> = {
    opportunity: <TrendingUp className="h-4 w-4" />,
    project: <Briefcase className="h-4 w-4" />,
    followup: <Users className="h-4 w-4" />,
    quotation: <FileText className="h-4 w-4" />,
    approval: <CheckSquare className="h-4 w-4" />,
    system: <AlertCircle className="h-4 w-4" />,
    solution: <Lightbulb className="h-4 w-4" />,
    customer: <Building2 className="h-4 w-4" />,
  };
  return iconMap[type] || <AlertCircle className="h-4 w-4" />;
};

// 获取任务类型图标
const getTodoIcon = (type: string) => {
  const icons: Record<string, React.ReactNode> = {
    followup: <Users className="h-4 w-4" />,
    document: <FileText className="h-4 w-4" />,
    bidding: <Briefcase className="h-4 w-4" />,
    meeting: <Calendar className="h-4 w-4" />,
    approval: <CheckSquare className="h-4 w-4" />,
    other: <Target className="h-4 w-4" />,
  };
  return icons[type] || icons.other;
};

// 获取优先级样式
const getPriorityStyle = (priority: string) => {
  const styles: Record<string, string> = {
    urgent: 'bg-destructive/10 text-destructive border-destructive/20',
    high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    medium: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    low: 'bg-muted text-muted-foreground border-muted',
  };
  return styles[priority] || styles.medium;
};

// 获取日程类型图标
const getScheduleIcon = (type: string) => {
  const icons: Record<string, React.ReactNode> = {
    meeting: <Calendar className="h-4 w-4" />,
    visit: <Building2 className="h-4 w-4" />,
    call: <MessageSquare className="h-4 w-4" />,
    presentation: <Lightbulb className="h-4 w-4" />,
    other: <Clock className="h-4 w-4" />,
  };
  return icons[type] || icons.other;
};

// 获取动态跳转链接
const getActivityLink = (activity: Activity): string => {
  switch (activity.relatedType) {
    case 'project':
      return `/projects/${activity.relatedId}`;
    case 'customer':
      return `/customers/${activity.relatedId}`;
    case 'solution':
      return `/solutions/${activity.relatedId}`;
    case 'opportunity':
      return `/opportunities/${activity.relatedId}`;
    case 'task':
      return `/tasks?id=${activity.relatedId}`;
    default:
      return '#';
  }
};

// 格式化金额
const formatAmount = (amount: number): string => {
  if (amount >= 10000) {
    return `${(amount / 10000).toFixed(1)}万`;
  }
  return amount.toLocaleString();
};

export default function WorkbenchPage() {
  const { user, isAuthenticated } = useAuth();
  const [stats, setStats] = useState<Stats>({
    pendingTodos: 0,
    myTasks: 0,
    myProjects: 0,
    myBudget: 0,
    myWinAmount: 0,
  });
  const [todayTodos, setTodayTodos] = useState<Todo[]>([]);
  const [weekSchedules, setWeekSchedules] = useState<Schedule[]>([]);
  const [starredProjects, setStarredProjects] = useState<StarredProject[]>([]);
  const [weeklyActivities, setWeeklyActivities] = useState<WeeklyActivity[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [weeklyReportOpen, setWeeklyReportOpen] = useState(false);
  const [reportType, setReportType] = useState<'weekly' | 'monthly' | 'yearly'>('weekly');

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchWorkbenchData();
      fetchActivities();
    }
  }, [isAuthenticated, user]);

  const fetchActivities = async () => {
    try {
      const response = await fetch('/api/activities?limit=10');
      const result = await response.json();

      if (result.success) {
        setActivities(result.data.list);
      }
    } catch (error) {
      console.error('Failed to fetch activities:', error);
    }
  };

  const fetchWorkbenchData = async () => {
    try {
      const response = await fetch(`/api/workbench/summary`);
      const result = await response.json();

      if (result.success) {
        setStats(result.data.stats);
        setTodayTodos(result.data.todayTodos);
        setWeekSchedules(result.data.weekSchedules);
        setStarredProjects(result.data.starredProjects || []);
        setWeeklyActivities(result.data.weeklyProjectActivities || []);
      }
    } catch (error) {
      console.error('Failed to fetch workbench data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTodoComplete = async (todoId: number) => {
    try {
      await fetch(`/api/todos/${todoId}/complete`, {
        method: 'POST',
      });
      fetchWorkbenchData();
    } catch (error) {
      console.error('Failed to complete todo:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-80px)]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">工作台</h1>
          <p className="text-muted-foreground">欢迎回来，这是您的工作中心</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href="/messages">
              <Bell className="h-4 w-4 mr-2" />
              消息中心
            </Link>
          </Button>
          <Button size="sm" asChild>
            <Link href="/work-logs">
              <FileText className="h-4 w-4 mr-2" />
              工作日志
            </Link>
          </Button>
        </div>
      </div>

      {/* 统计卡片 - 5个 */}
      <div className="grid gap-3 grid-cols-2 md:grid-cols-5 md:gap-4">
        <Link href="/calendar" className="block">
          <Card className="md:col-span-1 cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 md:px-6">
              <CardTitle className="text-xs md:text-sm font-medium">待办事项</CardTitle>
              <CheckSquare className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="px-3 md:px-6">
              <div className="text-lg md:text-2xl font-bold">{stats.pendingTodos}</div>
              <p className="text-[10px] md:text-xs text-muted-foreground">个人待办 + 今日日程</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/my-tasks" className="block">
          <Card className="md:col-span-1 cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 md:px-6">
              <CardTitle className="text-xs md:text-sm font-medium">我的任务</CardTitle>
              <Target className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="px-3 md:px-6">
              <div className="text-lg md:text-2xl font-bold">{stats.myTasks}</div>
              <p className="text-[10px] md:text-xs text-muted-foreground">预警提醒 + 项目任务</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/projects" className="block">
          <Card className="md:col-span-1 cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 md:px-6">
              <CardTitle className="text-xs md:text-sm font-medium">我的项目</CardTitle>
              <Briefcase className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="px-3 md:px-6">
              <div className="text-lg md:text-2xl font-bold">{stats.myProjects}</div>
              <p className="text-[10px] md:text-xs text-muted-foreground">关联项目</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/projects" className="block">
          <Card className="md:col-span-1 cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 md:px-6">
              <CardTitle className="text-xs md:text-sm font-medium">我的预算</CardTitle>
              <DollarSign className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="px-3 md:px-6">
              <div className="text-lg md:text-2xl font-bold">{formatAmount(stats.myBudget)}</div>
              <p className="text-[10px] md:text-xs text-muted-foreground">预算总额</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/projects?bidResult=won" className="block">
          <Card className="md:col-span-1 cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-3 md:px-6">
              <CardTitle className="text-xs md:text-sm font-medium">我的中标</CardTitle>
              <Trophy className="h-3 w-3 md:h-4 md:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="px-3 md:px-6">
              <div className="text-lg md:text-2xl font-bold text-green-600">{formatAmount(stats.myWinAmount)}</div>
              <p className="text-[10px] md:text-xs text-muted-foreground">中标金额</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* 一键生成报告入口 */}
      <Card className="bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">一键生成报告</h3>
                <p className="text-sm text-muted-foreground">
                  基于工作日志和任务完成情况，自动生成报告
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Button
                className="flex-1 md:flex-none"
                onClick={() => {
                  setReportType('weekly');
                  setWeeklyReportOpen(true);
                }}
              >
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                周报
              </Button>
              <Button
                variant="outline"
                className="flex-1 md:flex-none"
                onClick={() => {
                  setReportType('monthly');
                  setWeeklyReportOpen(true);
                }}
              >
                月报
              </Button>
              <Button
                variant="outline"
                className="flex-1 md:flex-none"
                onClick={() => {
                  setReportType('yearly');
                  setWeeklyReportOpen(true);
                }}
              >
                年报
              </Button>
              <Button variant="outline" size="icon" asChild>
                <Link href="/work-logs">
                  <FileText className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 主要内容区域 */}
      <div className="grid gap-4 md:gap-6 lg:grid-cols-3">
        {/* 左侧：今日待办 */}
        <div className="lg:col-span-1 space-y-4 md:space-y-6">
          {/* 今日待办 */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">今日待办</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/calendar">
                  查看全部
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px]">
                {todayTodos.length > 0 ? (
                  <div className="space-y-3">
                    {todayTodos.map((todo) => (
                      <div
                        key={todo.id}
                        className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <Checkbox
                          id={`todo-${todo.id}`}
                          onCheckedChange={() => handleTodoComplete(todo.id)}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            {getTodoIcon(todo.type)}
                            <span className="font-medium truncate">{todo.title}</span>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className={`text-xs ${getPriorityStyle(todo.priority)}`}>
                              {todo.priority === 'urgent' ? '紧急' : todo.priority === 'high' ? '高' : todo.priority === 'medium' ? '中' : '低'}
                            </Badge>
                            {todo.dueTime && (
                              <span className="text-xs text-muted-foreground">
                                {todo.dueTime}
                              </span>
                            )}
                          </div>
                          {todo.relatedName && (
                            <p className="text-xs text-muted-foreground mt-1 truncate">
                              {todo.relatedName}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center py-8">
                    <CheckSquare className="h-12 w-12 text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">今日暂无待办</p>
                    <Button variant="link" size="sm" className="mt-2" asChild>
                      <Link href="/calendar">
                        <Plus className="h-4 w-4 mr-1" />
                        创建待办
                      </Link>
                    </Button>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* 重点项目 */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Star className="h-4 w-4 text-yellow-500" />
                重点项目
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/projects">
                  查看全部
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                {starredProjects.length > 0 ? (
                  <div className="space-y-3">
                    {starredProjects.map((project) => (
                      <Link
                        key={project.id}
                        href={`/projects/${project.id}`}
                        className="block p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium truncate">{project.projectName}</span>
                          <Badge variant="outline" className="text-xs">
                            {project.status === 'ongoing' ? '进行中' : project.status === 'completed' ? '已完成' : project.status}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between mt-2 text-sm">
                          <span className="text-muted-foreground truncate">{project.customerName}</span>
                          <span className="font-medium">{project.progress}%</span>
                        </div>
                        <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${project.progress}%` }}
                          />
                        </div>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center py-8">
                    <Star className="h-12 w-12 text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">暂无重点项目</p>
                    <Button variant="link" size="sm" className="mt-2" asChild>
                      <Link href="/projects">
                        <Plus className="h-4 w-4 mr-1" />
                        去标记重点项目
                      </Link>
                    </Button>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* 中间：本周日程 + 项目跟进 */}
        <div className="lg:col-span-1 space-y-6">
          {/* 本周日程 */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">本周日程</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/calendar">
                  查看全部
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px]">
                {weekSchedules.length > 0 ? (
                  <div className="space-y-3">
                    {weekSchedules.map((schedule) => (
                      <div
                        key={schedule.id}
                        className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          {getScheduleIcon(schedule.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{schedule.title}</p>
                          <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span>
                              {schedule.startDate}
                              {schedule.startTime && ` ${schedule.startTime}`}
                            </span>
                          </div>
                          {schedule.location && (
                            <p className="text-xs text-muted-foreground mt-1">
                              📍 {schedule.location}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center py-8">
                    <Calendar className="h-12 w-12 text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">本周暂无日程</p>
                    <Button variant="link" size="sm" className="mt-2" asChild>
                      <Link href="/calendar">
                        <Plus className="h-4 w-4 mr-1" />
                        创建日程
                      </Link>
                    </Button>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* 项目跟进折线图 */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">项目跟进</CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/projects">
                  查看全部
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                {weeklyActivities.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={weeklyActivities}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis 
                        dataKey="week" 
                        className="text-xs" 
                        tick={{ fill: 'hsl(var(--muted-foreground))' }}
                      />
                      <YAxis 
                        className="text-xs" 
                        tick={{ fill: 'hsl(var(--muted-foreground))' }}
                        allowDecimals={false}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                        }}
                        labelStyle={{ color: 'hsl(var(--foreground))' }}
                      />
                      <Line
                        type="monotone"
                        dataKey="count"
                        name="活跃项目"
                        stroke="hsl(var(--primary))"
                        strokeWidth={2}
                        dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    暂无数据
                  </div>
                )}
              </div>
              <p className="text-xs text-muted-foreground text-center mt-2">
                近12周项目活跃趋势
              </p>
            </CardContent>
          </Card>

          {/* 快捷入口 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">快捷入口</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/projects/new">
                    <Plus className="h-5 w-5" />
                    <span className="text-xs">新建项目</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/solutions/new">
                    <Lightbulb className="h-5 w-5" />
                    <span className="text-xs">新建方案</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/solutions">
                    <FileText className="h-5 w-5" />
                    <span className="text-xs">知识库</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/integrations">
                    <Settings className="h-5 w-5" />
                    <span className="text-xs">钉钉集成</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/schedules">
                    <Calendar className="h-5 w-5" />
                    <span className="text-xs">日程管理</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/calendar">
                    <CheckSquare className="h-5 w-5" />
                    <span className="text-xs">日历视图</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/messages">
                    <MessageSquare className="h-5 w-5" />
                    <span className="text-xs">消息中心</span>
                  </Link>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                  <Link href="/work-logs">
                    <FileText className="h-5 w-5" />
                    <span className="text-xs">工作日志</span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 最近动态 */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-base">最近动态</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                {activities.length > 0 ? (
                  <div className="space-y-4">
                    {activities.map((activity) => {
                      const link = getActivityLink(activity);
                      const isClickable = link !== '#';
                      
                      return (
                        <Link
                          key={activity.id}
                          href={isClickable ? link : '#'}
                          className={`flex gap-3 ${isClickable ? 'cursor-pointer hover:bg-accent/50 p-2 -m-2 rounded-lg transition-colors' : 'cursor-default'}`}
                        >
                          <div className={`w-8 h-8 rounded-full ${activity.style?.bgColor || 'bg-muted'} flex items-center justify-center flex-shrink-0`}>
                            {getActivityIcon(activity.type)}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">
                              <span className="font-medium">{activity.actorName}</span> {activity.action}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {activity.relatedName || activity.description} · {activity.timeAgo}
                            </p>
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center py-8">
                    <Bell className="h-12 w-12 text-muted-foreground/30 mb-3" />
                    <p className="text-muted-foreground">暂无动态</p>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 报告生成对话框 */}
      <WeeklyReportDialog 
        open={weeklyReportOpen} 
        onOpenChange={setWeeklyReportOpen} 
        reportType={reportType}
      />
    </div>
  );
}
