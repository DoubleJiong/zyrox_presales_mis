'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

/**
 * 知识库页面重定向
 * 知识库功能已融合到解决方案模块
 * 访问此页面会自动重定向到 /solutions?tab=knowledge
 */
export default function KnowledgeRedirectPage() {
  const router = useRouter();

  useEffect(() => {
    // 重定向到解决方案页面的知识库标签
    router.replace('/solutions?tab=knowledge');
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto text-muted-foreground" />
        <p className="mt-4 text-muted-foreground">正在跳转到知识库...</p>
      </div>
    </div>
  );
}
