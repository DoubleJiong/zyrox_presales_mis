'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { apiClient } from '@/lib/api-client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  AlertTriangle,
  Briefcase,
  Clock,
  CheckCircle,
  AlertCircle,
  Target,
  Calendar,
  User,
  Building2,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

// 任务类型
interface MyTask {
  id: string;
  type: 'alert' | 'assigned';
  title: string;
  description: string | null;
  status: string;
  priority?: string;
  severity?: string;
  progress?: number;
  startDate?: string | null;
  dueDate?: string | null;
  estimatedHours?: number | null;
  actualHours?: number | null;
  relatedType?: string | null;
  relatedId?: number | null;
  relatedName?: string;
  projectId?: number | null;
  projectName?: string;
  taskType?: string | null;
  ruleName?: string | null;
  createdAt: string;
}

// 统计类型
interface TaskStats {
  total: number;
  alertCount: number;
  assignedCount: number;
  pending: number;
  completed: number;
}

// 获取状态样式
const getStatusStyle = (status: string) => {
  const styles: Record<string, string> = {
    pending: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    in_progress: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    completed: 'bg-green-500/10 text-green-600 border-green-500/20',
    cancelled: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
  };
  return styles[status] || styles.pending;
};

// 获取状态标签
const getStatusLabel = (status: string) => {
  const labels: Record<string, string> = {
    pending: '待处理',
    in_progress: '进行中',
    completed: '已完成',
    cancelled: '已取消',
  };
  return labels[status] || '待处理';
};

// 获取严重程度样式
const getSeverityStyle = (severity: string) => {
  const styles: Record<string, string> = {
    critical: 'bg-red-500/10 text-red-600 border-red-500/20',
    high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    medium: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    low: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  };
  return styles[severity] || styles.medium;
};

// 获取严重程度标签
const getSeverityLabel = (severity: string) => {
  const labels: Record<string, string> = {
    critical: '紧急',
    high: '高',
    medium: '中',
    low: '低',
  };
  return labels[severity] || '中';
};

// 获取优先级样式
const getPriorityStyle = (priority: string) => {
  const styles: Record<string, string> = {
    urgent: 'bg-red-500/10 text-red-600 border-red-500/20',
    high: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    medium: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    low: 'bg-gray-500/10 text-gray-600 border-gray-500/20',
  };
  return styles[priority] || styles.medium;
};

// 获取优先级标签
const getPriorityLabel = (priority: string) => {
  const labels: Record<string, string> = {
    urgent: '紧急',
    high: '高',
    medium: '中',
    low: '低',
  };
  return labels[priority] || '中';
};

// 获取任务类型标签
const getTaskTypeLabel = (taskType: string) => {
  const labels: Record<string, string> = {
    development: '开发',
    design: '设计',
    testing: '测试',
    documentation: '文档',
    meeting: '会议',
    other: '其他',
  };
  return labels[taskType] || '其他';
};

export default function MyTasksPage() {
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [tasks, setTasks] = useState<MyTask[]>([]);
  const [stats, setStats] = useState<TaskStats>({
    total: 0,
    alertCount: 0,
    assignedCount: 0,
    pending: 0,
    completed: 0,
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    if (!authLoading && isAuthenticated && user) {
      fetchTasks();
    }
  }, [authLoading, isAuthenticated, user, activeTab]);

  const fetchTasks = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const typeParam = activeTab === 'all' ? 'all' : activeTab;
      const { data: result } = await apiClient.get<{
        success: boolean;
        data: {
          allTasks: MyTask[];
          stats: TaskStats;
        };
      }>(`/api/my-tasks?type=${typeParam}&status=all`);
      
      if (result.success) {
        setTasks(result.data.allTasks);
        setStats(result.data.stats);
      }
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  // 根据当前标签过滤任务
  const filteredTasks = tasks.filter(task => {
    if (activeTab === 'all') return true;
    if (activeTab === 'alert') return task.type === 'alert';
    if (activeTab === 'assigned') return task.type === 'assigned';
    return true;
  });

  // 渲染任务卡片
  const renderTaskCard = (task: MyTask) => {
    const isAlert = task.type === 'alert';
    
    return (
      <Card key={task.id} className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 space-y-2">
              {/* 标题和类型标识 */}
              <div className="flex items-center gap-2">
                {isAlert ? (
                  <AlertTriangle className="h-4 w-4 text-orange-500" />
                ) : (
                  <Briefcase className="h-4 w-4 text-blue-500" />
                )}
                <span className="font-medium">{task.title}</span>
                <Badge variant="outline" className={isAlert ? 'bg-orange-500/10 text-orange-600' : 'bg-blue-500/10 text-blue-600'}>
                  {isAlert ? '预警任务' : '指派任务'}
                </Badge>
              </div>
              
              {/* 描述 */}
              {task.description && (
                <p className="text-sm text-muted-foreground line-clamp-2">{task.description}</p>
              )}
              
              {/* 关联信息 */}
              <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                {isAlert ? (
                  <>
                    {task.ruleName && (
                      <span className="flex items-center gap-1">
                        <Target className="h-3 w-3" />
                        {task.ruleName}
                      </span>
                    )}
                    {task.relatedName && (
                      <span className="flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        {task.relatedName}
                      </span>
                    )}
                  </>
                ) : (
                  <>
                    {task.taskType && (
                      <Badge variant="outline" className="text-xs">{getTaskTypeLabel(task.taskType)}</Badge>
                    )}
                    {task.projectName && (
                      <span className="flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        {task.projectName}
                      </span>
                    )}
                    {task.dueDate && (
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        截止: {format(new Date(task.dueDate), 'MM-dd', { locale: zhCN })}
                      </span>
                    )}
                    {task.progress !== undefined && task.progress > 0 && (
                      <span className="flex items-center gap-1">
                        进度: {task.progress}%
                      </span>
                    )}
                  </>
                )}
              </div>
            </div>
            
            {/* 右侧状态和操作 */}
            <div className="flex flex-col items-end gap-2">
              {isAlert && task.severity && (
                <Badge variant="outline" className={getSeverityStyle(task.severity)}>
                  {getSeverityLabel(task.severity)}
                </Badge>
              )}
              {!isAlert && task.priority && (
                <Badge variant="outline" className={getPriorityStyle(task.priority)}>
                  {getPriorityLabel(task.priority)}
                </Badge>
              )}
              <Badge variant="outline" className={getStatusStyle(task.status)}>
                {getStatusLabel(task.status)}
              </Badge>
              
              {/* 跳转按钮 */}
              {task.relatedId && (
                <Button variant="ghost" size="sm" asChild>
                  <Link href={isAlert ? `/alerts/${task.relatedId}` : `/tasks/${task.id.replace('assigned-', '')}`}>
                    查看详情
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">分配给我的任务</h1>
          <p className="text-muted-foreground">查看预警任务和领导指派的项目任务。</p>
          <p className="text-xs text-muted-foreground mt-1">
            💡 此页面仅显示分配给您的任务，<Link href="/tasks" className="text-primary hover:underline">项目任务管理</Link>页面显示所有项目任务。
            <Link href="/workbench" className="text-primary hover:underline ml-1">前往工作台查看待办和日程 →</Link>
          </p>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">全部任务</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">预警任务</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.alertCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">指派任务</CardTitle>
            <Briefcase className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.assignedCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">待处理</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          </CardContent>
        </Card>
      </div>

      {/* 任务列表 */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">全部任务</TabsTrigger>
          <TabsTrigger value="alert">预警任务</TabsTrigger>
          <TabsTrigger value="assigned">指派任务</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredTasks.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>暂无任务</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredTasks.map(renderTaskCard)}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
