'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import * as echarts from 'echarts';
import ChinaMap from '@/components/china-map';
import { MapPin } from 'lucide-react';

interface Stats {
  totalCustomers: number;
  totalProjects: number;
  totalSchemes: number;
  totalStaff: number;
  conversionRate: number;
  avgProjectDuration: number;
  totalRevenue: number;
  avgSatisfaction: number;
}

interface MonthlyData {
  month: string;
  customers: number;
  projects: number;
  revenue: number;
}

export default function DashboardScreenPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [mapType, setMapType] = useState<'customers' | 'projects'>('customers');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api/dashboard/stats');
      if (response.ok) {
        const result = await response.json();
        // API 返回格式: { success: true, data: {...} } 或直接返回数据
        const data = result.data || result;
        setStats(data.stats);
        setMonthlyData(data.monthlyData || []);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // 生成模拟数据
  const generateMockData = () => {
    return [
      { month: '1月', customers: 12, projects: 8, revenue: 120000 },
      { month: '2月', customers: 15, projects: 10, revenue: 150000 },
      { month: '3月', customers: 18, projects: 12, revenue: 180000 },
      { month: '4月', customers: 22, projects: 15, revenue: 220000 },
      { month: '5月', customers: 25, projects: 18, revenue: 250000 },
      { month: '6月', customers: 28, projects: 20, revenue: 280000 },
    ];
  };

  // 项目类型分布数据
  const projectTypeData = [
    { value: 45, name: '软件系统' },
    { value: 25, name: '硬件设备' },
    { value: 20, name: '咨询服务' },
    { value: 10, name: '集成项目' },
  ];

  // 区域分布数据
  const regionData = [
    { value: 35, name: '华东' },
    { value: 25, name: '华南' },
    { value: 20, name: '华北' },
    { value: 12, name: '华中' },
    { value: 5, name: '西南' },
    { value: 3, name: '西北' },
  ];

  // 月度业务趋势图配置
  const monthlyTrendOption: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(255, 255, 255, 0.98)',
      borderColor: '#e5e7eb',
      textStyle: { color: '#1f2937' }
    },
    legend: {
      data: ['新增客户', '新建项目', '营收'],
      top: 10,
      textStyle: { color: '#4b5563' }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: (monthlyData.length > 0 ? monthlyData : generateMockData()).map(d => d.month),
      axisLine: { lineStyle: { color: '#d1d5db' } },
      axisLabel: { color: '#6b7280' }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#d1d5db' } },
      axisLabel: { color: '#6b7280' },
      splitLine: { lineStyle: { color: '#e5e7eb', type: 'dashed' } }
    },
    series: [
      {
        name: '新增客户',
        type: 'line',
        data: (monthlyData.length > 0 ? monthlyData : generateMockData()).map(d => d.customers),
        smooth: true,
        lineStyle: { width: 3, color: '#3b82f6' },
        itemStyle: { color: '#3b82f6' },
        areaStyle: {
          color: new (echarts as any).graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(59, 130, 246, 0.3)' },
            { offset: 1, color: 'rgba(59, 130, 246, 0)' }
          ])
        }
      },
      {
        name: '新建项目',
        type: 'line',
        data: (monthlyData.length > 0 ? monthlyData : generateMockData()).map(d => d.projects),
        smooth: true,
        lineStyle: { width: 3, color: '#10b981' },
        itemStyle: { color: '#10b981' },
        areaStyle: {
          color: new (echarts as any).graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(16, 185, 129, 0.3)' },
            { offset: 1, color: 'rgba(16, 185, 129, 0)' }
          ])
        }
      },
      {
        name: '营收',
        type: 'line',
        data: (monthlyData.length > 0 ? monthlyData : generateMockData()).map(d => d.revenue / 10000),
        smooth: true,
        lineStyle: { width: 3, color: '#f59e0b' },
        itemStyle: { color: '#f59e0b' }
      }
    ]
  };

  // 项目类型分布图配置
  const projectTypeOption: EChartsOption = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)',
      backgroundColor: 'rgba(255, 255, 255, 0.98)',
      borderColor: '#e5e7eb',
      textStyle: { color: '#1f2937' }
    },
    legend: {
      orient: 'vertical',
      right: '10%',
      top: 'center',
      textStyle: { color: '#4b5563' }
    },
    series: [
      {
        name: '项目类型',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#ffffff',
          borderWidth: 2
        },
        label: {
          show: false,
          position: 'center'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 20,
            fontWeight: 'bold',
            color: '#1f2937'
          }
        },
        labelLine: {
          show: false
        },
        data: projectTypeData,
        color: ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6']
      }
    ]
  };

  // 客户转化率配置
  const conversionOption: EChartsOption = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c}% ({d}%)',
      backgroundColor: 'rgba(255, 255, 255, 0.98)',
      borderColor: '#e5e7eb',
      textStyle: { color: '#1f2937' }
    },
    series: [
      {
        name: '客户转化',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 10,
          borderColor: '#ffffff',
          borderWidth: 2
        },
        label: {
          show: true,
          formatter: '{b}: {c}%',
          color: '#1f2937'
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 16,
            fontWeight: 'bold',
            color: '#1f2937'
          }
        },
        data: [
          { value: stats?.conversionRate || 0, name: '客户转化', itemStyle: { color: '#3b82f6' } },
          { value: 100 - (stats?.conversionRate || 0), name: '客户未转化', itemStyle: { color: '#d1d5db' } }
        ]
      }
    ]
  };

  // 区域分布图配置
  const regionOption: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: 'rgba(255, 255, 255, 0.98)',
      borderColor: '#e5e7eb',
      textStyle: { color: '#1f2937' }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: regionData.map(d => d.name),
      axisLine: { lineStyle: { color: '#d1d5db' } },
      axisLabel: { color: '#6b7280' }
    },
    yAxis: {
      type: 'value',
      axisLine: { lineStyle: { color: '#d1d5db' } },
      axisLabel: { color: '#6b7280' },
      splitLine: { lineStyle: { color: '#e5e7eb', type: 'dashed' } }
    },
    series: [
      {
        name: '客户数',
        type: 'bar',
        data: regionData.map(d => d.value),
        itemStyle: {
          color: new (echarts as any).graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#8b5cf6' },
            { offset: 1, color: '#6366f1' }
          ]),
          borderRadius: [5, 5, 0, 0]
        }
      }
    ]
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-lg text-foreground">加载中...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6 bg-background min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">数据大屏</h1>
        <p className="text-muted-foreground">实时监控业务数据</p>
      </div>

      {/* 核心指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">客户总数</CardTitle>
            <div className="h-4 w-4 rounded bg-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.totalCustomers || 0}</div>
            <p className="text-xs text-muted-foreground">较上月 +12%</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">项目总数</CardTitle>
            <div className="h-4 w-4 rounded bg-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.totalProjects || 0}</div>
            <p className="text-xs text-muted-foreground">较上月 +8%</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">方案总数</CardTitle>
            <div className="h-4 w-4 rounded bg-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.totalSchemes || 0}</div>
            <p className="text-xs text-muted-foreground">较上月 +15%</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">人员总数</CardTitle>
            <div className="h-4 w-4 rounded bg-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.totalStaff || 0}</div>
            <p className="text-xs text-muted-foreground">较上月 +5%</p>
          </CardContent>
        </Card>
      </div>

      {/* 第二排指标 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">客户转化率</CardTitle>
            <div className="h-4 w-4 rounded bg-cyan-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.conversionRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">较上月 +3.2%</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">平均项目周期</CardTitle>
            <div className="h-4 w-4 rounded bg-pink-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.avgProjectDuration || 0} 天</div>
            <p className="text-xs text-muted-foreground">较上月 -5天</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">总营收</CardTitle>
            <div className="h-4 w-4 rounded bg-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{formatAmount(stats?.totalRevenue || 0)}</div>
            <p className="text-xs text-muted-foreground">较上月 +18%</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">客户满意度</CardTitle>
            <div className="h-4 w-4 rounded bg-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats?.avgSatisfaction.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">较上月 +1.5%</p>
          </CardContent>
        </Card>
      </div>

      {/* 中国地图 - 显眼位置 */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="h-6 w-6 text-blue-600" />
              <div>
                <CardTitle className="text-xl text-foreground">全国业务分布地图</CardTitle>
                <CardDescription className="text-muted-foreground">实时查看各地区客户和项目分布情况</CardDescription>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setMapType('customers')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  mapType === 'customers'
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30 scale-105'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                }`}
              >
                客户分布
              </button>
              <button
                onClick={() => setMapType('projects')}
                className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  mapType === 'projects'
                    ? 'bg-green-600 text-white shadow-lg shadow-green-500/30 scale-105'
                    : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                }`}
              >
                项目分布
              </button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ChinaMap type={mapType} height="600px" />
        </CardContent>
      </Card>

      {/* 图表区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 月度趋势图 */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-foreground">月度业务趋势</CardTitle>
            <CardDescription className="text-muted-foreground">客户、项目、营收月度变化</CardDescription>
          </CardHeader>
          <CardContent>
            <ReactECharts option={monthlyTrendOption} style={{ height: '300px' }} />
          </CardContent>
        </Card>

        {/* 项目类型分布 */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-foreground">项目类型分布</CardTitle>
            <CardDescription className="text-muted-foreground">各类项目占比情况</CardDescription>
          </CardHeader>
          <CardContent>
            <ReactECharts option={projectTypeOption} style={{ height: '300px' }} />
          </CardContent>
        </Card>

        {/* 区域分布 */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-foreground">区域客户分布</CardTitle>
            <CardDescription className="text-muted-foreground">各地区客户数量统计</CardDescription>
          </CardHeader>
          <CardContent>
            <ReactECharts option={regionOption} style={{ height: '300px' }} />
          </CardContent>
        </Card>

        {/* 客户转化率 */}
        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-foreground">客户转化率</CardTitle>
            <CardDescription className="text-muted-foreground">客户转化与未转化比例</CardDescription>
          </CardHeader>
          <CardContent>
            <ReactECharts option={conversionOption} style={{ height: '300px' }} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
