'use client';

import { useState, useEffect, useCallback } from 'react';
import { TechMapChart } from '@/components/dashboard/TechMapChart';
import { HeatmapTopRank } from '@/components/dashboard/HeatmapTopRank';
import { HeatmapDimensionSwitcher } from '@/components/dashboard/HeatmapDimensionSwitcher';
import { LiveClock } from '@/components/dashboard/LiveClock';
import { 
  SalesPanel, CustomersPanel, ProjectsPanel, SolutionsPanel, 
  RealTimeDataPanel, QuickStatsPanel, RegionDetailPanel 
} from '@/components/dashboard/DataPanels';
import { MapDataType, MapRegionData } from '@/lib/map-types';
import { 
  Hexagon, RefreshCw, MapPin, ArrowLeft, Globe,
  UserCog, Users, FolderKanban, FileText, X, Loader2
} from 'lucide-react';
import * as echarts from 'echarts';
import ReactECharts from 'echarts-for-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  useDataScreen,
  OverviewData,
  HeatmapData,
  HeatmapRegionData as ApiHeatmapRegionData,
  StreamMessage,
  RankItem
} from '@/hooks/use-data-screen-optimized';
import { usePanelData, SalesPanelData, CustomersPanelData, ProjectsPanelData, SolutionsPanelData } from '@/hooks/use-panel-data';

import {
  transformOverviewData,
  transformHeatmapData,
  transformStreamData,
  transformRankingsData,
  formatTime,
  formatAmount,
  getHeatmapConfig,
  PROVINCES,
  REGION_GROUPS,
  ZHEJIANG_CITIES,
} from '@/lib/data-screen-utils';

type PanelType = 'sales' | 'customers' | 'projects' | 'solutions' | null;

// 将 API 数据转换为 MapRegionData 格式
function convertToMapRegionData(regions: ApiHeatmapRegionData[]): MapRegionData[] {
  return regions.map(region => ({
    name: region.name,
    customerCount: region.customerCount,
    projectCount: region.projectCount,
    projectAmount: region.projectAmount,
    ongoingProjectAmount: region.ongoingProjectAmount,
    hasCustomerAlert: region.hasCustomerAlert,
    hasProjectAlert: region.hasProjectAlert,
    hasUserAlert: region.hasUserAlert,
    solutionUsage: region.solutionUsage,
    preSalesActivity: region.preSalesActivity,
    budget: region.budget,
    contractAmount: region.contractAmount,
  }));
}

export default function DataScreenPage() {
  // ==================== 数据获取 ====================
  const {
    overview,
    stream,
    heatmap,
    rankings,
    isLoading: isDataLoading,
    error: dataError,
    lastRefresh,
    refreshAll,
    fetchHeatmap,
    fetchRankings,
  } = useDataScreen({
    autoRefresh: true,
    refreshInterval: 5 * 60 * 1000,
  });

  // ==================== 全局状态 ====================
  const [currentMapType, setCurrentMapType] = useState<'province-outside' | 'zhejiang'>('province-outside');
  const [selectedRegion, setSelectedRegion] = useState<MapRegionData | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [activePanel, setActivePanel] = useState<PanelType>(null);
  
  // 地图下钻状态
  const [mapLevel, setMapLevel] = useState<'nation' | 'province'>('nation');
  const [currentProvince, setCurrentProvince] = useState<string | null>(null);
  
  // 全局控件状态
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [heatmapMode, setHeatmapMode] = useState<'customer' | 'project' | 'budget' | 'contract' | 'activity' | 'solution'>('customer');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastRefreshTime, setLastRefreshTime] = useState<Date | null>(null);
  const [isMounted, setIsMounted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // 时间范围选择 - 使用空字符串作为初始值，避免 hydration 错误
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  
  // 全局数据统计模块：当前选中的子模块
  const [globalStatsTab, setGlobalStatsTab] = useState<'sales' | 'customers' | 'projects' | 'solutions'>('sales');

  // 面板数据获取
  const salesPanelData = usePanelData<SalesPanelData>({ panelType: 'sales', startDate, endDate });
  const customersPanelData = usePanelData<CustomersPanelData>({ panelType: 'customers', startDate, endDate });
  const projectsPanelData = usePanelData<ProjectsPanelData>({ panelType: 'projects', startDate, endDate });
  const solutionsPanelData = usePanelData<SolutionsPanelData>({ panelType: 'solutions', startDate, endDate });

  // 热力图数据
  const [heatmapRegionData, setHeatmapRegionData] = useState<MapRegionData[]>([]);

  // 更新热力图数据
  useEffect(() => {
    if (heatmap?.success && heatmap.data.regions) {
      setHeatmapRegionData(convertToMapRegionData(heatmap.data.regions));
    } else {
      // 如果没有数据，使用默认数据
      setHeatmapRegionData(getDefaultProvinceData());
    }
  }, [heatmap]);

  // 当 heatmapMode 变化时，重新获取热力图数据
  useEffect(() => {
    if (isMounted) {
      // 直接调用 API 获取热力图数据
      const fetchHeatmapData = async () => {
        try {
          const params = new URLSearchParams();
          params.set('mode', heatmapMode);
          if (startDate) params.set('startDate', startDate);
          if (endDate) params.set('endDate', endDate);

          const response = await fetch(`/api/data-screen/heatmap?${params.toString()}`);
          const data = await response.json();
          
          if (data.success && data.data.regions) {
            setHeatmapRegionData(convertToMapRegionData(data.data.regions));
          }
        } catch (error) {
          console.error('Failed to fetch heatmap data:', error);
        }
      };
      
      fetchHeatmapData();
    }
  }, [heatmapMode, isMounted, startDate, endDate]);

  // 获取默认省份数据
  function getDefaultProvinceData(): MapRegionData[] {
    return PROVINCES.map(name => ({
      name,
      customerCount: 0,
      projectCount: 0,
      projectAmount: 0,
      ongoingProjectAmount: 0,
      solutionUsage: 0,
      preSalesActivity: 0,
      budget: 0,
      contractAmount: 0,
    }));
  }

  // 获取当前地图数据
  const getCurrentMapData = (): MapRegionData[] => {
    if (currentMapType === 'province-outside') {
      return heatmapRegionData.length > 0 ? heatmapRegionData : getDefaultProvinceData();
    }
    // 浙江地图数据
    return getZhejiangMapData();
  };

  // 获取浙江地图数据
  function getZhejiangMapData(): MapRegionData[] {
    return ZHEJIANG_CITIES.map(name => ({
      name,
      customerCount: 0,
      projectCount: 0,
      projectAmount: 0,
      ongoingProjectAmount: 0,
      solutionUsage: 0,
      preSalesActivity: 0,
      budget: 0,
      contractAmount: 0,
    }));
  }

  // 全屏切换
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch((err) => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      }).catch((err) => {
        console.error(`Error attempting to exit fullscreen: ${err.message}`);
      });
    }
  };

  // 监听全屏变化
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // 确保客户端渲染后才加载数据，避免 hydration 错误
  useEffect(() => {
    setIsMounted(true);
    // 初始化日期值
    const now = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    setStartDate(thirtyDaysAgo.toISOString().split('T')[0]);
    setEndDate(now.toISOString().split('T')[0]);
    setLastRefreshTime(now);
  }, []);

  const getMapDataTypeByHeatmapMode = (): MapDataType => {
    switch (heatmapMode) {
      case 'customer': return MapDataType.CUSTOMER_COUNT_HEATMAP;
      case 'project': return MapDataType.PROJECT_COUNT_HEATMAP;
      case 'budget': return MapDataType.BUDGET;
      case 'contract': return MapDataType.CONTRACT_AMOUNT;
      case 'activity': return MapDataType.PRE_SALES_ACTIVITY;
      case 'solution': return MapDataType.SOLUTION_USAGE;
      default: return MapDataType.CUSTOMER_COUNT_HEATMAP;
    }
  };

  // 获取当前热力图维度的配置
  const getHeatmapConfigLocal = () => {
    return getHeatmapConfig(heatmapMode);
  };

  const handleDrillDown = (regionName: string) => {
    if (regionName === '浙江') {
      setCurrentMapType('zhejiang');
      setMapLevel('province');
      setCurrentProvince('浙江');
      setSelectedRegion(null);
      // 直接调用 API
      fetch(`/api/data-screen/heatmap?mode=zhejiang`)
        .then(res => res.json())
        .then(data => {
          if (data.success && data.data.regions) {
            setHeatmapRegionData(convertToMapRegionData(data.data.regions));
          }
        });
    }
  };

  const handleGoBack = () => {
    setCurrentMapType('province-outside');
    setMapLevel('nation');
    setCurrentProvince(null);
    setSelectedRegion(null);
    // 直接调用 API
    const params = new URLSearchParams();
    params.set('mode', heatmapMode);
    fetch(`/api/data-screen/heatmap?${params.toString()}`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.data.regions) {
          setHeatmapRegionData(convertToMapRegionData(data.data.regions));
        }
      });
  };

  // ==================== 自动刷新 ====================
  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(() => {
        setLastRefreshTime(new Date());
        refreshAll();
      }, 5 * 60 * 1000);
      return () => clearInterval(interval);
    }
  }, [autoRefresh, refreshAll]);

  // ==================== 入场动画 ====================
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  // ==================== 样式配置 ====================
  const techCardStyle = {
    background: 'rgba(15, 25, 40, 0.75)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(0, 212, 255, 0.25)',
    borderRadius: '8px',
    boxShadow: '0 4px 20px rgba(0, 212, 255, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.08)',
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0A0F1A',
      padding: 0,
      position: 'relative',
      fontFamily: '"JetBrains Mono", monospace',
      overflow: 'hidden',
      color: '#FFFFFF',
    }}>
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap');
          * { box-sizing: border-box; }
          #particle-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            pointer-events: none;
          }
          .hex-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            background: 
              radial-gradient(ellipse at center, rgba(0, 212, 255, 0.02) 0%, transparent 70%),
              linear-gradient(180deg, rgba(0, 0, 0, 0.3) 0%, rgba(0, 0, 0, 0.5) 100%);
            pointer-events: none;
          }
          .tech-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            background-image: 
              linear-gradient(rgba(0, 212, 255, 0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 212, 255, 0.03) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: gridMove 20s linear infinite;
            pointer-events: none;
          }
          @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
          }
          .scan-line {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(0, 212, 255, 0.3), transparent);
            z-index: 2;
            animation: scanLine 8s linear infinite;
            pointer-events: none;
          }
          @keyframes scanLine {
            0% { top: -2px; }
            100% { top: 100%; }
          }
          .data-stream {
            position: fixed;
            z-index: 2;
            pointer-events: none;
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px;
            color: rgba(0, 212, 255, 0.15);
            white-space: nowrap;
            animation: dataStream linear infinite;
          }
          @keyframes dataStream {
            0% { transform: translateY(-100%); }
            100% { transform: translateY(100vh); }
          }
          .pulse-ring {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 1000px;
            height: 1000px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(0, 212, 255, 0.08) 0%, transparent 70%);
            z-index: 2;
            animation: pulseRing 4s ease-in-out infinite;
            pointer-events: none;
          }
          @keyframes pulseRing {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.3; }
            50% { transform: translate(-50%, -50%) scale(1.1); opacity: 0.5; }
          }
          .fade-in {
            animation: fadeIn 0.5s ease-out forwards;
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
          }
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
          .slide-in-right {
            animation: slideInRight 0.3s ease-out forwards;
          }
          @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
          ::-webkit-scrollbar {
            width: 4px;
          }
          ::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.3);
          }
          ::-webkit-scrollbar-thumb {
            background: rgba(0, 212, 255, 0.5);
            border-radius: 2px;
          }
        `}
      </style>

      {/* 动态背景 */}
      <canvas id="particle-canvas" />
      <div className="hex-grid" />
      <div className="tech-grid" />
      <div className="scan-line" />
      <div className="pulse-ring" />
      
      {/* 数据流粒子 - 仅客户端渲染 */}
      {isMounted && (
        <>
          {[...Array(8)].map((_, i) => (
            <div 
              key={i}
              className="data-stream"
              style={{
                left: `${10 + i * 12}%`,
                animationDuration: `${15 + Math.random() * 10}s`,
                animationDelay: `${Math.random() * 5}s`
              }}
            >
              {Array(20).fill(0).map((_, j) => (
                <div key={j} style={{ opacity: 0.3 + Math.random() * 0.4 }}>
                  {Math.random().toString(16).substr(2, 8)}
                </div>
              ))}
            </div>
          ))}
        </>
      )}

      {/* 主容器 */}
      <div className="relative z-10 flex h-full w-full flex-col" style={{ height: '100vh' }}>
        {/* 加载状态 */}
        {!isLoaded && (
          <div className="fixed inset-0 z-9999 flex items-center justify-center" style={{ background: '#0A0F1A' }}>
            <div style={{
              width: '60px',
              height: '60px',
              border: '4px solid rgba(0, 212, 255, 0.2)',
              borderTopColor: '#00D4FF',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
            }} />
            <p style={{ 
              color: '#00D4FF', 
              fontSize: '16px', 
              marginTop: '20px',
              fontFamily: '"JetBrains Mono", monospace',
              fontWeight: '600' 
            }}>
              正在初始化数据大屏...
            </p>
          </div>
        )}

        {/* 顶部工具栏 */}
        <div style={{
          height: '60px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 20px',
          background: 'rgba(10, 15, 26, 0.9)',
          border: '1px solid rgba(0, 212, 255, 0.3)',
          zIndex: 100,
          opacity: isLoaded ? 1 : 0,
          animation: isLoaded ? 'fadeIn 0.5s ease-out forwards' : 'none',
        }}>
          {/* 左侧：标题和面包屑 */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Hexagon size={28} style={{ color: '#00D4FF' }} />
            <div>
              <h1 style={{
                fontFamily: '"JetBrains Mono", monospace',
                color: '#FFFFFF',
                fontSize: '18px',
                fontWeight: '700',
                margin: 0,
                letterSpacing: '2px',
              }}>
                <span style={{ color: '#00D4FF' }}>DOUBLEJIONG</span> DATA HUB
              </h1>
              {/* 地图切换按钮 */}
              <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
                <button
                  onClick={() => {
                    setCurrentMapType('province-outside');
                    setMapLevel('nation');
                    setCurrentProvince(null);
                    setSelectedRegion(null);
                  }}
                  style={{
                    padding: '4px 12px',
                    border: currentMapType === 'province-outside' ? '1px solid #00D4FF' : '1px solid rgba(0, 212, 255, 0.2)',
                    background: currentMapType === 'province-outside' ? 'rgba(0, 212, 255, 0.2)' : 'rgba(0, 212, 255, 0.05)',
                    color: currentMapType === 'province-outside' ? '#00D4FF' : 'rgba(255,255,255,0.6)',
                    fontSize: '11px',
                    borderRadius: '4px',
                    fontFamily: '"JetBrains Mono", monospace',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                >
                  <Globe size={10} style={{ display: 'inline', marginRight: '4px', verticalAlign: 'middle' }} />
                  全国
                </button>
                <button
                  onClick={() => {
                    setCurrentMapType('zhejiang');
                    setMapLevel('province');
                    setCurrentProvince('浙江');
                    setSelectedRegion(null);
                  }}
                  style={{
                    padding: '4px 12px',
                    border: currentMapType === 'zhejiang' ? '1px solid #00FF88' : '1px solid rgba(0, 255, 136, 0.2)',
                    background: currentMapType === 'zhejiang' ? 'rgba(0, 255, 136, 0.2)' : 'rgba(0, 255, 136, 0.05)',
                    color: currentMapType === 'zhejiang' ? '#00FF88' : 'rgba(255,255,255,0.6)',
                    fontSize: '11px',
                    borderRadius: '4px',
                    fontFamily: '"JetBrains Mono", monospace',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                >
                  <MapPin size={10} style={{ display: 'inline', marginRight: '4px', verticalAlign: 'middle' }} />
                  浙江省
                </button>
              </div>
            </div>
          </div>

          {/* 中间：标题 */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            flex: 1,
          }}>
            <h1 style={{
              fontFamily: '"JetBrains Mono", monospace',
              color: '#00D4FF',
              fontSize: '16px',
              fontWeight: '700',
              margin: 0,
              letterSpacing: '2px',
              textTransform: 'uppercase',
            }}>
              双江数据大屏
            </h1>
          </div>

          {/* 右侧：时间控件和刷新 */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {/* 全屏按钮 */}
            <button
              onClick={toggleFullscreen}
              style={{
                padding: '5px 12px',
                border: isFullscreen ? '1px solid #00D4FF' : '1px solid rgba(0, 212, 255, 0.3)',
                background: isFullscreen ? 'rgba(0, 212, 255, 0.2)' : 'rgba(0, 0, 0, 0.3)',
                color: isFullscreen ? '#00D4FF' : 'rgba(255,255,255,0.7)',
                fontSize: '11px',
                borderRadius: '4px',
                fontFamily: '"JetBrains Mono", monospace',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                transition: 'all 0.2s ease',
              }}
              title={isFullscreen ? '退出全屏' : '全屏显示'}
            >
              {isFullscreen ? (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/>
                </svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>
                </svg>
              )}
              {isFullscreen ? '退出全屏' : '全屏'}
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 12px', border: '1px solid rgba(0, 212, 255, 0.3)', borderRadius: '4px', background: 'rgba(0, 0, 0, 0.3)' }}>
              <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '11px', fontFamily: '"JetBrains Mono", monospace' }}>统计范围:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                style={{
                  padding: '2px 6px',
                  border: '1px solid rgba(0, 212, 255, 0.3)',
                  background: 'rgba(0, 0, 0, 0.5)',
                  color: '#FFFFFF',
                  fontSize: '11px',
                  borderRadius: '3px',
                  fontFamily: '"JetBrains Mono", monospace',
                  cursor: 'pointer',
                }}
              />
              <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '12px' }}>至</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                style={{
                  padding: '2px 6px',
                  border: '1px solid rgba(0, 212, 255, 0.3)',
                  background: 'rgba(0, 0, 0, 0.5)',
                  color: '#FFFFFF',
                  fontSize: '11px',
                  borderRadius: '3px',
                  fontFamily: '"JetBrains Mono", monospace',
                  cursor: 'pointer',
                }}
              />
            </div>
            <button
              onClick={() => setAutoRefresh(!autoRefresh)}
              style={{
                padding: '5px 12px',
                border: autoRefresh ? '1px solid #00FF88' : '1px solid rgba(0, 255, 136, 0.2)',
                background: autoRefresh ? 'rgba(0, 255, 136, 0.2)' : 'transparent',
                color: autoRefresh ? '#00FF88' : 'rgba(255,255,255,0.7)',
                fontSize: '11px',
                borderRadius: '4px',
                fontFamily: '"JetBrains Mono", monospace',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              <RefreshCw size={12} style={{ animation: autoRefresh ? 'spin 1s linear infinite' : 'none' }} />
              自动
            </button>
            <LiveClock />
          </div>
        </div>

        {/* 主内容区域 - 两列布局 */}
        <div style={{
          flex: 1,
          display: 'flex',
          zIndex: 10,
          opacity: isLoaded ? 1 : 0,
          animation: isLoaded ? 'fadeIn 0.5s ease-out 0.1s forwards' : 'none',
          height: 'calc(100vh - 60px)',
          overflow: 'hidden',
        }}>
          {/* 左侧：全局数据统计 */}
          <div style={{
            width: '380px',
            minWidth: '380px',
            background: 'rgba(10, 15, 26, 0.95)',
            border: '1px solid rgba(0, 212, 255, 0.2)',
            borderRight: 'none',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}>
            {/* 标题 */}
            <div style={{
              padding: '12px 16px',
              borderBottom: '1px solid rgba(0, 212, 255, 0.2)',
              background: 'rgba(0, 212, 255, 0.1)',
            }}>
              <h2 style={{
                color: '#00D4FF',
                fontSize: '14px',
                fontWeight: '700',
                fontFamily: '"JetBrains Mono", monospace',
                margin: 0,
                letterSpacing: '1px',
              }}>
                全局数据统计
              </h2>
            </div>
            
            {/* 子模块标签切换 */}
            <div style={{
              display: 'flex',
              gap: '4px',
              padding: '8px',
              borderBottom: '1px solid rgba(0, 212, 255, 0.15)',
            }}>
              {[
                { key: 'sales', label: '售前数据', icon: UserCog },
                { key: 'customers', label: '客户数据', icon: Users },
                { key: 'projects', label: '项目数据', icon: FolderKanban },
                { key: 'solutions', label: '方案数据', icon: FileText },
              ].map((item) => (
                <button
                  key={item.key}
                  onClick={() => setGlobalStatsTab(item.key as any)}
                  style={{
                    flex: 1,
                    padding: '6px 4px',
                    border: globalStatsTab === item.key ? '1px solid #00D4FF' : '1px solid rgba(0, 212, 255, 0.2)',
                    background: globalStatsTab === item.key ? 'rgba(0, 212, 255, 0.2)' : 'rgba(0, 0, 0, 0.3)',
                    color: globalStatsTab === item.key ? '#00D4FF' : 'rgba(255,255,255,0.7)',
                    fontSize: '10px',
                    borderRadius: '4px',
                    fontFamily: '"JetBrains Mono", monospace',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '2px',
                    transition: 'all 0.2s ease',
                  }}
                >
                  <item.icon size={14} />
                  {item.label}
                </button>
              ))}
            </div>

            {/* 面板内容 - 网格布局 */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '12px',
              display: 'grid',
              gridTemplateColumns: '1fr',
              gridAutoRows: 'minmax(200px, auto)',
              gap: '12px',
            }}>
              {globalStatsTab === 'sales' && <SalesPanel data={salesPanelData.data} />}
              {globalStatsTab === 'customers' && <CustomersPanel data={customersPanelData.data} />}
              {globalStatsTab === 'projects' && <ProjectsPanel data={projectsPanelData.data} />}
              {globalStatsTab === 'solutions' && <SolutionsPanel data={solutionsPanelData.data} />}
            </div>
          </div>

          {/* 中间：地图区域 */}
          <div style={{
            flex: 1,
            position: 'relative',
            overflow: 'hidden',
          }}>
            <TechMapChart
              key={currentMapType}
              mapType={currentMapType === 'province-outside' ? 'china' : 'zhejiang'}
              title=""
              data={getCurrentMapData()}
              currentDataType={getMapDataTypeByHeatmapMode()}
              onRegionClick={setSelectedRegion}
              onDrillDown={handleDrillDown}
              height="100%"
              showDetailPanel={false}
              selectedRegion={null}
              onCloseDetail={() => {}}
              highlightMode={null}
              highlightRegions={[]}
              regionBrightness={{}}
            />

            {/* 选中区域详细信息面板 */}
            {selectedRegion && (
              <RegionDetailPanel regionData={selectedRegion} onClose={() => setSelectedRegion(null)} />
            )}
          </div>

          {/* 右侧：实时数据面板 */}
          <div style={{
            width: '350px',
            minWidth: '350px',
            background: 'rgba(10, 15, 26, 0.95)',
            border: '1px solid rgba(0, 212, 255, 0.2)',
            borderLeft: 'none',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}>
            {/* 标题 */}
            <div style={{
              padding: '12px 16px',
              borderBottom: '1px solid rgba(0, 212, 255, 0.2)',
              background: 'rgba(0, 255, 136, 0.1)',
            }}>
              <h2 style={{
                color: '#00FF88',
                fontSize: '14px',
                fontWeight: '700',
                fontFamily: '"JetBrains Mono", monospace',
                margin: 0,
                letterSpacing: '1px',
              }}>
                实时数据监控
              </h2>
            </div>

            {/* 实时数据内容 */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '12px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
            }}>
              {/* 热力图维度选择 - 下拉框 */}
              <div style={{
                padding: '8px',
                background: 'rgba(0, 212, 255, 0.05)',
                borderRadius: '8px',
                border: '1px solid rgba(0, 212, 255, 0.15)',
              }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '8px',
                }}>
                  <span style={{
                    color: 'rgba(255, 255, 255, 0.7)',
                    fontSize: '11px',
                    fontFamily: '"JetBrains Mono", monospace',
                  }}>
                    热力图维度
                  </span>
                </div>
                <HeatmapDimensionSwitcher
                  currentType={getMapDataTypeByHeatmapMode()}
                  onTypeChange={(type) => {
                    switch (type) {
                      case MapDataType.CUSTOMER_COUNT_HEATMAP:
                        setHeatmapMode('customer');
                        break;
                      case MapDataType.PROJECT_COUNT_HEATMAP:
                        setHeatmapMode('project');
                        break;
                      case MapDataType.BUDGET:
                        setHeatmapMode('budget');
                        break;
                      case MapDataType.CONTRACT_AMOUNT:
                        setHeatmapMode('contract');
                        break;
                      case MapDataType.PRE_SALES_ACTIVITY:
                        setHeatmapMode('activity');
                        break;
                      case MapDataType.SOLUTION_USAGE:
                        setHeatmapMode('solution');
                        break;
                    }
                  }}
                />
              </div>
              
              {/* 热力图排行榜 */}
              <HeatmapTopRank
                data={getCurrentMapData()}
                dataType={getMapDataTypeByHeatmapMode()}
                label={getHeatmapConfigLocal().label}
                unit={getHeatmapConfigLocal().unit}
              />
              
              {/* 实时数据流 */}
              <RealTimeDataPanel />
              
              {/* 快速统计 */}
              <QuickStatsPanel data={getCurrentMapData()} />
            </div>
          </div>
        </div>
      </div>

      {/* Particle Animation Script */}
      <script dangerouslySetInnerHTML={{
        __html: `
          (function() {
            const canvas = document.getElementById('particle-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let particles = [];
            let dataParticles = [];
            let nodes = [];

            function resize() {
              canvas.width = window.innerWidth;
              canvas.height = window.innerHeight;
              initNodes();
            }
            window.addEventListener('resize', resize);
            resize();

            // 普通粒子（背景）
            class Particle {
              constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.vx = (Math.random() - 0.5) * 0.4;
                this.vy = (Math.random() - 0.5) * 0.4;
                this.radius = Math.random() * 2 + 0.5;
                this.opacity = Math.random() * 0.5 + 0.3;
                this.color = Math.random() > 0.5 ? 'rgba(0, 212, 255,' : 'rgba(0, 255, 136,';
                this.pulsePhase = Math.random() * Math.PI * 2;
                this.pulseSpeed = 0.02 + Math.random() * 0.02;
              }
              update() {
                this.x += this.vx;
                this.y += this.vy;
                if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
                if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
                this.pulsePhase += this.pulseSpeed;
              }
              draw() {
                const pulse = Math.sin(this.pulsePhase) * 0.3 + 0.7;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius * pulse, 0, Math.PI * 2);
                ctx.fillStyle = this.color + (this.opacity * pulse) + ')';
                ctx.fill();
              }
            }

            // 数据流粒子
            class DataParticle {
              constructor() {
                this.reset();
              }
              reset() {
                this.x = Math.random() * canvas.width;
                this.y = -20;
                this.vy = 0.5 + Math.random() * 1.5;
                this.radius = Math.random() * 1.5 + 0.5;
                this.opacity = Math.random() * 0.4 + 0.2;
                this.color = 'rgba(0, 212, 255,';
                this.trail = [];
                this.maxTrail = 15;
              }
              update() {
                this.trail.push({ x: this.x, y: this.y, opacity: this.opacity });
                if (this.trail.length > this.maxTrail) {
                  this.trail.shift();
                }
                this.y += this.vy;
                if (this.y > canvas.height + 20) {
                  this.reset();
                }
              }
              draw() {
                // 绘制拖尾
                for (let i = 0; i < this.trail.length; i++) {
                  const t = this.trail[i];
                  const trailOpacity = (i / this.trail.length) * this.opacity * 0.5;
                  ctx.beginPath();
                  ctx.arc(t.x, t.y, this.radius * (i / this.trail.length), 0, Math.PI * 2);
                  ctx.fillStyle = this.color + trailOpacity + ')';
                  ctx.fill();
                }
                // 绘制粒子
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                ctx.fillStyle = this.color + this.opacity + ')';
                ctx.fill();
              }
            }

            // 闪烁节点
            class Node {
              constructor(x, y) {
                this.x = x;
                this.y = y;
                this.baseRadius = 3 + Math.random() * 4;
                this.radius = 0;
                this.opacity = 0;
                this.phase = Math.random() * Math.PI * 2;
                this.active = Math.random() > 0.7;
                this.activationInterval = 3000 + Math.random() * 5000;
                this.lastActivation = Date.now() + Math.random() * 3000;
                this.color = Math.random() > 0.5 ? 'rgba(0, 212, 255,' : 'rgba(255, 215, 0,';
              }
              update() {
                const now = Date.now();
                if (now - this.lastActivation > this.activationInterval) {
                  this.active = true;
                  this.lastActivation = now;
                  this.phase = 0;
                }
                
                if (this.active) {
                  this.phase += 0.08;
                  this.opacity = Math.sin(this.phase) * 0.5 + 0.5;
                  this.radius = this.baseRadius * (0.5 + Math.sin(this.phase) * 0.5);
                  
                  if (this.phase > Math.PI * 2) {
                    this.active = false;
                    this.opacity = 0;
                  }
                }
              }
              draw() {
                if (this.opacity <= 0.01) return;
                
                // 绘制外圈
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius * 2, 0, Math.PI * 2);
                ctx.fillStyle = this.color + (this.opacity * 0.2) + ')';
                ctx.fill();
                
                // 绘制内核
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
                ctx.fillStyle = this.color + this.opacity + ')';
                ctx.fill();
                
                // 绘制光晕
                const gradient = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius * 3);
                gradient.addColorStop(0, this.color + (this.opacity * 0.3) + ')');
                gradient.addColorStop(1, 'transparent');
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius * 3, 0, Math.PI * 2);
                ctx.fillStyle = gradient;
                ctx.fill();
              }
            }

            function init() {
              particles = [];
              for (let i = 0; i < 60; i++) particles.push(new Particle());
              
              dataParticles = [];
              for (let i = 0; i < 20; i++) dataParticles.push(new DataParticle());
              
              initNodes();
            }

            function initNodes() {
              nodes = [];
              const nodeCount = Math.floor((canvas.width * canvas.height) / 40000);
              for (let i = 0; i < nodeCount; i++) {
                nodes.push(new Node(
                  100 + Math.random() * (canvas.width - 200),
                  100 + Math.random() * (canvas.height - 200)
                ));
              }
            }

            function connect() {
              // 普通粒子之间的连接
              for (let i = 0; i < particles.length; i++) {
                for (let j = i + 1; j < particles.length; j++) {
                  const dx = particles[i].x - particles[j].x;
                  const dy = particles[i].y - particles[j].y;
                  const distance = Math.sqrt(dx * dx + dy * dy);
                  if (distance < 150) {
                    ctx.beginPath();
                    ctx.strokeStyle = 'rgba(0, 212, 255,' + (0.1 - distance / 1500) + ')';
                    ctx.lineWidth = 0.5;
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                  }
                }
              }
              
              // 节点之间的连接
              for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                  const dx = nodes[i].x - nodes[j].x;
                  const dy = nodes[i].y - nodes[j].y;
                  const distance = Math.sqrt(dx * dx + dy * dy);
                  if (distance < 200) {
                    const maxOpacity = Math.max(nodes[i].opacity, nodes[j].opacity);
                    ctx.beginPath();
                    ctx.strokeStyle = 'rgba(0, 212, 255,' + (maxOpacity * 0.15 * (1 - distance / 200)) + ')';
                    ctx.lineWidth = 1;
                    ctx.moveTo(nodes[i].x, nodes[i].y);
                    ctx.lineTo(nodes[j].x, nodes[j].y);
                    ctx.stroke();
                  }
                }
              }
            }

            let animationId: number;
            let isVisible = true;

            document.addEventListener('visibilitychange', () => {
              isVisible = !document.hidden;
              if (!isVisible) {
                cancelAnimationFrame(animationId);
                animationId = 0;
              } else if (!animationId) {
                animate();
              }
            });

            function animate() {
              if (!isVisible) return;
              
              ctx.clearRect(0, 0, canvas.width, canvas.height);
              
              // 更新和绘制所有粒子
              particles.forEach(p => {
                p.update();
                p.draw();
              });
              
              // 更新和绘制数据流粒子
              dataParticles.forEach(dp => {
                dp.update();
                dp.draw();
              });
              
              // 更新和绘制节点
              nodes.forEach(n => {
                n.update();
                n.draw();
              });
              
              connect();
              
              animationId = requestAnimationFrame(animate);
            }

            init();
            animate();
          })();
        `
      }} />
    </div>
  );
}

