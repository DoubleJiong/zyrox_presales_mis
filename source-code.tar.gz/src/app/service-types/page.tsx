'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function ServiceTypesRedirectPage() {
  const router = useRouter();

  useEffect(() => {
    // 自动重定向到系统设置下的售前服务配置
    router.replace('/settings?tab=presales');
  }, [router]);

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-center">
        <div className="text-lg">正在跳转到系统设置...</div>
      </div>
    </div>
  );
}
