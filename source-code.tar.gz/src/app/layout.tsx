import type { Metadata } from 'next';
import { AuthProvider } from '@/contexts/auth-context';
import { RootAuthCheck } from '@/components/root-auth-check';
import { MainLayout } from '@/components/main-layout';
import { PermissionProvider } from '@/components/auth/PermissionProvider';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '售前管理系统',
    template: '%s | 售前管理系统',
  },
  description: '正元智慧售前管理系统 - 全流程管理售前工作',
  authors: [{ name: '正元智慧' }],
  generator: 'Coze Code',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body className="antialiased">
        <AuthProvider>
          <RootAuthCheck>
            <PermissionProvider>
              <MainLayout>
                {children}
              </MainLayout>
            </PermissionProvider>
          </RootAuthCheck>
        </AuthProvider>
      </body>
    </html>
  );
}
