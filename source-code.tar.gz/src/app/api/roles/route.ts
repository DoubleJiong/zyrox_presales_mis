import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { roles } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';

// GET - 获取角色列表
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const { searchParams } = new URL(request.url);
    const includePermissions = searchParams.get('includePermissions') === 'true';

    const roleList = await db
      .select({
        id: roles.id,
        roleName: roles.roleName,
        roleCode: roles.roleCode,
        description: roles.description,
        status: roles.status,
        permissions: roles.permissions,
        createdAt: roles.createdAt,
      })
      .from(roles)
      .orderBy(desc(roles.id));

    return successResponse(roleList);
  } catch (error) {
    console.error('Failed to fetch roles:', error);
    return errorResponse('INTERNAL_ERROR', '获取角色列表失败');
  }
});

// POST - 创建角色
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const body = await request.json();
    const { roleName, roleCode, description, status, permissions } = body;

    if (!roleName || !roleCode) {
      return errorResponse('BAD_REQUEST', '角色名称和编码不能为空');
    }

    // 检查角色编码是否已存在
    const existing = await db
      .select()
      .from(roles)
      .where(eq(roles.roleCode, roleCode))
      .limit(1);

    if (existing.length > 0) {
      return errorResponse('BAD_REQUEST', '角色编码已存在');
    }

    const [newRole] = await db
      .insert(roles)
      .values({
        roleName,
        roleCode,
        description: description || null,
        status: status || 'active',
        permissions: permissions || [],
      })
      .returning();

    return successResponse(newRole, { status: 201 });
  } catch (error) {
    console.error('Failed to create role:', error);
    return errorResponse('INTERNAL_ERROR', '创建角色失败');
  }
});

// PUT - 更新角色
export const PUT = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const body = await request.json();
    const { id, roleName, description, status, permissions } = body;

    if (!id) {
      return errorResponse('BAD_REQUEST', '角色ID不能为空');
    }

    // 检查角色是否存在
    const existing = await db
      .select()
      .from(roles)
      .where(eq(roles.id, id))
      .limit(1);

    if (existing.length === 0) {
      return errorResponse('NOT_FOUND', '角色不存在');
    }

    // 更新角色
    const [updatedRole] = await db
      .update(roles)
      .set({
        roleName: roleName || existing[0].roleName,
        description: description !== undefined ? description : existing[0].description,
        status: status || existing[0].status,
        permissions: permissions || existing[0].permissions,
        updatedAt: new Date(),
      })
      .where(eq(roles.id, id))
      .returning();

    return successResponse(updatedRole);
  } catch (error) {
    console.error('Failed to update role:', error);
    return errorResponse('INTERNAL_ERROR', '更新角色失败');
  }
});

// DELETE - 删除角色
export const DELETE = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return errorResponse('BAD_REQUEST', '角色ID不能为空');
    }

    // 检查角色是否存在
    const existing = await db
      .select()
      .from(roles)
      .where(eq(roles.id, parseInt(id)))
      .limit(1);

    if (existing.length === 0) {
      return errorResponse('NOT_FOUND', '角色不存在');
    }

    // 软删除（设置deletedAt）
    await db
      .update(roles)
      .set({
        deletedAt: new Date(),
        status: 'inactive',
        updatedAt: new Date(),
      })
      .where(eq(roles.id, parseInt(id)));

    return successResponse({ deleted: true });
  } catch (error) {
    console.error('Failed to delete role:', error);
    return errorResponse('INTERNAL_ERROR', '删除角色失败');
  }
});
