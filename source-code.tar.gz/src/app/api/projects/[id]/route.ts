import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, users, tasks, projectBudgetHistory } from '@/db/schema';
import { eq, sql, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { canReadProject, canWriteProject, canAdminProject } from '@/lib/permissions/project';
import { syncSingleCustomerStats } from '@/app/api/customers/sync-stats/route';
import { sanitizeString, containsHtml } from '@/lib/xss';
import { formatDateField } from '@/lib/utils';

// GET - 获取项目详情
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const idParam = context.params?.id || '0';
    const projectId = parseInt(idParam);
    
    // BUG-016: 处理非数字ID或projectCode的情况
    if (isNaN(projectId) || projectId <= 0) {
      return errorResponse('BAD_REQUEST', '无效的项目ID');
    }

    // 权限检查
    const canRead = await canReadProject(projectId, context.userId);
    if (!canRead) {
      return errorResponse('FORBIDDEN', '您没有权限查看此项目');
    }

    const projectList = await db
      .select({
        id: projects.id,
        projectCode: projects.projectCode,
        projectName: projects.projectName,
        customerId: projects.customerId,
        customerName: projects.customerName,
        projectTypeId: projects.projectTypeId,
        industry: projects.industry,
        region: projects.region,
        description: projects.description,
        managerId: projects.managerId,
        projectStage: projects.projectStage,
        estimatedAmount: projects.estimatedAmount,
        actualAmount: projects.actualAmount,
        startDate: projects.startDate,
        endDate: projects.endDate,
        expectedDeliveryDate: projects.expectedDeliveryDate,
        status: projects.status,
        priority: projects.priority,
        progress: projects.progress,
        risks: projects.risks,
        bidResult: projects.bidResult,
        winCompetitor: projects.winCompetitor,
        loseReason: projects.loseReason,
        contractNumber: projects.contractNumber,
        lessonsLearned: projects.lessonsLearned,
        expectedBiddingDate: projects.expectedBiddingDate,
        estimatedDuration: projects.estimatedDuration,
        urgencyLevel: projects.urgencyLevel,
        previousStatus: projects.previousStatus,
        holdReason: projects.holdReason,
        cancelReason: projects.cancelReason,
        createdAt: projects.createdAt,
        updatedAt: projects.updatedAt,
      })
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (projectList.length === 0) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 格式化日期字段
    const project = projectList[0];
    const formattedProject = {
      ...project,
      startDate: formatDateField(project.startDate),
      endDate: formatDateField(project.endDate),
      expectedDeliveryDate: formatDateField(project.expectedDeliveryDate),
      expectedBiddingDate: formatDateField(project.expectedBiddingDate),
      createdAt: formatDateField(project.createdAt),
      updatedAt: formatDateField(project.updatedAt),
    };

    return successResponse(formattedProject);
  } catch (error) {
    console.error('Failed to fetch project detail:', error);
    return errorResponse('INTERNAL_ERROR', '获取项目详情失败');
  }
});

// PUT - 更新项目
export const PUT = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const body = await request.json();
    const projectId = parseInt(context.params?.id || '0');

    // 权限检查
    const canWrite = await canWriteProject(projectId, context.userId);
    if (!canWrite) {
      return errorResponse('FORBIDDEN', '您没有权限编辑此项目');
    }

    // 获取原项目信息
    const [originalProject] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!originalProject) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // ============ BUG-001: 已取消状态不可变更 ============
    if (originalProject.status === 'cancelled') {
      return errorResponse('FORBIDDEN', '已取消的项目不能再进行修改');
    }

    // ============ BUG-020: 项目进度范围校验 ============
    if (body.progress !== undefined) {
      const progress = parseInt(body.progress);
      if (isNaN(progress) || progress < 0 || progress > 100) {
        return errorResponse('BAD_REQUEST', '项目进度必须在0-100之间');
      }
    }

    // ============ BUG-013: 项目名称不能为空 ============
    if (body.projectName !== undefined) {
      const sanitizedName = sanitizeString(body.projectName);
      if (!sanitizedName || sanitizedName.trim() === '') {
        return errorResponse('BAD_REQUEST', '项目名称不能为空');
      }
      if (sanitizedName.length > 200) {
        return errorResponse('BAD_REQUEST', '项目名称不能超过200个字符');
      }
      body.projectName = sanitizedName;
    }

    // ============ BUG-012: 项目更新时customerId外键验证 ============
    if (body.customerId !== undefined && body.customerId !== null) {
      const { customers } = await import('@/db/schema');
      const customerExists = await db
        .select({ id: customers.id })
        .from(customers)
        .where(eq(customers.id, body.customerId))
        .limit(1);
      
      if (customerExists.length === 0) {
        return errorResponse('BAD_REQUEST', '指定的客户不存在');
      }
    }

    // ============ BUG-010: 项目进度与状态一致性校验 ============
    const newProgress = body.progress !== undefined ? parseInt(body.progress) : originalProject.progress;
    const checkStatus = body.status || originalProject.status;
    
    // 进度100%时状态不能是draft
    if (newProgress === 100 && checkStatus === 'draft') {
      return errorResponse('BAD_REQUEST', '项目进度100%时状态不能为草稿');
    }
    
    // 状态为completed时进度必须为100%
    if (checkStatus === 'completed' && newProgress !== 100) {
      return errorResponse('BAD_REQUEST', '项目状态为已完成时，进度必须为100%');
    }

    // ============ BUG-014: 金额不能为负数 ============
    if (body.estimatedAmount !== undefined) {
      const amount = parseFloat(body.estimatedAmount);
      if (!isNaN(amount) && amount < 0) {
        return errorResponse('BAD_REQUEST', '预计金额不能为负数');
      }
    }
    if (body.actualAmount !== undefined) {
      const amount = parseFloat(body.actualAmount);
      if (!isNaN(amount) && amount < 0) {
        return errorResponse('BAD_REQUEST', '实际金额不能为负数');
      }
    }

    // ============ BUG-015: 结束日期不能早于开始日期 ============
    const startDate = body.startDate || originalProject.startDate;
    const endDate = body.endDate || originalProject.endDate;
    if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
      return errorResponse('BAD_REQUEST', '结束日期不能早于开始日期');
    }

    // ============ BUG-040: 项目优先级枚举校验 ============
    if (body.priority !== undefined) {
      const validPriorities = ['low', 'medium', 'high', 'urgent'];
      if (!validPriorities.includes(body.priority)) {
        return errorResponse('BAD_REQUEST', '无效的项目优先级');
      }
    }

    // ============ XSS防护: 清理用户输入 ============
    const sanitizedBody = {
      ...body,
      projectName: sanitizeString(body.projectName || ''),
      customerName: sanitizeString(body.customerName || ''),
      description: body.description ? sanitizeString(body.description) : null,
      risks: body.risks ? sanitizeString(body.risks) : null,
      loseReason: body.loseReason ? sanitizeString(body.loseReason) : null,
      holdReason: body.holdReason ? sanitizeString(body.holdReason) : null,
      cancelReason: body.cancelReason ? sanitizeString(body.cancelReason) : null,
      winCompetitor: body.winCompetitor ? sanitizeString(body.winCompetitor) : null,
      contractNumber: body.contractNumber ? sanitizeString(body.contractNumber) : null,
      lessonsLearned: body.lessonsLearned ? sanitizeString(body.lessonsLearned) : null,
    };

    // ============ BUG-002: 状态转换限制 ============
    const oldStatus = originalProject.status;
    const newStatus = sanitizedBody.status;

    // 定义合法的状态转换路径
    const validTransitions: Record<string, string[]> = {
      'lead': ['qualified', 'lost', 'cancelled'],           // 商机线索 → 意向确认/丢失/取消
      'qualified': ['bidding', 'lost', 'cancelled'],         // 意向确认 → 投标中/丢失/取消
      'bidding': ['won', 'lost', 'cancelled'],               // 投标中 → 中标/丢标/取消
      'won': ['archived'],                                    // 中标 → 归档
      'lost': ['archived'],                                   // 丢标 → 归档
      'archived': [],                                         // 归档是终态，不可变更
      'cancelled': [],                                        // 取消是终态，不可变更（前面已校验）
      'draft': ['lead', 'qualified', 'cancelled'],            // BUG-022: 草稿不能直接到completed
      'in_progress': ['completed', 'on_hold', 'cancelled'],   // 进行中 → 已完成/暂停/取消
      'ongoing': ['completed', 'cancelled'],                  // 进行中才能完成
      'completed': ['archived'],                              // 已完成才能归档
      'on_hold': ['in_progress', 'cancelled'],                // 暂停 → 进行中/取消
    };

    // 如果状态有变化，检查转换是否合法
    if (newStatus && newStatus !== oldStatus) {
      const allowedNextStatuses = validTransitions[oldStatus] || [];
      if (!allowedNextStatuses.includes(newStatus)) {
        return errorResponse('BAD_REQUEST', 
          `状态不能从"${oldStatus}"直接变更为"${newStatus}"。允许的下一状态：${allowedNextStatuses.join('、') || '无'}`);
      }
      
      // BUG-022: 额外验证 - 不能从draft直接到completed
      if (oldStatus === 'draft' && newStatus === 'completed') {
        return errorResponse('BAD_REQUEST', '项目不能从草稿状态直接变为已完成');
      }
    }

    // ============ BUG-003: 中标时必须填写金额 ============
    if (newStatus === 'won') {
      const actualAmount = sanitizedBody.actualAmount ?? originalProject.actualAmount;
      if (!actualAmount || parseFloat(actualAmount) <= 0) {
        return errorResponse('BAD_REQUEST', '项目中标时必须填写实际金额（actualAmount）');
      }
    }

    // ============ TC-STAGE-*: 阶段转换限制 ============
    const oldStage = originalProject.projectStage;
    const newStage = sanitizedBody.projectStage;

    if (newStage && newStage !== oldStage) {
      // TC-STAGE-012: 归档后不可变更阶段
      if (oldStage === 'archived') {
        return errorResponse('BAD_REQUEST', '归档后的项目不可变更阶段');
      }

      // TC-STAGE-010/011: 中标后不可退回商机阶段或招投标阶段
      const currentStatus = newStatus || oldStatus;
      if (currentStatus === 'won' || currentStatus === 'archived') {
        const restrictedStages = ['opportunity', 'bidding'];
        if (restrictedStages.includes(newStage) && !restrictedStages.includes(oldStage)) {
          return errorResponse('BAD_REQUEST', `中标后不可退回到${newStage === 'opportunity' ? '商机' : '招投标'}阶段`);
        }
      }

      // TC-STAGE-020: 未中标不可进入实施阶段
      const implementationStages = ['execution', 'settlement'];
      if (implementationStages.includes(newStage) && currentStatus !== 'won') {
        return errorResponse('BAD_REQUEST', '进入实施阶段需要先中标');
      }
    }

    const oldCustomerId = originalProject.customerId;
    const newCustomerId = sanitizedBody.customerId !== undefined ? sanitizedBody.customerId : oldCustomerId;

    // 同步 projectType 字段（当 projectTypeId 变化时）
    let newProjectType = originalProject.projectType;
    if (sanitizedBody.projectTypeId !== undefined && sanitizedBody.projectTypeId !== originalProject.projectTypeId) {
      const { projectTypes } = await import('@/db/schema');
      const [newType] = await db
        .select({ code: projectTypes.code })
        .from(projectTypes)
        .where(eq(projectTypes.id, sanitizedBody.projectTypeId))
        .limit(1);
      if (newType) {
        newProjectType = newType.code;
      }
    }

    // BUG-003: 检查预算是否有变化，用于记录历史
    const oldEstimatedAmount = originalProject.estimatedAmount;
    const newEstimatedAmount = sanitizedBody.estimatedAmount;
    const hasBudgetChange = newEstimatedAmount !== undefined && 
                            String(oldEstimatedAmount || '0') !== String(newEstimatedAmount);

    // 更新项目
    const [updatedProject] = await db
      .update(projects)
      .set({
        projectName: sanitizedBody.projectName,
        customerId: newCustomerId,
        customerName: sanitizedBody.customerName,
        projectTypeId: sanitizedBody.projectTypeId,
        projectType: newProjectType,
        industry: sanitizedBody.industry,
        region: sanitizedBody.region,
        description: sanitizedBody.description,
        managerId: sanitizedBody.managerId,
        projectStage: sanitizedBody.projectStage,
        estimatedAmount: sanitizedBody.estimatedAmount,
        actualAmount: sanitizedBody.actualAmount,
        startDate: sanitizedBody.startDate || null,
        endDate: sanitizedBody.endDate || null,
        expectedDeliveryDate: sanitizedBody.expectedDeliveryDate || null,
        expectedBiddingDate: sanitizedBody.expectedBiddingDate || null,
        estimatedDuration: sanitizedBody.estimatedDuration,
        urgencyLevel: sanitizedBody.urgencyLevel,
        status: sanitizedBody.status,
        priority: sanitizedBody.priority,
        progress: sanitizedBody.progress,
        risks: sanitizedBody.risks,
        // BUG-004/005: 处理状态相关的附加字段
        loseReason: sanitizedBody.loseReason,
        holdReason: sanitizedBody.holdReason,
        cancelReason: sanitizedBody.cancelReason,
        winCompetitor: sanitizedBody.winCompetitor,
        contractNumber: sanitizedBody.contractNumber,
        lessonsLearned: sanitizedBody.lessonsLearned,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId))
      .returning();

    // BUG-003: 如果预算有变化，记录预算历史
    if (hasBudgetChange) {
      // 获取当前用户信息
      const [currentUser] = await db
        .select({ realName: users.realName })
        .from(users)
        .where(eq(users.id, context.userId))
        .limit(1);

      const isFirstEntry = oldEstimatedAmount === null || oldEstimatedAmount === undefined;
      
      await db.insert(projectBudgetHistory).values({
        projectId,
        oldAmount: oldEstimatedAmount ? String(oldEstimatedAmount) : null,
        newAmount: String(newEstimatedAmount),
        changeReason: isFirstEntry ? null : '项目编辑更新',
        isFirstEntry,
        changedBy: context.userId,
        changedByName: currentUser?.realName || null,
      });
    }

    // 如果客户变更，更新客户项目数统计
    if (oldCustomerId !== newCustomerId) {
      // 同步原客户统计
      if (oldCustomerId) {
        await syncSingleCustomerStats(oldCustomerId);
      }
      // 同步新客户统计
      if (newCustomerId) {
        await syncSingleCustomerStats(newCustomerId);
      }
    } else if (newCustomerId) {
      // 即使客户没变，金额变化也需要同步
      await syncSingleCustomerStats(newCustomerId);
    }

    return successResponse(updatedProject);
  } catch (error) {
    console.error('Failed to update project:', error);
    return errorResponse('INTERNAL_ERROR', '更新项目失败');
  }
});


// DELETE - 删除项目（软删除）
export const DELETE = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');

    // 权限检查（需要ADMIN权限才能删除）
    const canAdmin = await canAdminProject(projectId, context.userId);
    if (!canAdmin) {
      return errorResponse('FORBIDDEN', '您没有权限删除此项目');
    }

    // 获取原项目信息
    const [originalProject] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!originalProject) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // BUG-024: 检查是否有关联合同
    const { contracts } = await import('@/db/schema');
    const relatedContracts = await db
      .select({ id: contracts.id, contractName: contracts.contractName })
      .from(contracts)
      .where(eq(contracts.projectId, projectId))
      .limit(5);

    if (relatedContracts.length > 0) {
      return errorResponse('BAD_REQUEST', 
        `该项目有${relatedContracts.length}个关联合同，请先解除关联或删除合同后再删除项目`);
    }

    // 软删除项目
    await db
      .update(projects)
      .set({
        deletedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId));

    // 更新客户项目数统计
    if (originalProject.customerId) {
      await syncSingleCustomerStats(originalProject.customerId);
    }

    return successResponse({ success: true, message: '项目已删除' });
  } catch (error) {
    console.error('Failed to delete project:', error);
    return errorResponse('INTERNAL_ERROR', '删除项目失败');
  }
});
