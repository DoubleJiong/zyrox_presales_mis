import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projectBiddings, projects } from '@/db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { canReadProject, canWriteProject } from '@/lib/permissions/project';

// GET - 获取项目投标信息
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');

    // 检查项目是否存在且未被删除
    const [projectExists] = await db
      .select({ id: projects.id })
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!projectExists) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 权限检查
    const canRead = await canReadProject(projectId, context.userId);
    if (!canRead) {
      return errorResponse('FORBIDDEN', '您没有权限查看此项目');
    }

    const [projectBid] = await db
      .select()
      .from(projectBiddings)
      .where(eq(projectBiddings.projectId, projectId))
      .limit(1);

    if (!projectBid) {
      return NextResponse.json({
        success: true,
        data: {
          projectId,
          bidNumber: null,
          bidProjectName: null,
          biddingMethod: null,
          scoringMethod: null,
          priceLimit: null,
          fundSource: null,
          biddingType: null,
          bidDeadline: null,
          bidBondAmount: null,
          bidBondStatus: 'unpaid',
          bidBondPayDate: null,
          bidBondReturnDate: null,
          tenderDocuments: [],
          bidDocuments: [],
          bidTeam: [],
          bidPrice: null,
          bidOpenDate: null,
          bidResult: 'pending',
          loseReason: null,
          winCompetitor: null,
          reviewComments: null,
          lessonsLearned: null,
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: projectBid,
    });
  } catch (error) {
    console.error('Get project bidding error:', error);
    return errorResponse('INTERNAL_ERROR', '获取项目投标信息失败');
  }
});

// PUT - 更新项目投标信息
export const PUT = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');
    const body = await request.json();

    // 检查项目是否存在且未被删除
    const [projectExists] = await db
      .select({ id: projects.id })
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!projectExists) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 权限检查
    const canWrite = await canWriteProject(projectId, context.userId);
    if (!canWrite) {
      return errorResponse('FORBIDDEN', '您没有权限编辑此项目');
    }

    // BUG-005: 投标保证金不能为负数
    if (body.bidBondAmount !== undefined && body.bidBondAmount !== null) {
      const bondAmount = parseFloat(body.bidBondAmount);
      if (!isNaN(bondAmount) && bondAmount < 0) {
        return errorResponse('BAD_REQUEST', '投标保证金不能为负数');
      }
    }

    // BUG-026: 投标报价不能为负数
    if (body.bidPrice !== undefined && body.bidPrice !== null) {
      const bidPrice = parseFloat(body.bidPrice);
      if (!isNaN(bidPrice) && bidPrice < 0) {
        return errorResponse('BAD_REQUEST', '投标报价不能为负数');
      }
    }

    // BUG-023: 价格上限不能为负数
    if (body.priceLimit !== undefined && body.priceLimit !== null) {
      const priceLimit = parseFloat(body.priceLimit);
      if (!isNaN(priceLimit) && priceLimit < 0) {
        return errorResponse('BAD_REQUEST', '价格上限不能为负数');
      }
    }

    const [existing] = await db
      .select()
      .from(projectBiddings)
      .where(eq(projectBiddings.projectId, projectId))
      .limit(1);

    let result;
    if (existing) {
      [result] = await db
        .update(projectBiddings)
        .set({
          ...body,
          updatedAt: new Date(),
        })
        .where(eq(projectBiddings.projectId, projectId))
        .returning();
    } else {
      [result] = await db
        .insert(projectBiddings)
        .values({
          projectId,
          ...body,
        })
        .returning();
    }

    // 同步更新项目阶段和投标结果
    const projectUpdates: any = {
      projectStage: 'bidding',
      updatedAt: new Date(),
    };
    
    if (body.bidResult === 'won') {
      projectUpdates.bidResult = 'won';
    } else if (body.bidResult === 'lost') {
      projectUpdates.bidResult = 'lost';
      projectUpdates.winCompetitor = body.winCompetitor;
      projectUpdates.loseReason = body.loseReason;
    }

    await db
      .update(projects)
      .set(projectUpdates)
      .where(eq(projects.id, projectId));

    return NextResponse.json({
      success: true,
      data: result,
      message: '保存成功',
    });
  } catch (error) {
    console.error('Update project bidding error:', error);
    return errorResponse('INTERNAL_ERROR', '更新项目投标信息失败');
  }
});
