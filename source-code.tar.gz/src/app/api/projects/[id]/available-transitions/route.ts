import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects } from '@/db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { getStatusOptions, ProjectStatus, ProjectStage } from '@/lib/utils/status-transitions';
import { getStageOptions } from '@/lib/utils/stage-transitions';

// GET - 获取项目可用的状态和阶段转换选项
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');

    // 获取当前项目
    const [project] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!project) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    const currentStatus = project.status as ProjectStatus;
    const currentStage = (project.projectStage || 'opportunity') as ProjectStage;

    // 获取可用的状态选项
    const statusOptions = getStatusOptions(currentStatus);

    // 获取可用的阶段选项
    const stageOptions = getStageOptions(currentStage, currentStatus);

    return successResponse({
      statuses: statusOptions,
      stages: stageOptions,
      current: {
        status: currentStatus,
        stage: currentStage
      }
    });
  } catch (error) {
    console.error('Failed to get available transitions:', error);
    return errorResponse('INTERNAL_ERROR', '获取可转换选项失败');
  }
});
