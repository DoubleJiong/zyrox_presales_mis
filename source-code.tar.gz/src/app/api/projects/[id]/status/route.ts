import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects } from '@/db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { 
  isStatusTransitionAllowed, 
  getRequiredFieldsForStatus,
  ProjectStatus 
} from '@/lib/utils/status-transitions';
import { getStatusLabel } from '@/lib/utils/project-colors';

// POST - 变更项目状态
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const body = await request.json();
    const projectId = parseInt(context.params?.id || '0');
    const newStatus = body.status as ProjectStatus;
    const additionalData = body.additionalData || {};
    const isResume = body.isResume || false; // 是否是恢复操作

    // 获取当前项目
    const [project] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!project) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    const currentStatus = project.status as ProjectStatus;

    // 如果是恢复操作，跳过状态转换校验
    if (!isResume) {
      // 检查状态变更是否允许
      if (!isStatusTransitionAllowed(currentStatus, newStatus)) {
        return errorResponse('BAD_REQUEST', `不允许从「${getStatusLabel(currentStatus)}」变更到「${getStatusLabel(newStatus)}」`);
      }

      // 检查必填字段
      const requiredFields = getRequiredFieldsForStatus(newStatus);
      const missingFields: string[] = [];
      
      for (const field of requiredFields) {
        // 检查项目本身字段
        if (field === 'projectName' && !project.projectName) {
          missingFields.push('项目名称');
        } else if (field === 'customerId' && !project.customerId) {
          missingFields.push('客户');
        } else if (field === 'winAmount' && !additionalData.winAmount && !project.actualAmount) {
          missingFields.push('中标金额');
        } else if (field === 'winDate' && !additionalData.winDate) {
          missingFields.push('中标日期');
        }
      }

      if (missingFields.length > 0) {
        return NextResponse.json({
          success: false,
          error: {
            code: 'BAD_REQUEST',
            message: `请先填写：${missingFields.join('、')}`,
            details: { missingFields }
          }
        }, { status: 400 });
      }
    }

    // 准备更新数据
    const updateData: Record<string, unknown> = {
      status: newStatus,
      updatedAt: new Date(),
    };

    // 处理暂停操作：保存当前状态
    if (newStatus === 'on_hold') {
      updateData.previousStatus = currentStatus;
      if (additionalData.holdReason) {
        updateData.holdReason = additionalData.holdReason;
      }
    }

    // 处理恢复操作：清除 previousStatus
    if (isResume && newStatus !== 'on_hold') {
      updateData.previousStatus = null;
      updateData.holdReason = null;
    }

    // 处理中标
    if (newStatus === 'won') {
      if (additionalData.winAmount) {
        updateData.actualAmount = additionalData.winAmount;
      }
    }

    // 处理丢标
    if (additionalData.lostReason) {
      updateData.loseReason = additionalData.lostReason;
    }

    // 处理取消
    if (newStatus === 'cancelled') {
      if (additionalData.cancelReason) {
        updateData.cancelReason = additionalData.cancelReason;
      }
    }

    const [updatedProject] = await db
      .update(projects)
      .set(updateData)
      .where(eq(projects.id, projectId))
      .returning();

    return successResponse({
      success: true,
      data: {
        projectId,
        oldStatus: currentStatus,
        newStatus,
        isResume,
        project: updatedProject
      }
    });
  } catch (error) {
    console.error('Failed to update project status:', error);
    return errorResponse('INTERNAL_ERROR', '更新项目状态失败');
  }
});
