import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, customers, projectMembers, users } from '@/db/schema';
import { desc, eq, sql, and, or, inArray, isNull, count, lt } from 'drizzle-orm';
import { successResponse, errorResponse, validatePagination } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';
import type { AuthUser } from '@/lib/jwt';
import {
  canReadProject,
  canWriteProject,
  canAdminProject,
  getAccessibleProjectIds,
  isSystemAdmin,
  PermissionLevel,
} from '@/lib/permissions/project';
import { syncSingleCustomerStats } from '@/app/api/customers/sync-stats/route';
import { sanitizeString, sanitizeSearchString } from '@/lib/xss';
import { formatDateField } from '@/lib/utils';

// GET - 获取项目列表
export const GET = withAuth(async (req: NextRequest, { userId }) => {
  try {
    const { searchParams } = new URL(req.url);
    // BUG-035, BUG-036: 清理搜索字符串，限制长度并移除危险字符
    const search = sanitizeSearchString(searchParams.get('search') || '');
    const status = searchParams.get('status') || '';
    const priority = searchParams.get('priority') || '';
    
    // ============ 分页支持 ============
    const cursor = searchParams.get('cursor');
    const pagination = validatePagination(
      searchParams.get('page'),
      searchParams.get('pageSize')
    );
    
    if (!pagination.valid) {
      return errorResponse('BAD_REQUEST', pagination.error || '分页参数无效');
    }
    
    const { page, pageSize } = pagination;
    
    // 检查是否是系统管理员
    const isAdmin = await isSystemAdmin(userId);

    // 构建基础查询条件
    const baseConditions = [isNull(projects.deletedAt)];
    
    // BUG-020: 验证状态参数是否有效
    const validStatuses = ['draft', 'lead', 'opportunity', 'bidding', 'negotiation', 'ongoing', 'completed', 'on_hold', 'cancelled'];
    if (status && !validStatuses.includes(status)) {
      return errorResponse('BAD_REQUEST', `无效的项目状态，有效值为: ${validStatuses.join(', ')}`);
    }
    
    // BUG-040: 验证优先级参数是否有效
    const validPriorities = ['low', 'medium', 'high', 'urgent'];
    if (priority && !validPriorities.includes(priority)) {
      return errorResponse('BAD_REQUEST', `无效的优先级，有效值为: ${validPriorities.join(', ')}`);
    }
    
    // 添加搜索条件
    if (search) {
      baseConditions.push(
        or(
          sql`${projects.projectName} ILIKE ${`%${search}%`}`,
          sql`${projects.projectCode} ILIKE ${`%${search}%`}`,
          sql`${projects.customerName} ILIKE ${`%${search}%`}`
        )!
      );
    }
    
    // 添加状态筛选
    if (status) {
      baseConditions.push(eq(projects.status, status));
    }
    
    // 添加优先级筛选
    if (priority) {
      baseConditions.push(eq(projects.priority, priority));
    }
    
    // 游标分页条件
    if (cursor) {
      const [cursorId] = cursor.split('_');
      baseConditions.push(lt(projects.id, parseInt(cursorId)));
    }

    // 定义项目查询的选择字段
    const projectSelectFields = {
      id: projects.id,
      projectCode: projects.projectCode,
      projectName: projects.projectName,
      customerId: projects.customerId,
      customerName: projects.customerName,
      projectTypeId: projects.projectTypeId,
      projectType: projects.projectType,
      industry: projects.industry,
      region: projects.region,
      description: projects.description,
      managerId: projects.managerId,
      estimatedAmount: projects.estimatedAmount,
      actualAmount: projects.actualAmount,
      startDate: projects.startDate,
      endDate: projects.endDate,
      expectedDeliveryDate: projects.expectedDeliveryDate,
      status: projects.status,
      priority: projects.priority,
      projectStage: projects.projectStage,
      progress: projects.progress,
      risks: projects.risks,
      createdAt: projects.createdAt,
      updatedAt: projects.updatedAt,
      managerName: users.realName,
      memberCount: sql<number>`(SELECT COUNT(*) FROM bus_project_member pm WHERE pm.project_id = ${projects.id})`,
      taskTotal: sql<number>`(SELECT COUNT(*) FROM bus_project_task pt WHERE pt.project_id = ${projects.id} AND pt.deleted_at IS NULL)`,
      taskCompleted: sql<number>`(SELECT COUNT(*) FROM bus_project_task pt WHERE pt.project_id = ${projects.id} AND pt.status = 'completed' AND pt.deleted_at IS NULL)`,
      taskPending: sql<number>`(SELECT COUNT(*) FROM bus_project_task pt WHERE pt.project_id = ${projects.id} AND pt.status = 'pending' AND pt.deleted_at IS NULL)`,
      taskInProgress: sql<number>`(SELECT COUNT(*) FROM bus_project_task pt WHERE pt.project_id = ${projects.id} AND pt.status = 'in_progress' AND pt.deleted_at IS NULL)`,
    };

    let projectList;
    let totalResult = null;
    
    if (isAdmin) {
      // 系统管理员可以看到所有项目（排除已删除）
      [totalResult, projectList] = await Promise.all([
        cursor ? Promise.resolve(null) : db
          .select({ count: count() })
          .from(projects)
          .where(and(...baseConditions)),
        
        db
          .select(projectSelectFields)
          .from(projects)
          .leftJoin(users, eq(projects.managerId, users.id))
          .where(and(...baseConditions))
          .orderBy(desc(projects.id))
          .limit(cursor ? pageSize + 1 : pageSize)
          .offset(cursor ? 0 : (page - 1) * pageSize)
      ]);
    } else {
      // 普通用户：可以看到自己是负责人、或者是团队成员的项目
      const accessibleIds = await getAccessibleProjectIds(userId);
      
      // 获取没有负责人的项目（排除已删除）
      const orphanProjects = await db
        .select({ id: projects.id })
        .from(projects)
        .where(and(
          sql`${projects.managerId} IS NULL`,
          isNull(projects.deletedAt)
        ));
      
      const allAccessibleIds = new Set([
        ...accessibleIds,
        ...orphanProjects.map(p => p.id)
      ]);

      if (allAccessibleIds.size === 0) {
        return successResponse({
          projects: [],
          pagination: cursor ? {
            hasNextPage: false,
            nextCursor: null,
            pageSize,
          } : {
            page,
            pageSize,
            total: 0,
            totalPages: 0,
          },
        });
      }

      // 添加项目ID过滤条件
      baseConditions.push(inArray(projects.id, Array.from(allAccessibleIds)));
      
      [totalResult, projectList] = await Promise.all([
        cursor ? Promise.resolve(null) : db
          .select({ count: count() })
          .from(projects)
          .where(and(...baseConditions)),
        
        db
          .select(projectSelectFields)
          .from(projects)
          .leftJoin(users, eq(projects.managerId, users.id))
          .where(and(...baseConditions))
          .orderBy(desc(projects.id))
          .limit(cursor ? pageSize + 1 : pageSize)
          .offset(cursor ? 0 : (page - 1) * pageSize)
      ]);
    }

    // ============ 处理游标分页结果 ============
    let hasNextPage = false;
    let nextCursor: string | null = null;
    let finalList = projectList;
    
    if (cursor && projectList.length > pageSize) {
      hasNextPage = true;
      finalList = projectList.slice(0, pageSize);
      const lastItem = finalList[finalList.length - 1];
      nextCursor = `${lastItem.id}_${lastItem.createdAt?.getTime() || 0}`;
    }

    // 格式化返回数据
    const formattedList = finalList.map(p => ({
      ...p,
      managerName: p.managerName || null,
      memberCount: Number(p.memberCount) || 0,
      startDate: formatDateField(p.startDate),
      endDate: formatDateField(p.endDate),
      expectedDeliveryDate: formatDateField(p.expectedDeliveryDate),
      createdAt: formatDateField(p.createdAt),
      updatedAt: formatDateField(p.updatedAt),
      taskStats: {
        total: Number(p.taskTotal) || 0,
        completed: Number(p.taskCompleted) || 0,
        pending: Number(p.taskPending) || 0,
        inProgress: Number(p.taskInProgress) || 0,
      },
    }));

    // 返回带分页元数据的结果
    const paginationMeta = cursor ? {
      hasNextPage,
      nextCursor,
      pageSize,
    } : {
      page,
      pageSize,
      total: totalResult?.[0]?.count || 0,
      totalPages: Math.ceil((totalResult?.[0]?.count || 0) / pageSize),
    };

    return successResponse({
      projects: formattedList,
      pagination: paginationMeta,
    });
  } catch (error) {
    console.error('Failed to fetch projects:', error);
    return errorResponse('INTERNAL_ERROR', '获取项目列表失败');
  }
});

// POST - 创建新项目
export const POST = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const body = await request.json();

    // XSS防护：清理用户输入
    const sanitizedName = sanitizeString(body.projectName || '');
    const sanitizedCustomerName = sanitizeString(body.customerName || '');
    const sanitizedDescription = body.description ? sanitizeString(body.description) : null;
    const sanitizedRisks = body.risks ? sanitizeString(body.risks) : null;

    // 验证必填字段
    if (!sanitizedName || sanitizedName.trim() === '') {
      return errorResponse('BAD_REQUEST', '项目名称不能为空');
    }

    if (sanitizedName.length > 200) {
      return errorResponse('BAD_REQUEST', '项目名称不能超过200个字符');
    }

    // ============ 幂等性检查：防止重复提交 ============
    // 使用项目名称 + 客户名称作为幂等性键
    const idempotencyKey = `project_create:${userId}:${sanitizedName.toLowerCase()}:${(sanitizedCustomerName || '').toLowerCase()}`;
    const { checkIdempotencyKey, storeIdempotencyKey } = await import('@/lib/idempotency');
    
    const existingResponse = await checkIdempotencyKey(idempotencyKey);
    if (existingResponse) {
      return new NextResponse(existingResponse, {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // TC-VALID-001: 商机阶段必填字段校验
    // 商机阶段（默认阶段）需要校验以下必填字段
    const projectStage = body.projectStage || 'opportunity';
    if (projectStage === 'opportunity') {
      const missingFields: string[] = [];
      
      if (!sanitizedCustomerName || sanitizedCustomerName.trim() === '') {
        missingFields.push('客户名称');
      }
      // 项目类型：支持 projectTypeId 或 projectType
      if (!body.projectTypeId && !body.projectType) {
        missingFields.push('项目类型');
      }
      if (!body.estimatedAmount) {
        missingFields.push('预计预算');
      }
      if (!body.region) {
        missingFields.push('区域');
      }
      
      if (missingFields.length > 0) {
        return errorResponse('BAD_REQUEST', `请填写必填字段：${missingFields.join('、')}`);
      }
    }

    // TC-B004: 预算上限校验
    // 设置合理的预算上限为100亿（数据库最大支持万亿级别，但业务上限制为100亿）
    const MAX_BUDGET = 10_000_000_000; // 100亿
    if (body.estimatedAmount !== undefined && body.estimatedAmount !== null) {
      const amount = parseFloat(body.estimatedAmount);
      if (!isNaN(amount) && amount > MAX_BUDGET) {
        return errorResponse('BAD_REQUEST', `预计预算不能超过 ${MAX_BUDGET.toLocaleString()} 元`);
      }
      if (!isNaN(amount) && amount < 0) {
        return errorResponse('BAD_REQUEST', '预计预算不能为负数');
      }
    }

    // BUG-002: 外键验证 - 验证customerId是否存在
    if (body.customerId) {
      const customerExists = await db
        .select({ id: customers.id })
        .from(customers)
        .where(eq(customers.id, body.customerId))
        .limit(1);
      
      if (customerExists.length === 0) {
        return errorResponse('BAD_REQUEST', '指定的客户不存在');
      }
    }

    // BUG-016: 验证projectTypeId是否存在
    if (body.projectTypeId) {
      const { projectTypes } = await import('@/db/schema');
      const typeExists = await db
        .select({ id: projectTypes.id })
        .from(projectTypes)
        .where(eq(projectTypes.id, body.projectTypeId))
        .limit(1);
      
      if (typeExists.length === 0) {
        return errorResponse('BAD_REQUEST', '指定的项目类型不存在');
      }
    }

    // 生成项目编号（PRJ20260212001格式）
    // 使用数据库序列来避免并发冲突
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const prefix = `PRJ${dateStr}`;
    
    // BUG-029: 使用数据库行锁确保并发安全的项目编号生成
    // 使用 FOR UPDATE SKIP LOCKED 防止并发冲突
    let projectCode = '';
    let attempts = 0;
    const maxAttempts = 5;
    
    while (attempts < maxAttempts) {
      attempts++;
      
      // 查询当天最大的项目编号
      const maxCodeResult = await db.execute(sql`
        SELECT project_code 
        FROM bus_project 
        WHERE project_code LIKE ${prefix + '%'}
        ORDER BY LENGTH(project_code) DESC, project_code DESC 
        LIMIT 1
      `);
      
      let nextNum = 1;
      const rows = maxCodeResult as unknown as { project_code: string }[];
      if (rows[0]?.project_code) {
        const lastCode = rows[0].project_code;
        const numStr = lastCode.replace(prefix, '');
        const lastNum = parseInt(numStr, 10);
        if (!isNaN(lastNum)) {
          nextNum = lastNum + 1;
        }
      }
      
      // 使用4位数字格式，确保足够的容量
      const candidateCode = `${prefix}${String(nextNum).padStart(4, '0')}`;
      
      // 检查该编号是否已存在（防止并发冲突）
      const existingCode = await db.execute(sql`
        SELECT id FROM bus_project WHERE project_code = ${candidateCode} LIMIT 1
      `);
      
      if ((existingCode as unknown as any[]).length === 0) {
        projectCode = candidateCode;
        break;
      }
      // 如果编号已存在，重试
    }
    
    if (!projectCode) {
      // 最终降级：使用时间戳确保唯一性
      projectCode = `${prefix}${Date.now().toString().slice(-4)}`;
    }

    // V1.2: 自动设置项目负责人为当前用户（如果未指定）
    const managerId = body.managerId || userId;

    // 处理项目类型：如果传入的是 projectType 字符串，查找对应的 projectTypeId
    let projectTypeId = body.projectTypeId || null;
    let projectTypeCode = body.projectType || null;
    
    // 如果只有 projectType 字符串，从项目类型表查找对应的 ID
    if (!projectTypeId && projectTypeCode) {
      try {
        const { projectTypes } = await import('@/db/schema');
        const { eq, or, and, isNull } = await import('drizzle-orm');
        
        // 尝试通过名称或代码匹配
        const typeItem = await db
          .select()
          .from(projectTypes)
          .where(and(
            or(
              eq(projectTypes.name, projectTypeCode),
              eq(projectTypes.code, projectTypeCode),
              // 也尝试匹配不带"项目"后缀的名称
              eq(projectTypes.name, projectTypeCode + '项目')
            ),
            isNull(projectTypes.deletedAt)
          ))
          .limit(1);
        
        if (typeItem.length > 0) {
          projectTypeId = typeItem[0].id;
          projectTypeCode = typeItem[0].code;
        }
      } catch (e) {
        console.error('Failed to find project type ID:', e);
      }
    }

    const newProject = await db
      .insert(projects)
      .values({
        projectCode,
        projectName: sanitizedName,
        customerId: body.customerId || null,
        customerName: sanitizedCustomerName,
        projectTypeId: projectTypeId,
        projectType: projectTypeCode, // 保存项目类型代码
        industry: body.industry || null,
        region: body.region || null,
        description: sanitizedDescription,
        managerId, // 自动设置项目负责人
        estimatedAmount: body.estimatedAmount || null,
        startDate: body.startDate || null,
        endDate: body.endDate || null,
        expectedDeliveryDate: body.expectedDeliveryDate || null,
        status: body.status || 'lead', // 默认状态改为lead（商机线索）
        priority: body.priority || 'medium',
        progress: 0,
        risks: sanitizedRisks,
      })
      .returning();

    const projectId = newProject[0].id;

    // V1.2: 如果项目负责人不是当前用户，添加项目负责人为团队成员（manager角色）
    if (managerId !== userId) {
      await db.insert(projectMembers).values({
        projectId,
        userId: managerId,
        role: 'manager',
        invitedBy: userId,
      });
    }

    // V1.2: 添加创建者为项目团队成员（如果创建者不是负责人）
    if (managerId !== userId) {
      await db.insert(projectMembers).values({
        projectId,
        userId,
        role: 'member',
        invitedBy: userId,
      });
    }

    // 更新客户的项目数统计
    if (body.customerId) {
      await syncSingleCustomerStats(body.customerId);
    }

    // ============ 存储幂等性响应 ============
    await storeIdempotencyKey(idempotencyKey, JSON.stringify({
      success: true,
      data: newProject[0],
    }));

    // BUG-017: 统一API响应格式
    return successResponse(newProject[0], { status: 201 });
  } catch (error) {
    console.error('Failed to create project:', error);
    return errorResponse('INTERNAL_ERROR', '创建项目失败');
  }
});

// PUT - 更新项目
export const PUT = withAuth(async (request: NextRequest, context: { userId: number; user?: AuthUser }) => {
  try {
    const userId = context.userId;
    const body = await request.json();
    const { id, projectName, customerName, projectTypeId, industry, region, description, managerId, estimatedAmount, startDate, endDate, expectedDeliveryDate, status, priority, progress, risks, projectStage } = body;

    if (!id) {
      return errorResponse('BAD_REQUEST', '缺少项目ID');
    }

    // V1.2: 权限检查
    const canWrite = await canWriteProject(id, userId);
    if (!canWrite) {
      return errorResponse('FORBIDDEN', '您没有权限编辑此项目');
    }

    // BUG-020: 进度范围校验
    if (progress !== undefined && progress !== null) {
      const progressNum = parseInt(progress);
      if (isNaN(progressNum) || progressNum < 0 || progressNum > 100) {
        return errorResponse('BAD_REQUEST', '项目进度必须在0-100之间');
      }
    }

    // BUG-040: 优先级枚举校验
    if (priority) {
      const validPriorities = ['low', 'medium', 'high', 'urgent'];
      if (!validPriorities.includes(priority)) {
        return errorResponse('BAD_REQUEST', '无效的优先级');
      }
    }

    // TC-B004: 预算上限校验
    const MAX_BUDGET = 10_000_000_000; // 100亿
    if (estimatedAmount !== undefined && estimatedAmount !== null) {
      const amount = parseFloat(estimatedAmount);
      if (!isNaN(amount) && amount > MAX_BUDGET) {
        return errorResponse('BAD_REQUEST', `预计预算不能超过 ${MAX_BUDGET.toLocaleString()} 元`);
      }
      if (!isNaN(amount) && amount < 0) {
        return errorResponse('BAD_REQUEST', '预计预算不能为负数');
      }
    }

    // 查找要更新的项目
    const projectList = await db
      .select()
      .from(projects)
      .where(eq(projects.id, id));

    if (!projectList || projectList.length === 0) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    const currentProject = projectList[0];

    // ============ 乐观锁版本控制 ============
    // 检查版本号是否匹配，防止并发更新冲突
    const { OptimisticLock } = await import('@/lib/idempotency');
    const clientVersion = body.version || body.updatedAt;
    
    if (clientVersion && !OptimisticLock.validateVersion(
      currentProject.updatedAt?.getTime() || null,
      new Date(clientVersion).getTime()
    )) {
      return NextResponse.json(OptimisticLock.createConflictError('项目'), { status: 409 });
    }

    // BUG-031: 项目阶段转换校验
    if (projectStage && projectStage !== currentProject.projectStage) {
      const stageOrder = ['opportunity', 'bidding', 'negotiation', 'contract', 'execution', 'completed'];
      const currentIndex = stageOrder.indexOf(currentProject.projectStage || 'opportunity');
      const targetIndex = stageOrder.indexOf(projectStage);
      
      // 只允许前进到下一阶段或保持当前阶段（允许回退到opportunity作为特殊处理）
      if (targetIndex > currentIndex + 1) {
        return errorResponse('BAD_REQUEST', `项目阶段不能从「${currentProject.projectStage}」跳过中间阶段直接到「${projectStage}」`);
      }
    }

    // BUG-007: 结束日期不能早于开始日期
    const finalStartDate = startDate || currentProject.startDate;
    const finalEndDate = endDate || currentProject.endDate;
    if (finalStartDate && finalEndDate && new Date(finalEndDate) < new Date(finalStartDate)) {
      return errorResponse('BAD_REQUEST', '结束日期不能早于开始日期');
    }

    // 更新项目
    const updatedProject = await db
      .update(projects)
      .set({
        projectName: projectName || projectList[0].projectName,
        customerName: customerName || projectList[0].customerName,
        projectTypeId: projectTypeId !== undefined ? projectTypeId : projectList[0].projectTypeId,
        industry: industry !== undefined ? industry : projectList[0].industry,
        region: region !== undefined ? region : projectList[0].region,
        description: description !== undefined ? description : projectList[0].description,
        managerId: managerId !== undefined ? managerId : projectList[0].managerId,
        estimatedAmount: estimatedAmount !== undefined ? estimatedAmount : projectList[0].estimatedAmount,
        startDate: startDate || projectList[0].startDate,
        endDate: endDate || projectList[0].endDate,
        expectedDeliveryDate: expectedDeliveryDate || projectList[0].expectedDeliveryDate,
        status: status || projectList[0].status,
        priority: priority || projectList[0].priority,
        progress: progress !== undefined ? progress : projectList[0].progress,
        risks: risks !== undefined ? risks : projectList[0].risks,
        // V1.3: 项目阶段更新
        projectStage: projectStage !== undefined ? projectStage : projectList[0].projectStage,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, id))
      .returning();

    // BUG-017: 统一API响应格式
    return successResponse(updatedProject[0]);
  } catch (error) {
    console.error('Failed to update project:', error);
    return errorResponse('INTERNAL_ERROR', '更新项目失败');
  }
});

// DELETE - 删除项目
export const DELETE = withAuth(async (request: NextRequest, context: { userId: number; user?: AuthUser }) => {
  try {
    const userId = context.userId;
    const { searchParams } = new URL(request.url);
    const id = parseInt(searchParams.get('id') || '');

    if (!id) {
      return errorResponse('BAD_REQUEST', '缺少项目ID');
    }

    // V1.2: 权限检查（需要ADMIN权限才能删除）
    const canAdmin = await canAdminProject(id, userId);
    if (!canAdmin) {
      return errorResponse('FORBIDDEN', '您没有权限删除此项目');
    }

    // 查找要删除的项目
    const projectList = await db
      .select()
      .from(projects)
      .where(eq(projects.id, id));

    if (!projectList || projectList.length === 0) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 删除项目
    await db
      .delete(projects)
      .where(eq(projects.id, id));

    return successResponse({ success: true });
  } catch (error) {
    console.error('Failed to delete project:', error);
    return errorResponse('INTERNAL_ERROR', '删除项目失败');
  }
});
