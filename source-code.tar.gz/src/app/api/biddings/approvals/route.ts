/**
 * 投标审批流程API
 * 
 * 支持投标立项审批、文件审批等功能
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, projectBiddings, users } from '@/db/schema';
import { eq, and, desc } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { getPermissionContext } from '@/lib/permissions/data-scope';
import { hasFullAccess } from '@/lib/permissions/middleware';

// 投标审批状态
export type ApprovalStatus = 'draft' | 'pending_approval' | 'approved' | 'rejected';

// 审批记录类型
interface ApprovalRecord {
  id: number;
  projectId: number;
  projectName: string;
  approvalType: 'bid_initiation' | 'bid_price' | 'bid_document';
  status: ApprovalStatus;
  applicantId: number;
  applicantName: string;
  approverId: number | null;
  approverName: string | null;
  appliedAt: Date;
  approvedAt: Date | null;
  comment: string | null;
  details: Record<string, any>;
}

// GET - 获取审批列表
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') as ApprovalStatus | null;
    const approvalType = searchParams.get('approvalType');

    // 检查权限
    const permissionContext = await getPermissionContext(context.userId, 'bidding');
    const canViewAll = hasFullAccess(permissionContext);

    // 获取投标阶段的项目
    const biddingProjects = await db
      .select({
        id: projects.id,
        projectName: projects.projectName,
        projectCode: projects.projectCode,
        customerName: projects.customerName,
        estimatedAmount: projects.estimatedAmount,
        managerId: projects.managerId,
        createdAt: projects.createdAt,
        // 投标信息
        biddingId: projectBiddings.id,
        biddingType: projectBiddings.biddingType,
        bidDeadline: projectBiddings.bidDeadline,
        bidPrice: projectBiddings.bidPrice,
        bidResult: projectBiddings.bidResult,
      })
      .from(projects)
      .leftJoin(
        projectBiddings,
        eq(projects.id, projectBiddings.projectId)
      )
      .where(eq(projects.projectStage, 'bidding'))
      .orderBy(desc(projects.createdAt));

    // 获取项目经理信息
    const managerIds = [...new Set(biddingProjects.map(p => p.managerId).filter(Boolean))];
    const managers = managerIds.length > 0 
      ? await db.query.users.findMany({
          where: and(...managerIds.map(id => eq(users.id, id))),
          columns: { id: true, realName: true },
        })
      : [];

    const managerMap = new Map(managers.map(m => [m.id, m.realName]));

    // 构建审批列表
    const approvalList: ApprovalRecord[] = biddingProjects
      .filter(p => canViewAll || p.managerId === context.userId)
      .map((project, index) => ({
        id: index + 1,
        projectId: project.id,
        projectName: project.projectName,
        approvalType: 'bid_initiation' as const,
        status: project.biddingId ? 'approved' : 'pending_approval',
        applicantId: project.managerId || 0,
        applicantName: managerMap.get(project.managerId) || '未知',
        approverId: null,
        approverName: null,
        appliedAt: project.createdAt,
        approvedAt: project.biddingId ? project.createdAt : null,
        comment: null,
        details: {
          projectCode: project.projectCode,
          customerName: project.customerName,
          estimatedAmount: project.estimatedAmount,
          biddingType: project.biddingType,
          bidDeadline: project.bidDeadline,
          bidPrice: project.bidPrice,
        },
      }));

    // 按状态筛选
    let filteredList = approvalList;
    if (status) {
      filteredList = approvalList.filter(item => item.status === status);
    }
    if (approvalType) {
      filteredList = filteredList.filter(item => item.approvalType === approvalType);
    }

    return successResponse({
      list: filteredList,
      total: filteredList.length,
    });
  } catch (error) {
    console.error('Failed to fetch approvals:', error);
    return errorResponse('INTERNAL_ERROR', '获取审批列表失败');
  }
});

// POST - 提交审批
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const body = await request.json();
    const { projectId, approvalType, details } = body;

    if (!projectId || !approvalType) {
      return errorResponse('BAD_REQUEST', '缺少必要参数');
    }

    // 检查权限
    const permissionContext = await getPermissionContext(context.userId, 'bidding');
    const canApprove = hasFullAccess(permissionContext);

    // 获取项目信息
    const project = await db.query.projects.findFirst({
      where: eq(projects.id, projectId),
    });

    if (!project) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 检查是否是项目经理或管理员
    const isManager = project.managerId === context.userId;
    if (!isManager && !canApprove) {
      return errorResponse('FORBIDDEN', '无权提交审批');
    }

    // 根据审批类型处理
    switch (approvalType) {
      case 'bid_initiation':
        // 投标立项审批
        if (project.projectStage !== 'opportunity') {
          return errorResponse('BAD_REQUEST', '项目当前阶段不支持投标立项');
        }
        
        // 更新项目阶段为投标审批中
        await db
          .update(projects)
          .set({
            projectStage: 'bidding',
            updatedAt: new Date(),
          })
          .where(eq(projects.id, projectId));

        break;

      case 'bid_price':
        // 投标报价审批
        if (!details?.bidPrice) {
          return errorResponse('BAD_REQUEST', '缺少投标报价');
        }
        
        // 记录报价到投标信息
        const existingBidding = await db.query.projectBiddings.findFirst({
          where: eq(projectBiddings.projectId, projectId),
        });

        if (existingBidding) {
          await db
            .update(projectBiddings)
            .set({
              bidPrice: details.bidPrice,
              updatedAt: new Date(),
            })
            .where(eq(projectBiddings.projectId, projectId));
        }

        break;

      case 'bid_document':
        // 投标文件审批
        if (!details?.documents) {
          return errorResponse('BAD_REQUEST', '缺少投标文件');
        }
        
        const bidding = await db.query.projectBiddings.findFirst({
          where: eq(projectBiddings.projectId, projectId),
        });

        if (bidding) {
          await db
            .update(projectBiddings)
            .set({
              bidDocuments: details.documents,
              updatedAt: new Date(),
            })
            .where(eq(projectBiddings.projectId, projectId));
        }

        break;

      default:
        return errorResponse('BAD_REQUEST', '未知的审批类型');
    }

    return successResponse({
      message: '审批提交成功',
      projectId,
      approvalType,
    });
  } catch (error) {
    console.error('Failed to submit approval:', error);
    return errorResponse('INTERNAL_ERROR', '提交审批失败');
  }
});

// PUT - 审批操作
export const PUT = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    const body = await request.json();
    const { projectId, action, comment } = body;

    if (!projectId || !action) {
      return errorResponse('BAD_REQUEST', '缺少必要参数');
    }

    // 检查审批权限
    const permissionContext = await getPermissionContext(context.userId, 'bidding');
    const canApprove = hasFullAccess(permissionContext);

    if (!canApprove) {
      return errorResponse('FORBIDDEN', '无审批权限');
    }

    // 获取项目
    const project = await db.query.projects.findFirst({
      where: eq(projects.id, projectId),
    });

    if (!project) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 执行审批操作
    switch (action) {
      case 'approve':
        // 审批通过
        if (project.projectStage === 'bidding') {
          // 创建投标记录（如果不存在）
          const existingBidding = await db.query.projectBiddings.findFirst({
            where: eq(projectBiddings.projectId, projectId),
          });

          if (!existingBidding) {
            await db.insert(projectBiddings).values({
              projectId,
              bidResult: 'pending',
              bidBondStatus: 'unpaid',
              createdAt: new Date(),
              updatedAt: new Date(),
            });
          }
        }

        return successResponse({
          message: '审批通过',
          projectId,
        });

      case 'reject':
        // 审批拒绝
        await db
          .update(projects)
          .set({
            projectStage: 'opportunity',
            updatedAt: new Date(),
          })
          .where(eq(projects.id, projectId));

        return successResponse({
          message: '审批拒绝',
          projectId,
          comment,
        });

      default:
        return errorResponse('BAD_REQUEST', '未知的审批操作');
    }
  } catch (error) {
    console.error('Failed to process approval:', error);
    return errorResponse('INTERNAL_ERROR', '审批操作失败');
  }
});
