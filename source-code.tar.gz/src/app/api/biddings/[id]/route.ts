import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, projectBiddings } from '@/db/schema';
import { eq } from 'drizzle-orm';

// GET - 获取投标详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, parseInt(id)));

    if (!project) {
      return NextResponse.json(
        { success: false, error: '投标项目不存在' },
        { status: 404 }
      );
    }

    const [bidding] = await db
      .select()
      .from(projectBiddings)
      .where(eq(projectBiddings.projectId, parseInt(id)));

    return NextResponse.json({
      success: true,
      data: {
        ...project,
        bidding: bidding || null,
      },
    });
  } catch (error) {
    console.error('Failed to fetch bidding:', error);
    return NextResponse.json(
      { success: false, error: '获取投标详情失败' },
      { status: 500 }
    );
  }
}

// PUT - 更新投标信息
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // 更新投标详情
    const [updatedBidding] = await db
      .update(projectBiddings)
      .set({
        biddingType: body.biddingType,
        bidDeadline: body.bidDeadline ? new Date(body.bidDeadline) : null,
        bidBondAmount: body.bidBondAmount,
        bidBondStatus: body.bidBondStatus,
        bidBondPayDate: body.bidBondPayDate || null,
        bidBondReturnDate: body.bidBondReturnDate || null,
        bidPrice: body.bidPrice,
        bidOpenDate: body.bidOpenDate ? new Date(body.bidOpenDate) : null,
        bidTeam: body.bidTeam,
        tenderDocuments: body.tenderDocuments,
        bidDocuments: body.bidDocuments,
        reviewComments: body.reviewComments,
        updatedAt: new Date(),
      })
      .where(eq(projectBiddings.projectId, parseInt(id)))
      .returning();

    return NextResponse.json({
      success: true,
      data: updatedBidding,
    });
  } catch (error) {
    console.error('Failed to update bidding:', error);
    return NextResponse.json(
      { success: false, error: '更新投标失败' },
      { status: 500 }
    );
  }
}
