import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, projectBiddings, projectSettlements } from '@/db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { canWriteProject } from '@/lib/permissions/project';

// POST - 标记中标
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');
    const body = await request.json();

    // 权限检查
    const canWrite = await canWriteProject(projectId, context.userId);
    if (!canWrite) {
      return errorResponse('FORBIDDEN', '您没有权限修改此项目');
    }

    // 检查项目是否存在且未删除
    const [existingProject] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!existingProject) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 检查项目是否处于投标阶段
    if (existingProject.projectStage !== 'bidding') {
      return errorResponse('BAD_REQUEST', '只有投标阶段的项目才能标记中标');
    }

    // 验证合同金额
    const contractAmount = body.contractAmount;
    if (!contractAmount || parseFloat(contractAmount) <= 0) {
      return errorResponse('BAD_REQUEST', '中标时必须填写有效的合同金额');
    }

    // 更新项目状态
    const [updatedProject] = await db
      .update(projects)
      .set({
        projectStage: 'execution',
        status: 'ongoing',
        bidResult: 'won',
        contractAmount: contractAmount,
        contractSignDate: body.contractSignDate || null,
        contractStartDate: body.contractStartDate || null,
        contractEndDate: body.contractEndDate || null,
        actualAmount: contractAmount,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId))
      .returning();

    // 更新投标信息
    await db
      .update(projectBiddings)
      .set({
        bidResult: 'won',
        bidPrice: body.bidPrice || contractAmount,
        updatedAt: new Date(),
      })
      .where(eq(projectBiddings.projectId, projectId));

    // 创建结算记录
    await db
      .insert(projectSettlements)
      .values({
        projectId: projectId,
        settlementAmount: contractAmount,
      });

    return successResponse({
      ...updatedProject,
      message: '恭喜！项目已中标，进入执行阶段',
    });
  } catch (error) {
    console.error('Failed to mark as won:', error);
    return errorResponse('INTERNAL_ERROR', '标记中标失败');
  }
});
