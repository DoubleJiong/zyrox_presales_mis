import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, projectBiddings } from '@/db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { canWriteProject } from '@/lib/permissions/project';

// POST - 标记落标
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; params?: Record<string, string> }
) => {
  try {
    const projectId = parseInt(context.params?.id || '0');
    const body = await request.json();

    // 权限检查
    const canWrite = await canWriteProject(projectId, context.userId);
    if (!canWrite) {
      return errorResponse('FORBIDDEN', '您没有权限修改此项目');
    }

    // 检查项目是否存在且未删除
    const [existingProject] = await db
      .select()
      .from(projects)
      .where(and(
        eq(projects.id, projectId),
        isNull(projects.deletedAt)
      ))
      .limit(1);

    if (!existingProject) {
      return errorResponse('NOT_FOUND', '项目不存在');
    }

    // 检查项目是否处于投标阶段
    if (existingProject.projectStage !== 'bidding') {
      return errorResponse('BAD_REQUEST', '只有投标阶段的项目才能标记落标');
    }

    // 更新项目状态
    // 注意：落标后保持bidding阶段，但设置status为lost和bidResult为lost
    // 这样可以保持状态机的一致性，避免回退到opportunity阶段的逻辑矛盾
    const [updatedProject] = await db
      .update(projects)
      .set({
        projectStage: 'bidding', // 保持投标阶段，不回退
        status: 'lost', // 修改为lost状态而不是cancelled
        bidResult: 'lost',
        winCompetitor: body.winCompetitor || null,
        loseReason: body.loseReason || null,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId))
      .returning();

    // 更新投标信息
    await db
      .update(projectBiddings)
      .set({
        bidResult: 'lost',
        loseReason: body.loseReason || null,
        winCompetitor: body.winCompetitor || null,
        lessonsLearned: body.lessonsLearned || null,
        updatedAt: new Date(),
      })
      .where(eq(projectBiddings.projectId, projectId));

    return successResponse({
      ...updatedProject,
      message: '项目已标记为落标',
    });
  } catch (error) {
    console.error('Failed to mark as lost:', error);
    return errorResponse('INTERNAL_ERROR', '标记落标失败');
  }
});
