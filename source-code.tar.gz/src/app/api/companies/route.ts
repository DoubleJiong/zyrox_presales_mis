import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { subsidiaries } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';

// GET - 获取分子公司列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const companyType = searchParams.get('companyType');

    let query = db
      .select({
        id: subsidiaries.id,
        subsidiaryCode: subsidiaries.subsidiaryCode,
        subsidiaryName: subsidiaries.subsidiaryName,
        companyType: subsidiaries.companyType,
        regions: subsidiaries.regions,
        address: subsidiaries.address,
        contactPerson: subsidiaries.contactPerson,
        contactPhone: subsidiaries.contactPhone,
        status: subsidiaries.status,
        createdAt: subsidiaries.createdAt,
        updatedAt: subsidiaries.updatedAt,
      })
      .from(subsidiaries)
      .orderBy(desc(subsidiaries.createdAt));

    // 状态筛选
    if (status && status !== 'all') {
      const result = await db
        .select({
          id: subsidiaries.id,
          subsidiaryCode: subsidiaries.subsidiaryCode,
          subsidiaryName: subsidiaries.subsidiaryName,
          companyType: subsidiaries.companyType,
          regions: subsidiaries.regions,
          address: subsidiaries.address,
          contactPerson: subsidiaries.contactPerson,
          contactPhone: subsidiaries.contactPhone,
          status: subsidiaries.status,
          createdAt: subsidiaries.createdAt,
          updatedAt: subsidiaries.updatedAt,
        })
        .from(subsidiaries)
        .where(eq(subsidiaries.status, status))
        .orderBy(desc(subsidiaries.createdAt));
      
      return successResponse(result);
    }

    // 公司类型筛选
    if (companyType && companyType !== 'all') {
      const result = await db
        .select({
          id: subsidiaries.id,
          subsidiaryCode: subsidiaries.subsidiaryCode,
          subsidiaryName: subsidiaries.subsidiaryName,
          companyType: subsidiaries.companyType,
          regions: subsidiaries.regions,
          address: subsidiaries.address,
          contactPerson: subsidiaries.contactPerson,
          contactPhone: subsidiaries.contactPhone,
          status: subsidiaries.status,
          createdAt: subsidiaries.createdAt,
          updatedAt: subsidiaries.updatedAt,
        })
        .from(subsidiaries)
        .where(eq(subsidiaries.companyType, companyType))
        .orderBy(desc(subsidiaries.createdAt));
      
      return successResponse(result);
    }

    const result = await query;
    return successResponse(result);
  } catch (error) {
    console.error('Failed to fetch subsidiaries:', error);
    return errorResponse('INTERNAL_ERROR', '获取分子公司列表失败');
  }
}

// POST - 创建分子公司
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subsidiaryCode, subsidiaryName, companyType, regions, address, contactPerson, contactPhone, status } = body;

    // 验证必填字段
    if (!subsidiaryCode || !subsidiaryName) {
      return errorResponse('BAD_REQUEST', '编码和名称为必填项');
    }

    // 创建新分子公司
    const newSubsidiary = await db
      .insert(subsidiaries)
      .values({
        subsidiaryCode,
        subsidiaryName,
        companyType: companyType || 'sales_branch',
        regions: regions || [],
        address: address || null,
        contactPerson: contactPerson || null,
        contactPhone: contactPhone || null,
        status: status || 'active',
      })
      .returning();

    return successResponse(newSubsidiary[0], { status: 201 });
  } catch (error) {
    console.error('Failed to create subsidiary:', error);
    return errorResponse('INTERNAL_ERROR', '创建分子公司失败');
  }
}

// PUT - 更新分子公司
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, subsidiaryCode, subsidiaryName, companyType, regions, address, contactPerson, contactPhone, status } = body;

    if (!id) {
      return errorResponse('BAD_REQUEST', '分子公司ID为必填项');
    }

    const updateData: Record<string, any> = {
      updatedAt: new Date(),
    };
    
    if (subsidiaryCode !== undefined) updateData.subsidiaryCode = subsidiaryCode;
    if (subsidiaryName !== undefined) updateData.subsidiaryName = subsidiaryName;
    if (companyType !== undefined) updateData.companyType = companyType;
    if (regions !== undefined) updateData.regions = regions;
    if (address !== undefined) updateData.address = address;
    if (contactPerson !== undefined) updateData.contactPerson = contactPerson;
    if (contactPhone !== undefined) updateData.contactPhone = contactPhone;
    if (status !== undefined) updateData.status = status;

    const updatedSubsidiary = await db
      .update(subsidiaries)
      .set(updateData)
      .where(eq(subsidiaries.id, id))
      .returning();

    if (!updatedSubsidiary.length) {
      return errorResponse('NOT_FOUND', '分子公司不存在');
    }

    return successResponse(updatedSubsidiary[0]);
  } catch (error) {
    console.error('Failed to update subsidiary:', error);
    return errorResponse('INTERNAL_ERROR', '更新分子公司失败');
  }
}

// DELETE - 删除分子公司
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = parseInt(searchParams.get('id') || '');

    if (!id) {
      return errorResponse('BAD_REQUEST', '分子公司ID为必填项');
    }

    await db.delete(subsidiaries).where(eq(subsidiaries.id, id));

    return successResponse({ success: true });
  } catch (error) {
    console.error('Failed to delete subsidiary:', error);
    return errorResponse('INTERNAL_ERROR', '删除分子公司失败');
  }
}
