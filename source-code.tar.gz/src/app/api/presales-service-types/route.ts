import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { presalesServiceTypes } from '@/db/schema';
import { eq, desc, sql, and, isNull } from 'drizzle-orm';

// 获取售前服务类型列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const serviceCategory = searchParams.get('serviceCategory');
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');

    const conditions: any[] = [];

    if (status) {
      conditions.push(eq(presalesServiceTypes.status, status));
    }

    if (serviceCategory) {
      conditions.push(eq(presalesServiceTypes.serviceCategory, serviceCategory));
    }

    // 获取总数
    const [countResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(presalesServiceTypes)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    const total = countResult?.count || 0;

    // 获取服务类型列表
    const types = await db
      .select()
      .from(presalesServiceTypes)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(presalesServiceTypes.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    return NextResponse.json({
      success: true,
      data: types,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  } catch (error) {
    console.error('Get presales service types API error:', error);
    return NextResponse.json(
      { success: false, error: '获取售前服务类型列表失败' },
      { status: 500 }
    );
  }
}

// 创建售前服务类型
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      serviceCode,
      serviceName,
      serviceCategory,
      description,
      weight = 10,
      standardDuration,
      isRequired = false,
      sortOrder = 0,
      status = 'active',
    } = body;

    if (!serviceCode || !serviceName || !serviceCategory) {
      return NextResponse.json(
        { success: false, error: '服务编码、名称和分类不能为空' },
        { status: 400 }
      );
    }

    const [newType] = await db
      .insert(presalesServiceTypes)
      .values({
        serviceCode,
        serviceName,
        serviceCategory,
        description,
        weight,
        standardDuration,
        isRequired,
        sortOrder,
        status,
      })
      .returning();

    return NextResponse.json({
      success: true,
      data: newType,
      message: '售前服务类型创建成功',
    });
  } catch (error) {
    console.error('Create presales service type API error:', error);
    return NextResponse.json(
      { success: false, error: '创建售前服务类型失败' },
      { status: 500 }
    );
  }
}
