import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { customers, projects } from '@/db/schema';
import { eq, and, isNull, sql } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';
import { successResponse, errorResponse } from '@/lib/api-response';
import { isSystemAdmin } from '@/lib/permissions/project';

/**
 * POST /api/customers/sync-stats
 * 同步客户统计数据（重新计算 totalAmount 和 currentProjectCount）
 */
export const POST = withAuth(async (
  request: NextRequest,
  context: { userId: number; user?: any }
) => {
  try {
    // 只有管理员可以执行此操作
    const isAdmin = await isSystemAdmin(context.userId);
    if (!isAdmin) {
      return errorResponse('FORBIDDEN', '只有管理员可以执行此操作');
    }

    // 获取所有客户
    const allCustomers = await db
      .select({ id: customers.id })
      .from(customers)
      .where(isNull(customers.deletedAt));

    let updatedCount = 0;
    const errors: string[] = [];

    // 逐个客户更新统计
    for (const customer of allCustomers) {
      try {
        // 计算项目数量和金额统计（非删除状态）
        const [projectStats] = await db
          .select({
            count: sql<number>`COUNT(*)`,
            // 优先使用 actualAmount，如果没有则使用 estimatedAmount
            totalAmount: sql<string>`COALESCE(SUM(CAST(COALESCE(${projects.actualAmount}, ${projects.estimatedAmount}, 0) AS DECIMAL)), 0)`,
            maxProjectAmount: sql<string>`COALESCE(MAX(CAST(COALESCE(${projects.actualAmount}, ${projects.estimatedAmount}, 0) AS DECIMAL)), 0)`,
          })
          .from(projects)
          .where(and(
            eq(projects.customerId, customer.id),
            isNull(projects.deletedAt)
          ));

        // 计算进行中项目数量
        const [activeProjectStats] = await db
          .select({
            count: sql<number>`COUNT(*)`,
          })
          .from(projects)
          .where(and(
            eq(projects.customerId, customer.id),
            sql`${projects.status} IN ('lead', 'pending', 'in_progress', 'bidding', 'negotiation')`,
            isNull(projects.deletedAt)
          ));

        // 更新客户统计
        await db
          .update(customers)
          .set({
            totalAmount: projectStats.totalAmount || '0',
            maxProjectAmount: projectStats.maxProjectAmount || '0',
            currentProjectCount: activeProjectStats.count || 0,
            updatedAt: new Date(),
          })
          .where(eq(customers.id, customer.id));

        updatedCount++;
      } catch (err) {
        errors.push(`客户 ${customer.id} 更新失败: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    return successResponse({
      message: '客户统计数据同步完成',
      updatedCount,
      totalCustomers: allCustomers.length,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    console.error('Failed to sync customer stats:', error);
    return errorResponse('INTERNAL_ERROR', '同步客户统计数据失败');
  }
});

/**
 * POST /api/customers/[id]/sync-stats
 * 同步单个客户的统计数据
 */
export async function syncSingleCustomerStats(customerId: number) {
  // 计算中标项目的总金额和最大项目金额（只统计中标项目）
  const [projectStats] = await db
    .select({
      count: sql<number>`COUNT(*)`,
      // 优先使用 actualAmount，如果没有则使用 estimatedAmount
      totalAmount: sql<string>`COALESCE(SUM(CAST(COALESCE(${projects.actualAmount}, ${projects.estimatedAmount}, 0) AS DECIMAL)), 0)`,
      maxProjectAmount: sql<string>`COALESCE(MAX(CAST(COALESCE(${projects.actualAmount}, ${projects.estimatedAmount}, 0) AS DECIMAL)), 0)`,
    })
    .from(projects)
    .where(and(
      eq(projects.customerId, customerId),
      eq(projects.status, 'won'),  // 只统计中标项目的金额
      isNull(projects.deletedAt)
    ));

  // 计算进行中项目数量（包含lead状态）
  const [activeProjectStats] = await db
    .select({
      count: sql<number>`COUNT(*)`,
    })
    .from(projects)
    .where(and(
      eq(projects.customerId, customerId),
      sql`${projects.status} IN ('lead', 'pending', 'in_progress', 'bidding', 'negotiation')`,
      isNull(projects.deletedAt)
    ));

  // 更新客户统计
  await db
    .update(customers)
    .set({
      totalAmount: projectStats.totalAmount || '0',
      maxProjectAmount: projectStats.maxProjectAmount || '0',
      currentProjectCount: activeProjectStats.count || 0,
      updatedAt: new Date(),
    })
    .where(eq(customers.id, customerId));

  return {
    totalAmount: projectStats.totalAmount || '0',
    maxProjectAmount: projectStats.maxProjectAmount || '0',
    currentProjectCount: activeProjectStats.count || 0,
  };
}
