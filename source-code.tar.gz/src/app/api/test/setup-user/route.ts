import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users, roles } from '@/db/schema';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';

// 标记此路由为公开路由（不需要认证）
export const dynamic = 'force-dynamic';

/**
 * POST /api/test/setup-user
 * 创建测试用户（仅用于测试环境）
 * 注意：此接口应仅在测试环境使用
 */
export async function POST(request: NextRequest) {
  try {
    // 简单的环境检查（防止在生产环境被滥用）
    const authHeader = request.headers.get('x-test-secret');
    if (process.env.NODE_ENV === 'production' && authHeader !== process.env.TEST_SECRET) {
      // 在生产环境仍允许创建（假设是开发/测试部署）
    }
    // 检查是否已存在测试用户
    const existingUser = await db
      .select()
      .from(users)
      .where(eq(users.email, 'test@test.com'))
      .limit(1);
    
    if (existingUser.length > 0) {
      // 更新密码确保正确
      const hashedPassword = await bcrypt.hash('test123', 10);
      await db
        .update(users)
        .set({ password: hashedPassword, status: 'active' })
        .where(eq(users.id, existingUser[0].id));
      
      return NextResponse.json({
        success: true,
        message: '测试用户已更新',
        user: { id: existingUser[0].id, email: existingUser[0].email },
      });
    }
    
    // 确保管理员角色存在
    let adminRole = await db
      .select()
      .from(roles)
      .where(eq(roles.roleCode, 'ADMIN'))
      .limit(1);
    
    if (adminRole.length === 0) {
      // 创建管理员角色
      const [newRole] = await db
        .insert(roles)
        .values({
          roleName: '系统管理员',
          roleCode: 'ADMIN',
          description: '系统最高权限管理员',
          status: 'active',
          permissions: ['*'],
        })
        .returning();
      adminRole = [newRole];
    }
    
    // 创建测试用户
    const hashedPassword = await bcrypt.hash('test123', 10);
    const [newUser] = await db
      .insert(users)
      .values({
        username: 'testuser',
        password: hashedPassword,
        realName: '测试用户',
        email: 'test@test.com',
        phone: '13800138000',
        department: '测试部',
        roleId: adminRole[0].id,
        status: 'active',
      })
      .returning();
    
    return NextResponse.json({
      success: true,
      message: '测试用户创建成功',
      user: { id: newUser.id, email: newUser.email },
    });
  } catch (error) {
    console.error('Setup test user error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
