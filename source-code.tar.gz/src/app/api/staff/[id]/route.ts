import { NextRequest } from 'next/server';
import { db } from '@/db';
import { users, roles, userRoles } from '@/db/schema';
import { eq, inArray } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';

// GET - 获取单个人员详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const staffId = parseInt(id);

    if (isNaN(staffId)) {
      return errorResponse('BAD_REQUEST', '无效的人员ID');
    }

    const staff = await db
      .select({
        id: users.id,
        username: users.username,
        realName: users.realName,
        email: users.email,
        phone: users.phone,
        department: users.department,
        roleId: users.roleId,
        roleName: roles.roleName,
        roleCode: roles.roleCode,
        status: users.status,
        avatar: users.avatar,
        lastLoginTime: users.lastLoginTime,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        hireDate: users.hireDate,
        position: users.position,
        location: users.location,
        birthday: users.birthday,
        gender: users.gender,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .where(eq(users.id, staffId))
      .limit(1);

    if (!staff || staff.length === 0) {
      return errorResponse('NOT_FOUND', '人员不存在');
    }

    // 获取用户的所有角色
    const userRolesList = await db
      .select({
        roleId: userRoles.roleId,
        roleName: roles.roleName,
        roleCode: roles.roleCode,
      })
      .from(userRoles)
      .leftJoin(roles, eq(userRoles.roleId, roles.id))
      .where(eq(userRoles.userId, staffId));

    return successResponse({
      ...staff[0],
      roleIds: userRolesList.map((r) => r.roleId),
      roleNames: userRolesList.map((r) => r.roleName).filter(Boolean),
    });
  } catch (error) {
    console.error('Failed to fetch staff:', error);
    return errorResponse('INTERNAL_ERROR', '获取人员信息失败');
  }
}

// PUT - 更新人员信息
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const staffId = parseInt(id);
    const body = await request.json();

    if (isNaN(staffId)) {
      return errorResponse('BAD_REQUEST', '无效的人员ID');
    }

    // 检查人员是否存在
    const existingStaff = await db
      .select()
      .from(users)
      .where(eq(users.id, staffId))
      .limit(1);

    if (!existingStaff || existingStaff.length === 0) {
      return errorResponse('NOT_FOUND', '人员不存在');
    }

    // 准备更新数据
    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    // 只更新提供的字段
    if (body.realName !== undefined) updateData.realName = body.realName;
    if (body.email !== undefined) updateData.email = body.email;
    if (body.phone !== undefined) updateData.phone = body.phone || null;
    if (body.department !== undefined) updateData.department = body.department || null;
    if (body.position !== undefined) updateData.position = body.position || null;
    if (body.status !== undefined) updateData.status = body.status;
    if (body.gender !== undefined) updateData.gender = body.gender || null;
    if (body.birthday !== undefined) updateData.birthday = body.birthday || null;
    if (body.hireDate !== undefined) updateData.hireDate = body.hireDate || null;
    if (body.location !== undefined) updateData.location = body.location || null;
    if (body.avatar !== undefined) updateData.avatar = body.avatar || null;
    // 兼容单选和多选：如果有 roleIds 则使用第一个作为主角色，否则使用 roleId
    if (body.roleIds !== undefined && Array.isArray(body.roleIds)) {
      updateData.roleId = body.roleIds.length > 0 ? body.roleIds[0] : null;
    } else if (body.roleId !== undefined) {
      updateData.roleId = body.roleId || null;
    }

    // 如果有密码更新，需要加密
    if (body.password) {
      const bcrypt = require('bcrypt');
      updateData.password = await bcrypt.hash(body.password, 10);
    }

    // 更新人员
    const updatedStaff = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, staffId))
      .returning();

    // 更新用户角色关联（如果提供了 roleIds）
    if (body.roleIds !== undefined && Array.isArray(body.roleIds)) {
      // 先删除现有关联
      await db.delete(userRoles).where(eq(userRoles.userId, staffId));

      // 插入新关联
      if (body.roleIds.length > 0) {
        await db.insert(userRoles).values(
          body.roleIds.map((roleId: number) => ({
            userId: staffId,
            roleId: roleId,
          }))
        );
      }
    }

    // 获取更新后的角色列表
    const updatedRoles = await db
      .select({
        roleId: userRoles.roleId,
        roleName: roles.roleName,
      })
      .from(userRoles)
      .leftJoin(roles, eq(userRoles.roleId, roles.id))
      .where(eq(userRoles.userId, staffId));

    return successResponse({
      ...updatedStaff[0],
      roleIds: updatedRoles.map((r) => r.roleId),
      roleNames: updatedRoles.map((r) => r.roleName).filter(Boolean),
    });
  } catch (error) {
    console.error('Failed to update staff:', error);
    return errorResponse('INTERNAL_ERROR', '更新人员失败');
  }
}

// DELETE - 删除人员
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const staffId = parseInt(id);

    if (isNaN(staffId)) {
      return errorResponse('BAD_REQUEST', '无效的人员ID');
    }

    // 检查人员是否存在
    const existingStaff = await db
      .select()
      .from(users)
      .where(eq(users.id, staffId))
      .limit(1);

    if (!existingStaff || existingStaff.length === 0) {
      return errorResponse('NOT_FOUND', '人员不存在');
    }

    // 删除人员
    await db.delete(users).where(eq(users.id, staffId));

    return successResponse({ success: true });
  } catch (error) {
    console.error('Failed to delete staff:', error);
    return errorResponse('INTERNAL_ERROR', '删除人员失败');
  }
}
