import { NextRequest } from 'next/server';
import { db } from '@/db';
import { users, roles, userRoles } from '@/db/schema';
import { desc, eq, inArray } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';

// GET - 获取人员列表
export const GET = withAuth(async () => {
  try {
    const staffList = await db
      .select({
        id: users.id,
        username: users.username,
        realName: users.realName,
        email: users.email,
        phone: users.phone,
        department: users.department,
        roleId: users.roleId,
        roleName: roles.roleName,
        roleCode: roles.roleCode,
        status: users.status,
        avatar: users.avatar,
        lastLoginTime: users.lastLoginTime,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        hireDate: users.hireDate,
        position: users.position,
        location: users.location,
        birthday: users.birthday,
        gender: users.gender,
      })
      .from(users)
      .leftJoin(roles, eq(users.roleId, roles.id))
      .orderBy(desc(users.createdAt));

    // 获取所有用户的角色关联
    const userIds = staffList.map((s) => s.id);
    const allUserRoles = userIds.length > 0
      ? await db
          .select({
            userId: userRoles.userId,
            roleId: userRoles.roleId,
            roleName: roles.roleName,
            roleCode: roles.roleCode,
          })
          .from(userRoles)
          .leftJoin(roles, eq(userRoles.roleId, roles.id))
          .where(inArray(userRoles.userId, userIds))
      : [];

    // 按用户ID分组角色
    const userRolesMap = allUserRoles.reduce((acc, ur) => {
      if (!acc[ur.userId]) {
        acc[ur.userId] = [];
      }
      if (ur.roleId) {
        acc[ur.userId].push({
          id: ur.roleId,
          name: ur.roleName,
          code: ur.roleCode,
        });
      }
      return acc;
    }, {} as Record<number, Array<{ id: number; name: string | null; code: string | null }>>);

    // 组装返回数据
    const result = staffList.map((staff) => {
      const staffRoles = userRolesMap[staff.id] || [];
      return {
        ...staff,
        roleIds: staffRoles.map((r) => r.id),
        roleNames: staffRoles.map((r) => r.name).filter(Boolean),
      };
    });

    return successResponse(result);
  } catch (error) {
    console.error('Failed to fetch staff:', error);
    return errorResponse('INTERNAL_ERROR', '获取人员列表失败');
  }
});

// POST - 创建新人员
export const POST = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const body = await request.json();
    const bcrypt = require('bcrypt');
    const hashedPassword = await bcrypt.hash(body.password || '123456', 10);

    const newStaff = await db
      .insert(users)
      .values({
        username: body.username,
        password: hashedPassword,
        realName: body.realName,
        email: body.email,
        phone: body.phone || null,
        department: body.department || null,
        roleId: body.roleId || null,
        avatar: body.avatar || null,
        status: body.status || 'active',
      })
      .returning();

    return successResponse(newStaff[0]);
  } catch (error) {
    console.error('Failed to create staff:', error);
    return errorResponse('INTERNAL_ERROR', '创建人员失败');
  }
});

// PUT - 更新人员
export const PUT = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const body = await request.json();
    const { id, ...updateData } = body;

    if (!id) {
      return errorResponse('BAD_REQUEST', '缺少人员ID');
    }

    // 检查人员是否存在
    const existingStaff = await db
      .select()
      .from(users)
      .where(eq(users.id, id));

    if (!existingStaff || existingStaff.length === 0) {
      return errorResponse('NOT_FOUND', '人员不存在');
    }

    // 如果有密码更新，需要加密
    let hashedPassword = existingStaff[0].password;
    if (updateData.password) {
      const bcrypt = require('bcrypt');
      hashedPassword = await bcrypt.hash(updateData.password, 10);
    }

    // 更新人员
    const updatedStaff = await db
      .update(users)
      .set({
        username: updateData.username || existingStaff[0].username,
        realName: updateData.realName || existingStaff[0].realName,
        email: updateData.email || existingStaff[0].email,
        phone: updateData.phone !== undefined ? updateData.phone : existingStaff[0].phone,
        department: updateData.department !== undefined ? updateData.department : existingStaff[0].department,
        roleId: updateData.roleId !== undefined ? updateData.roleId : existingStaff[0].roleId,
        avatar: updateData.avatar !== undefined ? updateData.avatar : existingStaff[0].avatar,
        status: updateData.status || existingStaff[0].status,
        password: hashedPassword,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();

    return successResponse(updatedStaff[0]);
  } catch (error) {
    console.error('Failed to update staff:', error);
    return errorResponse('INTERNAL_ERROR', '更新人员失败');
  }
});

// DELETE - 删除人员
export const DELETE = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const { searchParams } = new URL(request.url);
    const id = parseInt(searchParams.get('id') || '');

    if (!id) {
      return errorResponse('BAD_REQUEST', '缺少人员ID');
    }

    // 检查人员是否存在
    const existingStaff = await db
      .select()
      .from(users)
      .where(eq(users.id, id));

    if (!existingStaff || existingStaff.length === 0) {
      return errorResponse('NOT_FOUND', '人员不存在');
    }

    // 删除人员
    await db
      .delete(users)
      .where(eq(users.id, id));

    return successResponse({ success: true });
  } catch (error) {
    console.error('Failed to delete staff:', error);
    return errorResponse('INTERNAL_ERROR', '删除人员失败');
  }
});
