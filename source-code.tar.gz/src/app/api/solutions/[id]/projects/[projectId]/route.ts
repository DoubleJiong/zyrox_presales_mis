/**
 * 方案-项目关联详情 API
 * 
 * 端点：
 * - GET /api/solutions/[id]/projects/[projectId] - 获取关联详情
 * - PATCH /api/solutions/[id]/projects/[projectId] - 更新贡献确认
 * 
 * 设计原则：
 * - 数据修改入口唯一：项目关联在项目管理模块操作
 * - 本API仅提供查询和贡献确认功能
 */

import { NextRequest, NextResponse } from 'next/server';
import { solutionProjectService } from '@/services/solution-project.service';
import { z } from 'zod';

// 参数验证
const updateContributionSchema = z.object({
  contributionConfirmed: z.boolean(),
  contributionRatio: z.string().optional(),
  estimatedValue: z.string().optional(),
  actualValue: z.string().optional(),
  winContributionScore: z.string().optional(),
  feedbackScore: z.string().optional(),
  feedbackContent: z.string().optional(),
});

/**
 * GET /api/solutions/[id]/projects/[projectId]
 * 获取关联详情
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; projectId: string }> }
) {
  try {
    const { id: idStr, projectId: projectIdStr } = await params;
    const solutionId = parseInt(idStr, 10);
    const projectId = parseInt(projectIdStr, 10);
    
    if (isNaN(solutionId) || isNaN(projectId)) {
      return NextResponse.json(
        { error: '无效的ID' },
        { status: 400 }
      );
    }
    
    const summary = await solutionProjectService.getSolutionStatsSummary(solutionId);
    
    return NextResponse.json({
      success: true,
      data: summary,
    });
    
  } catch (error) {
    console.error('获取关联详情失败:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : '获取关联详情失败' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/solutions/[id]/projects/[projectId]
 * 更新贡献确认
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; projectId: string }> }
) {
  try {
    const { projectId: projectIdStr } = await params;
    const associationId = parseInt(projectIdStr, 10);
    
    if (isNaN(associationId)) {
      return NextResponse.json(
        { error: '无效的ID' },
        { status: 400 }
      );
    }
    
    const body = await request.json();
    const validated = updateContributionSchema.parse(body);
    
    // TODO: 从 session 获取用户ID
    const userId = 1; // 临时硬编码
    
    const updated = await solutionProjectService.updateContribution({
      id: associationId,
      contributionConfirmed: validated.contributionConfirmed,
      contributionRatio: validated.contributionRatio ? parseFloat(validated.contributionRatio) / 100 : undefined,
      estimatedValue: validated.estimatedValue ? parseFloat(validated.estimatedValue) : undefined,
      actualValue: validated.actualValue ? parseFloat(validated.actualValue) : undefined,
      winContributionScore: validated.winContributionScore ? parseFloat(validated.winContributionScore) : undefined,
      feedbackScore: validated.feedbackScore ? parseFloat(validated.feedbackScore) : undefined,
      feedbackContent: validated.feedbackContent,
      userId,
    });
    
    return NextResponse.json({
      success: true,
      data: updated,
      message: '贡献确认更新成功',
    });
    
  } catch (error) {
    console.error('更新贡献确认失败:', error);
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: '参数验证失败', details: error.issues },
        { status: 400 }
      );
    }
    
    return NextResponse.json(
      { error: error instanceof Error ? error.message : '更新贡献确认失败' },
      { status: 500 }
    );
  }
}
