import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { tokenBlacklist } from '@/db/schema';
import { eq } from 'drizzle-orm';

/**
 * POST /api/auth/check-blacklist
 * 检查 Token 是否在黑名单中
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { tokenHash } = body;

    if (!tokenHash) {
      return NextResponse.json({ blacklisted: false });
    }

    // 检查 Token 是否在黑名单中
    const [result] = await db
      .select()
      .from(tokenBlacklist)
      .where(eq(tokenBlacklist.tokenHash, tokenHash))
      .limit(1);

    return NextResponse.json({
      blacklisted: !!result,
    });
  } catch (error) {
    console.error('Error checking blacklist:', error);
    // 出错时不阻止请求
    return NextResponse.json({ blacklisted: false });
  }
}
