import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { tokenBlacklist } from '@/db/schema';
import { successResponse, errorResponse } from '@/lib/api-response';
import { eq, lt, sql } from 'drizzle-orm';
import crypto from 'crypto';

/**
 * 从请求中提取 Token
 */
function extractToken(request: NextRequest): string | null {
  // 1. 从 Cookie 中获取
  const cookieToken = request.cookies.get('token')?.value;
  if (cookieToken) {
    return cookieToken;
  }

  // 2. 从 Authorization header 中获取
  const authHeader = request.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }

  return null;
}

/**
 * 计算 Token 的 SHA256 哈希
 */
function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

/**
 * POST /api/auth/logout
 * 用户登出
 */
export async function POST(request: NextRequest) {
  try {
    const token = extractToken(request);

    if (token) {
      // 计算 Token 哈希
      const tokenHash = hashToken(token);

      // 解析 Token 获取过期时间和用户 ID
      // JWT 格式: header.payload.signature
      const parts = token.split('.');
      if (parts.length === 3) {
        try {
          const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
          const expiresAt = new Date(payload.exp * 1000);
          const userId = payload.userId;

          // 将 Token 加入黑名单
          await db.insert(tokenBlacklist).values({
            tokenHash,
            userId: userId || null,
            expiresAt,
          }).onConflictDoNothing(); // 如果已存在则忽略
        } catch (e) {
          console.error('Failed to parse token:', e);
        }
      }

      // 清理过期的黑名单记录（可选，定期清理）
      try {
        await db.delete(tokenBlacklist).where(lt(tokenBlacklist.expiresAt, new Date()));
      } catch (e) {
        console.error('Failed to cleanup expired tokens:', e);
      }
    }

    // 构建响应
    const response = successResponse({
      message: '登出成功',
    });

    // 清除Cookie
    response.cookies.set('token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 0,
      path: '/',
    });

    response.cookies.set('refresh_token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 0,
      path: '/',
    });

    // 清除其他可能的认证Cookie
    response.cookies.set('session', '', {
      httpOnly: true,
      maxAge: 0,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return errorResponse('INTERNAL_ERROR', '登出失败');
  }
}

/**
 * GET /api/auth/logout
 * GET方式登出（用于重定向场景）
 */
export async function GET(request: NextRequest) {
  const response = NextResponse.redirect(new URL('/login', request.url));

  // 清除Cookie
  response.cookies.set('token', '', {
    httpOnly: true,
    maxAge: 0,
    path: '/',
  });

  response.cookies.set('refresh_token', '', {
    httpOnly: true,
    maxAge: 0,
    path: '/',
  });

  return response;
}
