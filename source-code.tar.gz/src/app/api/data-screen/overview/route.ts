import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, users, schemes, customers } from '@/db/schema';
import { count, sum, sql, desc, isNull, isNotNull } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';

// 内存缓存（已禁用以确保数据一致性）
let cachedOverview: {
  data: any;
  timestamp: number;
} | null = null;

const CACHE_TTL = 30 * 1000; // 30秒缓存（缩短缓存时间确保数据新鲜）

export const GET = withAuth(async (request: NextRequest) => {
  try {
    // BUG-DATA001: 禁用缓存以确保数据一致性，每次都查询最新数据
    // 检查缓存
    const now = Date.now();
    const forceRefresh = request.nextUrl.searchParams.get('refresh') === 'true';
    
    if (!forceRefresh && cachedOverview && (now - cachedOverview.timestamp) < CACHE_TTL) {
      return successResponse(cachedOverview.data);
    }

    // 并行获取所有统计数据 - 确保所有查询都过滤deletedAt
    const [
      customersCount,
      projectsCount,
      schemesCount,
      staffCount,
      totalRevenue,
      projectsByRegion,
      completedProjectsCount,
      customersByRegion,
    ] = await Promise.all([
      // 客户总数（bus_customer表，过滤软删除）
      db.select({ count: count() }).from(customers).where(isNull(customers.deletedAt)),
      
      // 项目总数（排除已删除）
      db.select({ count: count() }).from(projects).where(isNull(projects.deletedAt)),
      
      // 解决方案总数（排除已删除）
      db.select({ count: count() }).from(schemes).where(isNull(schemes.deletedAt)),
      
      // 员工总数（sys_user表，活跃状态，过滤软删除）
      db.select({ count: count() }).from(users).where(sql`${users.status} = 'active' AND ${users.deletedAt} IS NULL`),
      
      // 总收入（已中标项目的实际金额）
      db.select({ 
        total: sql<string>`COALESCE(SUM(CAST(${projects.actualAmount} AS DECIMAL)), 0)` 
      }).from(projects).where(sql`${projects.bidResult} = 'won' AND ${projects.deletedAt} IS NULL`),
      
      // 按区域统计项目
      db.select({
        region: projects.region,
        count: count(),
        amount: sql<string>`COALESCE(SUM(CAST(${projects.estimatedAmount} AS DECIMAL)), 0)`,
      }).from(projects)
        .where(sql`${projects.region} IS NOT NULL AND ${projects.region} != '' AND ${projects.deletedAt} IS NULL`)
        .groupBy(projects.region),
      
      // 已中标项目数
      db.select({ count: count() }).from(projects)
        .where(sql`${projects.bidResult} = 'won' AND ${projects.deletedAt} IS NULL`),
      
      // 按区域统计客户
      db.select({
        region: customers.region,
        count: count(),
      }).from(customers)
        .where(sql`${customers.region} IS NOT NULL AND ${customers.region} != '' AND ${customers.deletedAt} IS NULL`)
        .groupBy(customers.region),
    ]);

    // 构建区域数据
    const regionStats = projectsByRegion.map(item => ({
      name: item.region,
      value: Number(item.count),
      amount: Number(item.amount || 0),
    }));

    // 构建客户区域数据
    const customerRegionStats = customersByRegion.map(item => ({
      name: item.region,
      value: Number(item.count),
    }));

    // 生成月度趋势数据（最近6个月）- 修正：使用actualAmount
    const monthlyData = await db
      .select({
        month: sql<string>`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`,
        customers: sql<number>`COUNT(DISTINCT ${projects.customerId})`,
        projects: sql<number>`COUNT(*)`,
        actualRevenue: sql<number>`COALESCE(SUM(CAST(${projects.actualAmount} AS DECIMAL)), 0)`,
        estimatedRevenue: sql<number>`COALESCE(SUM(CAST(${projects.estimatedAmount} AS DECIMAL)), 0)`,
      })
      .from(projects)
      .where(sql`${projects.createdAt} >= NOW() - INTERVAL '6 months' AND ${projects.deletedAt} IS NULL`)
      .groupBy(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`)
      .orderBy(desc(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`))
      .limit(6);

    // 商机阶段统计
    const stageStats = await db
      .select({
        stage: projects.projectStage,
        count: count(),
      })
      .from(projects)
      .where(sql`${projects.projectStage} IS NOT NULL AND ${projects.deletedAt} IS NULL`)
      .groupBy(projects.projectStage);

    // 项目状态统计
    const statusStats = await db
      .select({
        status: projects.status,
        count: count(),
      })
      .from(projects)
      .where(isNull(projects.deletedAt))
      .groupBy(projects.status);

    const responseData = {
      success: true,
      data: {
        // 扁平化结构，方便前端直接访问
        totalCustomers: customersCount[0].count,
        totalProjects: projectsCount[0].count,
        totalSchemes: schemesCount[0].count,
        totalStaff: staffCount[0].count,
        totalRevenue: parseFloat(totalRevenue[0].total || '0'),
        wonProjects: completedProjectsCount[0].count,
        // 详细统计
        overview: {
          totalCustomers: customersCount[0].count,
          totalProjects: projectsCount[0].count,
          totalSchemes: schemesCount[0].count,
          totalStaff: staffCount[0].count,
          totalRevenue: parseFloat(totalRevenue[0].total || '0'),
          wonProjects: completedProjectsCount[0].count,
        },
        mapData: regionStats,
        regionStats,
        customerRegionStats,
        stageStats: stageStats.map(s => ({
          stage: s.stage,
          count: Number(s.count),
        })),
        statusStats: statusStats.map(s => ({
          status: s.status,
          count: Number(s.count),
        })),
        monthlyData: monthlyData.reverse().map(item => ({
          month: item.month,
          customers: Number(item.customers),
          projects: Number(item.projects),
          revenue: Number(item.actualRevenue || item.estimatedRevenue),
          actualRevenue: Number(item.actualRevenue),
          estimatedRevenue: Number(item.estimatedRevenue),
        })),
        topRegions: [...regionStats].sort((a, b) => b.value - a.value).slice(0, 5),
      },
    };

    // 更新缓存
    cachedOverview = {
      data: responseData,
      timestamp: now,
    };

    return successResponse(responseData);
  } catch (error) {
    console.error('Data screen overview API error:', error);
    return errorResponse('INTERNAL_ERROR', '获取数据大屏概览数据失败');
  }
});
