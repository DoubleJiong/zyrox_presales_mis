import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { schedules } from '@/db/schema';
import { eq, and } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';

// 获取单个日程详情
export const GET = withAuth(async (
  request: NextRequest,
  { userId }: { userId: number }
) => {
  try {
    const id = request.nextUrl.pathname.split('/').slice(-2)[0];

    const [schedule] = await db
      .select()
      .from(schedules)
      .where(and(
        eq(schedules.id, parseInt(id)),
        eq(schedules.userId, userId)
      ));

    if (!schedule) {
      return NextResponse.json({
        success: false,
        error: '日程不存在或无权访问',
      }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: schedule,
    });
  } catch (error) {
    console.error('Get schedule API error:', error);
    return NextResponse.json({
      success: false,
      error: '获取日程详情失败',
    }, { status: 500 });
  }
});

// 更新日程
export const PUT = withAuth(async (
  request: NextRequest,
  { userId }: { userId: number }
) => {
  try {
    const id = request.nextUrl.pathname.split('/').slice(-2)[0];
    const body = await request.json();

    // 先验证日程是否属于当前用户
    const [existingSchedule] = await db
      .select()
      .from(schedules)
      .where(and(
        eq(schedules.id, parseInt(id)),
        eq(schedules.userId, userId)
      ));

    if (!existingSchedule) {
      return NextResponse.json({
        success: false,
        error: '日程不存在或无权修改',
      }, { status: 404 });
    }

    const [updatedSchedule] = await db
      .update(schedules)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(schedules.id, parseInt(id)))
      .returning();

    return NextResponse.json({
      success: true,
      data: updatedSchedule,
      message: '日程更新成功',
    });
  } catch (error) {
    console.error('Update schedule API error:', error);
    return NextResponse.json({
      success: false,
      error: '更新日程失败',
    }, { status: 500 });
  }
});

// 删除日程
export const DELETE = withAuth(async (
  request: NextRequest,
  { userId }: { userId: number }
) => {
  try {
    const id = request.nextUrl.pathname.split('/').slice(-2)[0];

    // 先验证日程是否属于当前用户
    const [existingSchedule] = await db
      .select()
      .from(schedules)
      .where(and(
        eq(schedules.id, parseInt(id)),
        eq(schedules.userId, userId)
      ));

    if (!existingSchedule) {
      return NextResponse.json({
        success: false,
        error: '日程不存在或无权删除',
      }, { status: 404 });
    }

    await db
      .delete(schedules)
      .where(eq(schedules.id, parseInt(id)));

    return NextResponse.json({
      success: true,
      message: '日程删除成功',
    });
  } catch (error) {
    console.error('Delete schedule API error:', error);
    return NextResponse.json({
      success: false,
      error: '删除日程失败',
    }, { status: 500 });
  }
});
