import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { schedules } from '@/db/schema';
import { eq, and, gte, lte, desc } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';

// 获取日程列表
export const GET = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const status = searchParams.get('status');

    const conditions = [eq(schedules.userId, userId)];

    if (startDate) {
      conditions.push(gte(schedules.startDate, startDate));
    }
    if (endDate) {
      conditions.push(lte(schedules.endDate || schedules.startDate, endDate));
    }
    if (status) {
      conditions.push(eq(schedules.scheduleStatus, status));
    }

    const scheduleList = await db
      .select()
      .from(schedules)
      .where(and(...conditions))
      .orderBy(schedules.startDate, schedules.startTime)
      .limit(100);

    return NextResponse.json({
      success: true,
      data: scheduleList.map(schedule => ({
        id: schedule.id,
        title: schedule.title,
        type: schedule.type || 'other',
        startDate: schedule.startDate,
        startTime: schedule.startTime,
        endDate: schedule.endDate,
        endTime: schedule.endTime,
        allDay: schedule.allDay,
        location: schedule.location,
        participants: schedule.participants,
        relatedType: schedule.relatedType,
        relatedId: schedule.relatedId,
        description: schedule.description,
        scheduleStatus: schedule.scheduleStatus,
        createdAt: schedule.createdAt,
      })),
    });
  } catch (error) {
    console.error('Get schedules API error:', error);
    return NextResponse.json({
      success: false,
      error: '获取日程列表失败',
      data: [],
    });
  }
});

// 创建日程
export const POST = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const body = await request.json();
    const {
      title,
      type = 'other',
      startDate,
      startTime,
      endDate,
      endTime,
      allDay = false,
      location,
      participants,
      relatedType,
      relatedId,
      reminder,
      repeat,
      description,
    } = body;

    if (!title || !startDate) {
      return NextResponse.json({
        success: false,
        error: '请输入日程标题和开始日期',
      }, { status: 400 });
    }

    const [newSchedule] = await db
      .insert(schedules)
      .values({
        title,
        type,
        startDate,
        startTime,
        endDate: endDate || startDate,
        endTime,
        allDay,
        location,
        participants,
        relatedType,
        relatedId,
        reminder,
        repeat,
        description,
        userId,
        scheduleStatus: 'scheduled',
      })
      .returning();

    return NextResponse.json({
      success: true,
      data: newSchedule,
      message: '日程创建成功',
    });
  } catch (error) {
    console.error('Create schedule API error:', error);
    return NextResponse.json({
      success: false,
      error: '创建日程失败',
    }, { status: 500 });
  }
});
