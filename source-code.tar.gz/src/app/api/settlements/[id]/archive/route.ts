import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { projects, projectSettlements } from '@/db/schema';
import { eq } from 'drizzle-orm';

// POST - 归档项目
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // 更新项目状态
    const [updatedProject] = await db
      .update(projects)
      .set({
        projectStage: 'archived',
        status: 'completed',
        progress: 100,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, parseInt(id)))
      .returning();

    // 更新结算归档状态
    await db
      .update(projectSettlements)
      .set({
        archiveStatus: 'archived',
        archivedAt: new Date(),
        archivedBy: body.archivedBy || null,
      })
      .where(eq(projectSettlements.projectId, parseInt(id)));

    return NextResponse.json({
      success: true,
      data: updatedProject,
      message: '项目已归档',
    });
  } catch (error) {
    console.error('Failed to archive project:', error);
    return NextResponse.json(
      { success: false, error: '归档失败' },
      { status: 500 }
    );
  }
}
