/**
 * 数据库索引分析 API
 * GET /api/admin/index-analysis
 */

import { NextRequest } from 'next/server';
import { 
  getIndexUsageStats, 
  getUnusedIndexes, 
  getTableScanStats,
  generateIndexRecommendations,
  getIndexSizeStats,
  getDatabaseStatsSummary,
  analyzeTables
} from '@/lib/index-analyzer';
import { successResponse, errorResponse } from '@/lib/api-response';
import { extractToken, verifyToken } from '@/lib/jwt';
import { getUserPermissions } from '@/lib/rbac';

/**
 * 验证管理员权限
 */
async function verifyAdminAccess(request: NextRequest): Promise<{ userId: number } | null> {
  const token = extractToken(request);
  if (!token) {
    return null;
  }

  const payload = verifyToken(token);
  if (!payload) {
    return null;
  }

  const user = await getUserPermissions(payload.userId);
  if (!user || !user.isSuperAdmin) {
    return null;
  }

  return { userId: payload.userId };
}

export async function GET(request: NextRequest) {
  try {
    // 验证管理员权限
    const auth = await verifyAdminAccess(request);
    if (!auth) {
      return errorResponse('UNAUTHORIZED', '未授权访问', { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action') || 'summary';

    switch (action) {
      case 'summary': {
        const summary = await getDatabaseStatsSummary();
        return successResponse(summary);
      }

      case 'usage': {
        const stats = await getIndexUsageStats();
        return successResponse(stats);
      }

      case 'unused': {
        const unused = await getUnusedIndexes();
        return successResponse(unused);
      }

      case 'scans': {
        const scans = await getTableScanStats();
        return successResponse(scans);
      }

      case 'recommendations': {
        const recommendations = await generateIndexRecommendations();
        return successResponse(recommendations);
      }

      case 'sizes': {
        const sizes = await getIndexSizeStats();
        return successResponse(sizes);
      }

      default:
        return errorResponse('INVALID_ACTION', '无效的操作', { status: 400 });
    }
  } catch (error) {
    console.error('数据库索引分析失败:', error);
    return errorResponse('INTERNAL_ERROR', '数据库索引分析失败', { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    // 验证管理员权限
    const auth = await verifyAdminAccess(request);
    if (!auth) {
      return errorResponse('UNAUTHORIZED', '未授权访问', { status: 401 });
    }

    const body = await request.json();
    const { action, tables } = body;

    switch (action) {
      case 'analyze': {
        await analyzeTables(tables);
        return successResponse({ message: '更新统计信息成功' });
      }

      default:
        return errorResponse('INVALID_ACTION', '无效的操作', { status: 400 });
    }
  } catch (error) {
    console.error('执行数据库操作失败:', error);
    return errorResponse('INTERNAL_ERROR', '执行数据库操作失败', { status: 500 });
  }
}
