import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { operationLogs } from '@/db/schema';
import { sql, eq, and, gte, lte, like, desc, isNull } from 'drizzle-orm';
import { successResponse, errorResponse, paginatedResponse, parsePagination } from '@/lib/api-response';

// =====================================================
// 操作日志API
// =====================================================

/**
 * GET /api/operation-logs
 * 获取操作日志列表
 */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const { page, pageSize, offset } = parsePagination(searchParams);

    // 过滤参数
    const userId = searchParams.get('userId');
    const module = searchParams.get('module');
    const action = searchParams.get('action');
    const status = searchParams.get('status');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const search = searchParams.get('search');

    // 构建查询条件
    const conditions = [isNull(operationLogs.deletedAt)];

    if (userId) {
      conditions.push(eq(operationLogs.userId, parseInt(userId, 10)));
    }
    if (module) {
      conditions.push(eq(operationLogs.module, module));
    }
    if (action) {
      conditions.push(eq(operationLogs.action, action));
    }
    if (status) {
      conditions.push(eq(operationLogs.status, status));
    }
    if (startDate) {
      conditions.push(gte(operationLogs.createdAt, new Date(startDate)));
    }
    if (endDate) {
      conditions.push(lte(operationLogs.createdAt, new Date(endDate)));
    }
    if (search) {
      conditions.push(like(operationLogs.resource, `%${search}%`));
    }

    // 查询日志列表
    const logs = await db
      .select()
      .from(operationLogs)
      .where(and(...conditions))
      .orderBy(desc(operationLogs.createdAt))
      .limit(pageSize)
      .offset(offset);

    // 查询总数
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(operationLogs)
      .where(and(...conditions));

    return paginatedResponse(logs, Number(count) || 0, { page, pageSize });
  } catch (error) {
    console.error('Get operation logs error:', error);
    return errorResponse('INTERNAL_ERROR', '获取操作日志失败', { status: 500 });
  }
}

/**
 * DELETE /api/operation-logs
 * 清理过期日志
 */
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const daysToKeep = parseInt(searchParams.get('daysToKeep') || '30', 10);
    
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    // 软删除过期日志
    const result = await db
      .update(operationLogs)
      .set({ deletedAt: new Date() })
      .where(and(
        isNull(operationLogs.deletedAt),
        lte(operationLogs.createdAt, cutoffDate)
      ))
      .returning({ id: operationLogs.id });

    return successResponse({
      message: `已清理 ${result.length} 条过期日志`,
      count: result.length,
    });
  } catch (error) {
    console.error('Clean operation logs error:', error);
    return errorResponse('INTERNAL_ERROR', '清理操作日志失败', { status: 500 });
  }
}
