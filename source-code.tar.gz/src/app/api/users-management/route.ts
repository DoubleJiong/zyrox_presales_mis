import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { users, roles, userRoles } from '@/db/schema';
import { desc, eq, inArray, and } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';

// GET - 获取用户列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const includeRoles = searchParams.get('includeRoles') === 'true';

    // 查询用户列表
    const userList = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        name: users.realName,
        avatar: users.avatar,
        status: users.status,
        department: users.department,
        phone: users.phone,
        baseLocation: users.baseLocation,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));

    // 如果需要角色信息，查询用户角色关联
    let userRolesMap: Record<number, Array<{ id: number; name: string; code: string }>> = {};
    if (includeRoles && userList.length > 0) {
      const userIds = userList.map(u => u.id);
      
      // 查询用户角色关联
      const userRoleList = await db
        .select({
          userId: userRoles.userId,
          roleId: userRoles.roleId,
          roleName: roles.roleName,
          roleCode: roles.roleCode,
        })
        .from(userRoles)
        .leftJoin(roles, eq(userRoles.roleId, roles.id))
        .where(inArray(userRoles.userId, userIds));

      // 按用户ID分组
      userRolesMap = userRoleList.reduce((acc, ur) => {
        if (!acc[ur.userId]) {
          acc[ur.userId] = [];
        }
        if (ur.roleId && ur.roleName && ur.roleCode) {
          acc[ur.userId].push({
            id: ur.roleId,
            name: ur.roleName,
            code: ur.roleCode,
          });
        }
        return acc;
      }, {} as Record<number, Array<{ id: number; name: string; code: string }>>);
    }

    // 组装返回数据
    const result = userList.map(user => {
      const userRoleList = userRolesMap[user.id] || [];
      return {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        status: user.status,
        department: user.department,
        phone: user.phone,
        baseLocation: user.baseLocation,
        roles: userRoleList.map(r => r.id),
        roleIds: userRoleList.map(r => r.id),
        roleNames: userRoleList.map(r => r.name),
        roleCodes: userRoleList.map(r => r.code),
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      };
    });

    return successResponse(result);
  } catch (error) {
    console.error('Failed to fetch users:', error);
    return errorResponse('INTERNAL_ERROR', '获取用户列表失败');
  }
}

// POST - 创建用户
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, email, name, password, roleIds, status, department, phone, baseLocation } = body;

    // 验证必填字段
    if (!username || !email || !name || !password) {
      return errorResponse('BAD_REQUEST', '用户名、邮箱、姓名和密码为必填项');
    }

    // 密码加密
    const bcrypt = require('bcrypt');
    const passwordHash = await bcrypt.hash(password, 10);

    // 创建用户
    const [newUser] = await db
      .insert(users)
      .values({
        username,
        email,
        realName: name,
        password: passwordHash,
        department: department || null,
        phone: phone || null,
        baseLocation: baseLocation || null,
        status: status || 'active',
      })
      .returning();

    // 如果有角色，插入用户角色关联
    if (roleIds && Array.isArray(roleIds) && roleIds.length > 0) {
      await db.insert(userRoles).values(
        roleIds.map((roleId: number) => ({
          userId: newUser.id,
          roleId: roleId,
        }))
      );
    }

    return successResponse({
      id: newUser.id,
      username: newUser.username,
      email: newUser.email,
      name: newUser.realName,
      status: newUser.status,
      roleIds: roleIds || [],
    }, { status: 201 });
  } catch (error) {
    console.error('Failed to create user:', error);
    return errorResponse('INTERNAL_ERROR', '创建用户失败');
  }
}

// PUT - 更新用户
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, email, name, roleIds, status, department, phone, baseLocation } = body;

    if (!id) {
      return errorResponse('BAD_REQUEST', '用户ID为必填项');
    }

    // 构建更新数据
    const updateData: Record<string, any> = {
      updatedAt: new Date(),
    };
    
    if (email !== undefined) updateData.email = email;
    if (name !== undefined) updateData.realName = name;
    if (status !== undefined) updateData.status = status;
    if (department !== undefined) updateData.department = department;
    if (phone !== undefined) updateData.phone = phone;
    if (baseLocation !== undefined) updateData.baseLocation = baseLocation;

    // 更新用户基本信息
    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();

    if (!updatedUser) {
      return errorResponse('NOT_FOUND', '用户不存在');
    }

    // 更新用户角色关联
    if (roleIds !== undefined && Array.isArray(roleIds)) {
      // 先删除现有关联
      await db.delete(userRoles).where(eq(userRoles.userId, id));
      
      // 插入新关联
      if (roleIds.length > 0) {
        await db.insert(userRoles).values(
          roleIds.map((roleId: number) => ({
            userId: id,
            roleId: roleId,
          }))
        );
      }
    }

    return successResponse({
      id: updatedUser.id,
      username: updatedUser.username,
      email: updatedUser.email,
      name: updatedUser.realName,
      status: updatedUser.status,
      roleIds: roleIds,
    });
  } catch (error) {
    console.error('Failed to update user:', error);
    return errorResponse('INTERNAL_ERROR', '更新用户失败');
  }
}

// DELETE - 删除用户
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = parseInt(searchParams.get('id') || '');

    if (!id) {
      return errorResponse('BAD_REQUEST', '用户ID为必填项');
    }

    // 删除用户角色关联
    await db.delete(userRoles).where(eq(userRoles.userId, id));
    
    // 删除用户
    await db.delete(users).where(eq(users.id, id));

    return successResponse({ success: true });
  } catch (error) {
    console.error('Failed to delete user:', error);
    return errorResponse('INTERNAL_ERROR', '删除用户失败');
  }
}
