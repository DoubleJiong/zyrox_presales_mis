import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { todos, schedules, opportunities, users, projects, projectMembers, follows, tasks, alertNotifications } from '@/db/schema';
import { count, and, eq, gte, lte, sql, desc, sum, or, isNull, inArray } from 'drizzle-orm';
import { withAuth } from '@/lib/auth-middleware';

// 获取工作台概览数据
export const GET = withAuth(async (request: NextRequest, { userId }) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // 1. 待办事项统计（待办 + 今日日程）
    // 1.1 待办事项
    const [pendingTodosCount] = await db
      .select({ count: count() })
      .from(todos)
      .where(and(
        eq(todos.assigneeId, userId),
        eq(todos.todoStatus, 'pending')
      ));

    // 1.2 今日日程（未完成的）
    const [todaySchedulesCount] = await db
      .select({ count: count() })
      .from(schedules)
      .where(and(
        eq(schedules.userId, userId),
        eq(schedules.startDate, today),
        sql`${schedules.scheduleStatus} NOT IN ('completed', 'cancelled')`
      ));

    const totalPendingTodos = (pendingTodosCount?.count || 0) + (todaySchedulesCount?.count || 0);

    // 2. 我的任务统计（预警任务 + 指派任务）
    // 2.1 预警任务（未处理的预警通知）
    const [alertTasksCount] = await db
      .select({ count: count() })
      .from(alertNotifications)
      .where(and(
        eq(alertNotifications.recipientId, userId),
        eq(alertNotifications.status, 'pending'),
        isNull(alertNotifications.deletedAt)
      ));

    // 2.2 指派任务（待处理和进行中的项目任务）
    const [assignedTasksCount] = await db
      .select({ count: count() })
      .from(tasks)
      .where(and(
        eq(tasks.assigneeId, userId),
        or(
          eq(tasks.status, 'pending'),
          eq(tasks.status, 'in_progress')
        ),
        isNull(tasks.deletedAt)
      ));

    const myTasksCount = (alertTasksCount?.count || 0) + (assignedTasksCount?.count || 0);

    // 3. 我的项目统计（作为负责人或团队成员）
    const myProjectsResult = await db
      .select({ id: projects.id })
      .from(projects)
      .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
      .where(and(
        or(
          eq(projects.managerId, userId),
          eq(projectMembers.userId, userId)
        ),
        isNull(projects.deletedAt)
      ))
      .groupBy(projects.id);

    const myProjectsCount = myProjectsResult.length;

    // 4. 我的预算统计（关联项目的预算总额）
    const projectIds = myProjectsResult.map(p => p.id);
    let myBudgetTotal = 0;
    if (projectIds.length > 0) {
      const budgetResult = await db
        .select({ total: sum(projects.estimatedAmount) })
        .from(projects)
        .where(and(
          inArray(projects.id, projectIds),
          isNull(projects.deletedAt)
        ));
      myBudgetTotal = parseFloat(budgetResult[0]?.total || '0');
    }

    // 5. 我的中标统计（关联的中标项目中标金额）
    let myWinAmountTotal = 0;
    if (projectIds.length > 0) {
      const winAmountResult = await db
        .select({ total: sum(projects.actualAmount) })
        .from(projects)
        .where(and(
          inArray(projects.id, projectIds),
          eq(projects.bidResult, 'won'),
          isNull(projects.deletedAt)
        ));
      myWinAmountTotal = parseFloat(winAmountResult[0]?.total || '0');
    }

    // 获取今日待办
    const todayTodos = await db
      .select()
      .from(todos)
      .where(and(
        eq(todos.assigneeId, userId),
        eq(todos.dueDate, today),
        eq(todos.todoStatus, 'pending')
      ))
      .orderBy(desc(todos.priority))
      .limit(10);

    // 获取我的重点项目
    const starredProjects = await db
      .select({
        followId: follows.id,
        project: {
          id: projects.id,
          projectCode: projects.projectCode,
          projectName: projects.projectName,
          customerName: projects.customerName,
          status: projects.status,
          progress: projects.progress,
        },
      })
      .from(follows)
      .innerJoin(
        projects,
        and(
          eq(follows.targetId, projects.id),
          eq(follows.targetType, 'project')
        )
      )
      .where(and(
        eq(follows.userId, userId),
        eq(follows.followType, 'starred'),
        isNull(follows.deletedAt),
        isNull(projects.deletedAt)
      ))
      .orderBy(desc(follows.createdAt))
      .limit(5);

    // 获取本周日程
    const now = new Date();
    const dayOfWeek = now.getDay();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
    const weekStartStr = weekStart.toISOString().split('T')[0];
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    const weekEndStr = weekEnd.toISOString().split('T')[0];

    const weekSchedules = await db
      .select()
      .from(schedules)
      .where(and(
        eq(schedules.userId, userId),
        gte(schedules.startDate, weekStartStr),
        lte(schedules.startDate, weekEndStr)
      ))
      .orderBy(schedules.startDate)
      .limit(10);

    // 获取最近12周的项目活动数据（用于折线图）
    const weeklyProjectActivities = await getWeeklyProjectActivities(userId);

    return NextResponse.json({
      success: true,
      data: {
        stats: {
          pendingTodos: totalPendingTodos,
          myTasks: myTasksCount,
          myProjects: myProjectsCount,
          myBudget: myBudgetTotal,
          myWinAmount: myWinAmountTotal,
        },
        todayTodos: todayTodos.map(todo => ({
          id: todo.id,
          title: todo.title,
          type: todo.type || 'other',
          priority: todo.priority || 'medium',
          dueDate: todo.dueDate,
          dueTime: todo.dueTime,
          todoStatus: todo.todoStatus,
          relatedName: todo.relatedName,
        })),
        weekSchedules: weekSchedules.map(schedule => ({
          id: schedule.id,
          title: schedule.title,
          type: schedule.type || 'other',
          startDate: schedule.startDate,
          startTime: schedule.startTime,
          location: schedule.location,
        })),
        starredProjects: starredProjects.map(p => ({
          id: p.project.id,
          projectCode: p.project.projectCode,
          projectName: p.project.projectName,
          customerName: p.project.customerName,
          status: p.project.status,
          progress: p.project.progress,
        })),
        weeklyProjectActivities,
      },
    });
  } catch (error) {
    console.error('Workbench summary API error:', error);
    
    // 返回空数据而不是模拟数据
    return NextResponse.json({
      success: true,
      data: {
        stats: {
          pendingTodos: 0,
          myTasks: 0,
          myProjects: 0,
          myBudget: 0,
          myWinAmount: 0,
        },
        todayTodos: [],
        weekSchedules: [],
        starredProjects: [],
        weeklyProjectActivities: [],
      },
    });
  }
});

// 获取最近12周的项目活动数据
async function getWeeklyProjectActivities(userId: number) {
  const weeks: { week: string; count: number }[] = [];
  const now = new Date();
  
  for (let i = 11; i >= 0; i--) {
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - (i * 7) - now.getDay() + 1);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    
    const weekStartStr = weekStart.toISOString().split('T')[0];
    const weekEndStr = weekEnd.toISOString().split('T')[0];
    const weekLabel = `${weekStart.getMonth() + 1}/${weekStart.getDate()}`;
    
    try {
      // 统计本周内被该用户修改或关联的项目数
      const result = await db
        .select({ id: projects.id })
        .from(projects)
        .leftJoin(projectMembers, eq(projects.id, projectMembers.projectId))
        .where(and(
          or(
            eq(projects.managerId, userId),
            eq(projectMembers.userId, userId)
          ),
          sql`${projects.updatedAt} >= ${weekStartStr}`,
          sql`${projects.updatedAt} <= ${weekEndStr}`,
          sql`${projects.deletedAt} IS NULL`
        ))
        .groupBy(projects.id);
      
      weeks.push({ week: weekLabel, count: result.length });
    } catch {
      weeks.push({ week: weekLabel, count: 0 });
    }
  }
  
  return weeks;
}

// 生成模拟的周数据
function generateMockWeeklyData() {
  const weeks: { week: string; count: number }[] = [];
  const now = new Date();
  
  for (let i = 11; i >= 0; i--) {
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - (i * 7) - now.getDay() + 1);
    const weekLabel = `${weekStart.getMonth() + 1}/${weekStart.getDate()}`;
    weeks.push({ week: weekLabel, count: Math.floor(Math.random() * 8) + 1 });
  }
  
  return weeks;
}
