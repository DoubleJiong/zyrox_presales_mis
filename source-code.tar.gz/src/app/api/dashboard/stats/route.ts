import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { customers, projects, schemes, users } from '@/db/schema';
import { count, and, gte, lte, sql, desc, isNull, eq, inArray } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';
import { getPermissionContext } from '@/lib/permissions/data-scope';
import { hasFullAccess } from '@/lib/permissions/middleware';
import { DataScope } from '@/lib/permissions/types';
import type { ResourceType } from '@/lib/permissions/types';
import { getAccessibleProjectIds } from '@/lib/permissions/project';

/**
 * GET /api/dashboard/stats
 * 获取仪表盘统计数据（已修正数据源和数据权限）
 */
export const GET = withAuth(async (
  request: NextRequest,
  context: { userId: number }
) => {
  try {
    const userId = context.userId;
    
    // 获取权限上下文
    const permissionContext = await getPermissionContext(userId, 'customer' as ResourceType);
    const isFullAccess = hasFullAccess(permissionContext);
    
    // 构建客户查询条件（考虑数据权限）
    let customerWhereCondition = isNull(customers.deletedAt);
    if (!isFullAccess) {
      if (permissionContext.dataPermission?.scope === DataScope.SELF) {
        customerWhereCondition = and(isNull(customers.deletedAt), eq(customers.createdBy, userId));
      } else if (permissionContext.dataPermission?.scope === DataScope.ROLE) {
        customerWhereCondition = and(isNull(customers.deletedAt), eq(customers.createdBy, userId));
      }
    }
    
    // 构建项目查询条件（考虑数据权限）
    let projectWhereCondition = isNull(projects.deletedAt);
    if (!isFullAccess) {
      // 获取用户可访问的项目ID列表
      const accessibleProjectIds = await getAccessibleProjectIds(userId);
      if (accessibleProjectIds.length === 0) {
        projectWhereCondition = and(isNull(projects.deletedAt), sql`1 = 0`); // 无权限则返回空
      } else {
        projectWhereCondition = and(
          isNull(projects.deletedAt),
          inArray(projects.id, accessibleProjectIds)
        );
      }
    }

    // 基础统计数据 - 使用正确的表并应用数据权限
    const [customersCount, projectsCount, schemesCount, staffCount] = await Promise.all([
      db.select({ count: count() }).from(customers).where(customerWhereCondition),
      db.select({ count: count() }).from(projects).where(projectWhereCondition),
      db.select({ count: count() }).from(schemes).where(isNull(schemes.deletedAt)),
      db.select({ count: count() }).from(users).where(sql`${users.status} = 'active'`),
    ]);

    // 计算转化率（从线索转化）- 应用数据权限
    const activeCustomers = await db
      .select({ count: count() })
      .from(customers)
      .where(
        and(
          customerWhereCondition,
          sql`${customers.currentProjectCount} > 0`
        )
      );

    const engagementRate = customersCount[0].count > 0
      ? ((activeCustomers[0].count / customersCount[0].count) * 100).toFixed(1)
      : '0';

    // 计算总收入 - 应用数据权限
    const totalRevenue = await db
      .select({
        total: sql<number>`COALESCE(SUM(CAST(${projects.actualAmount} AS DECIMAL)), 0)`,
      })
      .from(projects)
      .where(
        and(
          sql`${projects.status} = 'completed'`,
          projectWhereCondition
        )
      );

    // 计算预估总收入（用于对比）- 应用数据权限
    const estimatedRevenue = await db
      .select({
        total: sql<number>`COALESCE(SUM(CAST(${projects.estimatedAmount} AS DECIMAL)), 0)`,
      })
      .from(projects)
      .where(
        and(
          sql`${projects.status} = 'completed'`,
          projectWhereCondition
        )
      );

    // 计算平均项目周期 - 应用数据权限
    // BUG-018: 修复负数平均项目时长问题
    const avgDuration = await db
      .select({
        avg: sql<number>`COALESCE(AVG(${projects.endDate}::date - ${projects.startDate}::date), 0)`,
      })
      .from(projects)
      .where(
        and(
          sql`${projects.startDate} IS NOT NULL`,
          sql`${projects.endDate} IS NOT NULL`,
          sql`${projects.endDate} >= ${projects.startDate}`, // 只计算结束日期>=开始日期的项目
          projectWhereCondition
        )
      );

    // 客户满意度（从评估数据计算，暂时返回固定值）
    const avgSatisfaction = '88.5';
    
    // 计算平均项目周期，确保非负
    const rawAvgDuration = Math.round(avgDuration[0].avg || 30);
    const finalAvgDuration = rawAvgDuration >= 0 ? rawAvgDuration : 0;

    // 月度数据（从数据库获取最近6个月）- 应用数据权限
    const monthlyData = await db
      .select({
        month: sql<string>`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`,
        customers: sql<number>`COUNT(DISTINCT ${projects.customerId})`,
        projects: sql<number>`COUNT(*)`,
        actualRevenue: sql<number>`COALESCE(SUM(CAST(${projects.actualAmount} AS DECIMAL)), 0)`,
        estimatedRevenue: sql<number>`COALESCE(SUM(CAST(${projects.estimatedAmount} AS DECIMAL)), 0)`,
      })
      .from(projects)
      .where(
        and(
          sql`${projects.createdAt} >= NOW() - INTERVAL '6 months'`,
          projectWhereCondition
        )
      )
      .groupBy(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`)
      .orderBy(desc(sql`TO_CHAR(${projects.createdAt}, 'YYYY-MM')`))
      .limit(6);

    return successResponse({
      stats: {
        totalCustomers: customersCount[0].count,
        totalProjects: projectsCount[0].count,
        totalSchemes: schemesCount[0].count,
        totalStaff: staffCount[0].count,
        engagementRate: Number(engagementRate), // 客户参与率（有项目的客户占比）
        avgProjectDuration: finalAvgDuration,
        totalRevenue: totalRevenue[0].total || 0, // 实际总收入
        estimatedRevenue: estimatedRevenue[0].total || 0, // 预估总收入
        avgSatisfaction: Number(avgSatisfaction),
      },
      monthlyData: monthlyData.reverse().map(item => ({
        month: item.month,
        customers: Number(item.customers),
        projects: Number(item.projects),
        revenue: Number(item.actualRevenue), // 默认使用实际金额
        actualRevenue: Number(item.actualRevenue),
        estimatedRevenue: Number(item.estimatedRevenue),
      })),
    });
  } catch (error) {
    console.error('Failed to fetch dashboard stats:', error);
    return errorResponse('INTERNAL_ERROR', '获取仪表盘统计数据失败');
  }
});
