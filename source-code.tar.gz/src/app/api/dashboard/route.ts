import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { customers, projects, schemes, tasks, users } from '@/db/schema';
import { count, and, eq, or, desc, isNull, inArray, sql } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';
import { getPermissionContext } from '@/lib/permissions/data-scope';
import { hasFullAccess } from '@/lib/permissions/middleware';
import { DataScope } from '@/lib/permissions/types';
import type { ResourceType } from '@/lib/permissions/types';
import { getAccessibleProjectIds } from '@/lib/permissions/project';

/**
 * GET /api/dashboard
 * 获取仪表盘数据
 * 已修复：添加认证中间件保护和数据权限过滤
 */
export const GET = withAuth(async (request: NextRequest, { userId }) => {
  try {
    // 获取权限上下文
    const permissionContext = await getPermissionContext(userId, 'customer' as ResourceType);
    const isFullAccess = hasFullAccess(permissionContext);

    // 构建客户查询条件（考虑数据权限）
    let customerWhereCondition = isNull(customers.deletedAt);
    if (!isFullAccess) {
      if (permissionContext.dataPermission?.scope === DataScope.SELF) {
        customerWhereCondition = and(isNull(customers.deletedAt), eq(customers.createdBy, userId));
      } else if (permissionContext.dataPermission?.scope === DataScope.ROLE) {
        customerWhereCondition = and(isNull(customers.deletedAt), eq(customers.createdBy, userId));
      }
    }

    // 构建项目查询条件（考虑数据权限）
    let projectWhereCondition = isNull(projects.deletedAt);
    if (!isFullAccess) {
      // 获取用户可访问的项目ID列表
      const accessibleProjectIds = await getAccessibleProjectIds(userId);
      if (accessibleProjectIds.length === 0) {
        projectWhereCondition = and(isNull(projects.deletedAt), sql`1 = 0`); // 无权限则返回空
      } else {
        projectWhereCondition = and(
          isNull(projects.deletedAt),
          inArray(projects.id, accessibleProjectIds)
        );
      }
    }

    // 统计数据 - 添加 deletedAt 过滤和数据权限
    const [customerCount, projectCount, schemeCount, taskCount] = await Promise.all([
      // 修正：使用 customers 表而不是 leads 表
      db.select({ count: count() }).from(customers).where(customerWhereCondition),
      // 项目总数（排除已删除）
      db.select({ count: count() }).from(projects).where(projectWhereCondition),
      // 方案总数（排除已删除）
      db.select({ count: count() }).from(schemes).where(isNull(schemes.deletedAt)),
      // 待办任务（排除已删除）
      db.select({ count: count() }).from(tasks).where(
        and(
          or(
            eq(tasks.status, 'pending'),
            eq(tasks.status, 'in_progress')
          ),
          isNull(tasks.deletedAt)
        )
      ),
    ]);

    // 最近项目（排除已删除，应用数据权限）
    const recentProjects = await db
      .select({
        id: projects.id,
        projectCode: projects.projectCode,
        projectName: projects.projectName,
        status: projects.status,
        progress: projects.progress,
      })
      .from(projects)
      .where(projectWhereCondition)
      .orderBy(desc(projects.createdAt))
      .limit(5);

    // 最近通知（从 notifications 表获取，如果存在）
    // 暂时返回空数组，等通知功能完善后再实现
    const recentNotifications: any[] = [];

    return NextResponse.json({
      totalCustomers: customerCount[0].count,
      totalProjects: projectCount[0].count,
      totalSchemes: schemeCount[0].count,
      pendingTasks: taskCount[0].count,
      recentProjects,
      recentNotifications,
    });
  } catch (error) {
    console.error('Dashboard API error:', error);
    return errorResponse('INTERNAL_ERROR', '获取仪表盘数据失败');
  }
});
