import { NextResponse } from 'next/server';
import { db } from '@/db';
import { users, roles, userRoles } from '@/db/schema';
import { desc, eq, inArray, and, sql, or } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';
import { withAuth } from '@/lib/auth-middleware';
import { DataPermissionService, DataScope } from '@/lib/permissions/data-scope';
import { ADMIN_ROLE_CODES, DEFAULT_ROLE_PERMISSIONS } from '@/lib/permissions/types';

// 允许按角色代码搜索的角色列表（这些角色搜索时不受数据权限限制）
const SEARCHABLE_ROLE_CODES = [
  'admin',
  'presale_manager',
  'hq_presale_engineer',
  'regional_presale_engineer',
  'solution_engineer',
];

// GET - 获取用户列表
export const GET = withAuth(async (request, { userId }) => {
  try {
    const { searchParams } = new URL(request.url);
    const keyword = searchParams.get('keyword');
    const roleCodes = searchParams.get('roleCodes'); // 支持按角色代码筛选，逗号分隔
    
    // 解析角色代码参数
    const roleCodeList = roleCodes ? roleCodes.split(',').map(r => r.trim()) : [];
    const isValidRoleSearch = roleCodeList.length > 0 && roleCodeList.every(r => SEARCHABLE_ROLE_CODES.includes(r));
    
    // 获取当前用户的数据权限范围
    const context = await DataPermissionService.getPermissionContext(userId, 'staff');
    const scope = context.dataPermission?.scope || DataScope.NONE;

    let userList;

    // 构建搜索条件
    const searchCondition = keyword 
      ? sql`(${users.realName} ILIKE ${`%${keyword}%`} OR ${users.email} ILIKE ${`%${keyword}%`} OR ${users.username} ILIKE ${`%${keyword}%`})`
      : null;

    // 如果是按角色代码搜索且是有效的角色代码，则绕过数据权限限制
    if (isValidRoleSearch) {
      // 查询角色ID
      const roleRecords = await db
        .select({ id: roles.id, roleCode: roles.roleCode })
        .from(roles)
        .where(inArray(roles.roleCode, roleCodeList));
      
      const roleIds = roleRecords.map(r => r.id);
      
      // 通过 userRoles 表查询用户
      if (roleIds.length > 0) {
        const usersByRole = await db
          .selectDistinct({
            id: users.id,
            username: users.username,
            realName: users.realName,
            email: users.email,
            department: users.department,
            status: users.status,
            roleId: users.roleId,
          })
          .from(users)
          .innerJoin(userRoles, eq(users.id, userRoles.userId))
          .where(
            and(
              inArray(userRoles.roleId, roleIds),
              eq(users.status, 'active'),
              searchCondition
            )
          )
          .orderBy(desc(users.createdAt))
          .limit(50);
        
        return successResponse(usersByRole);
      }
    }

    if (scope === DataScope.ALL || ADMIN_ROLE_CODES.includes(context.roleCode || '')) {
      // 全部数据权限 - 可以看到所有用户
      userList = await db
        .select({
          id: users.id,
          username: users.username,
          realName: users.realName,
          email: users.email,
          department: users.department,
          status: users.status,
          roleId: users.roleId,
        })
        .from(users)
        .where(searchCondition ? and(eq(users.status, 'active'), searchCondition) : eq(users.status, 'active'))
        .orderBy(desc(users.createdAt))
        .limit(20);
    } else if (scope === DataScope.ROLE && context.roleId) {
      // 同角色数据权限 - 只能看到同角色的用户
      userList = await db
        .select({
          id: users.id,
          username: users.username,
          realName: users.realName,
          email: users.email,
          department: users.department,
          status: users.status,
          roleId: users.roleId,
        })
        .from(users)
        .where(searchCondition 
          ? and(eq(users.roleId, context.roleId), eq(users.status, 'active'), searchCondition)
          : and(eq(users.roleId, context.roleId), eq(users.status, 'active')))
        .orderBy(desc(users.createdAt))
        .limit(20);
    } else if (scope === DataScope.SELF) {
      // 仅自己的数据
      userList = await db
        .select({
          id: users.id,
          username: users.username,
          realName: users.realName,
          email: users.email,
          department: users.department,
          status: users.status,
          roleId: users.roleId,
        })
        .from(users)
        .where(eq(users.id, userId))
        .orderBy(desc(users.createdAt));
    } else {
      // 无权限
      return errorResponse('FORBIDDEN', '您没有权限查看用户列表');
    }

    return successResponse(userList);
  } catch (error) {
    console.error('Failed to fetch users:', error);
    return errorResponse('INTERNAL_ERROR', '获取用户列表失败');
  }
});
