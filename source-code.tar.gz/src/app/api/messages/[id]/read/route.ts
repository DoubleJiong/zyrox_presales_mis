import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { messages } from '@/db/schema';
import { eq, and, inArray, sql } from 'drizzle-orm';

// 标记消息为已读
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const [updatedMessage] = await db
      .update(messages)
      .set({
        isRead: true,
        readAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(messages.id, parseInt(id)))
      .returning();

    if (!updatedMessage) {
      return NextResponse.json(
        { success: false, error: '消息不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: '消息已标记为已读',
    });
  } catch (error) {
    console.error('Mark message as read API error:', error);
    return NextResponse.json(
      { success: false, error: '标记已读失败' },
      { status: 500 }
    );
  }
}
