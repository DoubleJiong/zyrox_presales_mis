import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { messages } from '@/db/schema';
import { eq, and } from 'drizzle-orm';

// 获取单个消息详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const [message] = await db
      .select()
      .from(messages)
      .where(eq(messages.id, parseInt(id)));

    if (!message) {
      return NextResponse.json(
        { success: false, error: '消息不存在' },
        { status: 404 }
      );
    }

    // 自动标记为已读
    if (!message.isRead) {
      await db
        .update(messages)
        .set({
          isRead: true,
          readAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(messages.id, parseInt(id)));
    }

    return NextResponse.json({
      success: true,
      data: {
        ...message,
        isRead: true, // 返回已读状态
      },
    });
  } catch (error) {
    console.error('Get message detail API error:', error);
    return NextResponse.json(
      { success: false, error: '获取消息详情失败' },
      { status: 500 }
    );
  }
}

// 删除消息（软删除）
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const [deletedMessage] = await db
      .update(messages)
      .set({
        isDeleted: true,
        deletedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(messages.id, parseInt(id)))
      .returning();

    if (!deletedMessage) {
      return NextResponse.json(
        { success: false, error: '消息不存在' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: '消息已删除',
    });
  } catch (error) {
    console.error('Delete message API error:', error);
    return NextResponse.json(
      { success: false, error: '删除消息失败' },
      { status: 500 }
    );
  }
}
