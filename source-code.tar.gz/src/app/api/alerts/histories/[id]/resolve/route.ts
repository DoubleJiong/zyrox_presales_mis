import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { alertHistories } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: idStr } = await params;
    const id = parseInt(idStr);
    const body = await req.json();
    const { userId = 1, resolutionNote = '' } = body;

    // 检查预警记录是否存在
    const existingAlert = await db
      .select()
      .from(alertHistories)
      .where(eq(alertHistories.id, id));

    if (!existingAlert || existingAlert.length === 0) {
      return errorResponse('NOT_FOUND', '预警记录不存在');
    }

    // 更新预警状态为已解决
    const updatedAlert = await db
      .update(alertHistories)
      .set({
        status: 'resolved',
        resolvedAt: new Date(),
        resolvedBy: userId,
        resolutionNote,
        updatedAt: new Date(),
      })
      .where(eq(alertHistories.id, id))
      .returning();

    return NextResponse.json({
      success: true,
      message: '预警已解决',
      data: updatedAlert[0],
    });
  } catch (error) {
    console.error('Failed to resolve alert:', error);
    return errorResponse('INTERNAL_ERROR', '解决预警失败');
  }
}
