import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { subsidiaries } from '@/db/schema';
import { eq, isNull, and, asc } from 'drizzle-orm';
import { successResponse, errorResponse } from '@/lib/api-response';

// GET - 获取分子公司列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const simple = searchParams.get('simple') === 'true';

    // 构建查询条件
    const conditions = [isNull(subsidiaries.deletedAt)];
    if (status) {
      conditions.push(eq(subsidiaries.status, status));
    }

    const list = await db
      .select()
      .from(subsidiaries)
      .where(and(...conditions))
      .orderBy(asc(subsidiaries.subsidiaryName));

    // 简单格式返回（用于下拉选择）
    if (simple) {
      return successResponse(list.map(item => ({
        id: item.id,
        code: item.subsidiaryCode,
        name: item.subsidiaryName,
      })));
    }

    return successResponse(list);
  } catch (error) {
    console.error('Failed to fetch subsidiaries:', error);
    return errorResponse('INTERNAL_ERROR', '获取分子公司列表失败');
  }
}
