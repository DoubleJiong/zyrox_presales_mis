import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { 
  opportunities, 
  projects, 
  leadFollowRecords, 
  quotations,
  users 
} from '@/db/schema';
import { desc, eq, sql, isNull } from 'drizzle-orm';

// 动态类型
type ActivityType = 'opportunity' | 'project' | 'followup' | 'quotation' | 'approval' | 'system';

// 动态项接口
interface Activity {
  id: string;
  type: ActivityType;
  action: string;
  title: string;
  description: string;
  actorId: number;
  actorName: string;
  actorAvatar?: string;
  relatedType?: string;
  relatedId?: number;
  relatedName?: string;
  createdAt: Date;
}

// 获取图标和颜色
const getActivityStyle = (type: ActivityType) => {
  const styles: Record<ActivityType, { icon: string; color: string; bgColor: string }> = {
    opportunity: { icon: 'trending-up', color: 'text-green-500', bgColor: 'bg-green-500/10' },
    project: { icon: 'briefcase', color: 'text-purple-500', bgColor: 'bg-purple-500/10' },
    followup: { icon: 'users', color: 'text-blue-500', bgColor: 'bg-blue-500/10' },
    quotation: { icon: 'file-text', color: 'text-orange-500', bgColor: 'bg-orange-500/10' },
    approval: { icon: 'check-circle', color: 'text-cyan-500', bgColor: 'bg-cyan-500/10' },
    system: { icon: 'alert-circle', color: 'text-yellow-500', bgColor: 'bg-yellow-500/10' },
  };
  return styles[type] || styles.system;
};

// GET /api/activities - 获取最近动态
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '20');
    const types = searchParams.get('types')?.split(',') || ['opportunity', 'project', 'followup', 'quotation'];

    const activities: Activity[] = [];

    // 1. 获取商机动态
    if (types.includes('opportunity')) {
      const opps = await db
        .select({
          id: opportunities.id,
          projectName: opportunities.projectName,
          status: opportunities.status,
          createdAt: opportunities.createdAt,
          ownerId: opportunities.ownerId,
          ownerName: users.realName,
        })
        .from(opportunities)
        .leftJoin(users, eq(opportunities.ownerId, users.id))
        .where(isNull(opportunities.deletedAt))
        .orderBy(desc(opportunities.createdAt))
        .limit(5);

      opps.forEach(opp => {
        const statusLabels: Record<string, string> = {
          prospecting: '挖掘中',
          qualified: '已验证',
          proposal: '方案阶段',
          negotiation: '谈判中',
          won: '赢单',
          lost: '输单',
        };
        activities.push({
          id: `opp-${opp.id}`,
          type: 'opportunity',
          action: opp.status === 'won' ? '赢单' : opp.status === 'lost' ? '输单' : '更新商机',
          title: `${opp.ownerName || '系统'} ${statusLabels[opp.status as string] || '创建了商机'}`,
          description: opp.projectName || '',
          actorId: opp.ownerId || 0,
          actorName: opp.ownerName || '系统',
          relatedType: 'opportunity',
          relatedId: opp.id,
          relatedName: opp.projectName || undefined,
          createdAt: opp.createdAt || new Date(),
        });
      });
    }

    // 2. 获取项目动态
    if (types.includes('project')) {
      const projs = await db
        .select({
          id: projects.id,
          projectName: projects.projectName,
          status: projects.status,
          createdAt: projects.createdAt,
          managerId: projects.managerId,
          managerName: users.realName,
        })
        .from(projects)
        .leftJoin(users, eq(projects.managerId, users.id))
        .orderBy(desc(projects.createdAt))
        .limit(5);

      projs.forEach(proj => {
        const statusLabels: Record<string, string> = {
          pending: '待启动',
          in_progress: '进行中',
          completed: '已完成',
          suspended: '已暂停',
        };
        activities.push({
          id: `proj-${proj.id}`,
          type: 'project',
          action: '项目更新',
          title: `${proj.managerName || '系统'} 更新了项目状态`,
          description: `${proj.projectName} - ${statusLabels[proj.status as string] || proj.status}`,
          actorId: proj.managerId || 0,
          actorName: proj.managerName || '系统',
          relatedType: 'project',
          relatedId: proj.id,
          relatedName: proj.projectName || undefined,
          createdAt: proj.createdAt || new Date(),
        });
      });
    }

    // 3. 获取跟进记录动态
    if (types.includes('followup')) {
      const follows = await db
        .select({
          id: leadFollowRecords.id,
          followContent: leadFollowRecords.followContent,
          followTime: leadFollowRecords.followTime,
          followerId: leadFollowRecords.followerId,
          followerName: users.realName,
        })
        .from(leadFollowRecords)
        .leftJoin(users, eq(leadFollowRecords.followerId, users.id))
        .orderBy(desc(leadFollowRecords.followTime))
        .limit(5);

      follows.forEach(fu => {
        activities.push({
          id: `fu-${fu.id}`,
          type: 'followup',
          action: '线索跟进',
          title: `${fu.followerName || '系统'} 完成了线索跟进`,
          description: fu.followContent?.substring(0, 50) || '',
          actorId: fu.followerId || 0,
          actorName: fu.followerName || '系统',
          relatedType: 'followup',
          relatedId: fu.id,
          createdAt: fu.followTime || new Date(),
        });
      });
    }

    // 4. 获取报价动态
    if (types.includes('quotation')) {
      const quots = await db
        .select({
          id: quotations.id,
          quotationName: quotations.quotationName,
          quotationStatus: quotations.quotationStatus,
          createdAt: quotations.createdAt,
          createdBy: quotations.createdBy,
          creatorName: users.realName,
        })
        .from(quotations)
        .leftJoin(users, eq(quotations.createdBy, users.id))
        .orderBy(desc(quotations.createdAt))
        .limit(5);

      quots.forEach(quot => {
        const statusLabels: Record<string, string> = {
          draft: '草稿',
          pending_approval: '待审批',
          approved: '已审批',
          rejected: '已驳回',
          sent: '已发送',
        };
        activities.push({
          id: `quot-${quot.id}`,
          type: 'quotation',
          action: '报价更新',
          title: `${quot.creatorName || '系统'} ${quot.quotationStatus === 'draft' ? '创建了报价' : '更新了报价状态'}`,
          description: `${quot.quotationName} - ${statusLabels[quot.quotationStatus as string] || quot.quotationStatus}`,
          actorId: quot.createdBy || 0,
          actorName: quot.creatorName || '系统',
          relatedType: 'quotation',
          relatedId: quot.id,
          relatedName: quot.quotationName || undefined,
          createdAt: quot.createdAt || new Date(),
        });
      });
    }

    // 按时间排序并限制数量
    activities.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    const limitedActivities = activities.slice(0, limit);

    // 添加样式信息
    const result = limitedActivities.map(activity => ({
      ...activity,
      style: getActivityStyle(activity.type),
      timeAgo: formatTimeAgo(activity.createdAt),
    }));

    return NextResponse.json({
      success: true,
      data: {
        list: result,
        total: activities.length,
      },
    });
  } catch (error) {
    console.error('Get activities API error:', error);
    return NextResponse.json(
      { success: false, error: '获取动态列表失败' },
      { status: 500 }
    );
  }
}

// 格式化时间
function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - new Date(date).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes}分钟前`;
  if (hours < 24) return `${hours}小时前`;
  if (days < 7) return `${days}天前`;
  
  return new Date(date).toLocaleDateString('zh-CN');
}
