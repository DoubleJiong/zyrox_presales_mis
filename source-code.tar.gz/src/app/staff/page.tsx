'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { DictSelect } from '@/components/dictionary/dict-select';
import {
  Search,
  Plus,
  Mail,
  Phone,
  Building,
  Eye,
  Edit,
  Trash2,
  Calendar,
  MapPin,
  Briefcase,
  User,
  Loader2,
  ChevronDown,
  Check,
} from 'lucide-react';

interface Staff {
  id: number;
  username: string;
  realName: string;
  email: string;
  phone: string | null;
  department: string | null;
  roleId: number | null;
  roleName: string | null;
  roleCode: string | null;
  roleIds: number[]; // 支持多角色
  roleNames: string[]; // 支持多角色名称
  status: string;
  avatar: string | null;
  lastLoginTime: string | null;
  createdAt: string;
  hireDate: string | null;
  position: string | null;
  location: string | null;
  birthday: string | null;
  gender: string | null;
}

const ITEMS_PER_PAGE = 10;

export default function StaffPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [staff, setStaff] = useState<Staff[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  
  // 编辑对话框状态
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);
  const [editForm, setEditForm] = useState({
    realName: '',
    email: '',
    phone: '',
    department: '',
    position: '',
    status: 'active',
    gender: '',
    birthday: '',
    hireDate: '',
    location: '',
    roleIds: [] as number[], // 支持多选角色
  });
  const [saving, setSaving] = useState(false);

  // 新增人员对话框状态
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    username: '',
    password: '',
    realName: '',
    email: '',
    phone: '',
    department: '',
    position: '',
    status: 'active',
    gender: '',
    birthday: '',
    hireDate: '',
    location: '',
    roleIds: [] as number[],
  });
  const [creating, setCreating] = useState(false);

  // 角色列表
  const [rolesList, setRolesList] = useState<Array<{ id: number; roleName: string; roleCode: string }>>([]);

  useEffect(() => {
    fetchStaff();
    fetchRoles();
  }, []);

  const fetchStaff = async () => {
    try {
      const response = await fetch('/api/staff');
      const result = await response.json();
      // API 返回格式: { success: true, data: [...] }
      setStaff(result.data || result || []);
    } catch (error) {
      console.error('Failed to fetch staff:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await fetch('/api/roles');
      const result = await response.json();
      setRolesList(result.data || result || []);
    } catch (error) {
      console.error('Failed to fetch roles:', error);
    }
  };

  const filteredStaff = staff.filter((member) => {
    const matchesSearch =
      (member.realName?.toLowerCase() || '').includes(search.toLowerCase()) ||
      (member.email?.toLowerCase() || '').includes(search.toLowerCase()) ||
      member.phone?.includes(search);

    const matchesDepartment = departmentFilter === 'all' || member.department === departmentFilter;
    const matchesRole = roleFilter === 'all' || member.roleCode === roleFilter;
    const matchesStatus = statusFilter === 'all' || member.status === statusFilter;

    return matchesSearch && matchesDepartment && matchesRole && matchesStatus;
  });

  const paginatedStaff = filteredStaff.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  useEffect(() => {
    setCurrentPage(1);
  }, [search, departmentFilter, roleFilter, statusFilter]);

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      active: { label: '启用', variant: 'default' },
      inactive: { label: '禁用', variant: 'secondary' },
    };
    const statusInfo = statusMap[status] || { label: status, variant: 'default' as const };
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  const getRoleBadge = (roleCode: string | null) => {
    const roleMap: Record<string, string> = {
      admin: '管理员',
      presale_manager: '售前主管',
      hq_presale_engineer: '总部售前',
      solution_engineer: '解决方案',
      regional_presale_engineer: '区域售前',
      sales_rep: '销售代表',
      finance_specialist: '财务专员',
    };
    return roleMap[roleCode || ''] || roleCode || '-';
  };

  const handleDelete = async (id: number) => {
    if (!confirm('确定要删除这个人员吗？')) return;
    
    try {
      const response = await fetch(`/api/staff?id=${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        toast({ title: '删除成功' });
        await fetchStaff();
      }
    } catch (error) {
      console.error('Failed to delete staff:', error);
      toast({
        variant: 'destructive',
        title: '删除失败',
      });
    }
  };

  const handleEdit = (staffMember: Staff) => {
    setEditingStaff(staffMember);
    setEditForm({
      realName: staffMember.realName || '',
      email: staffMember.email || '',
      phone: staffMember.phone || '',
      department: staffMember.department || '',
      position: staffMember.position || '',
      status: staffMember.status || 'active',
      gender: staffMember.gender || '',
      birthday: staffMember.birthday ? staffMember.birthday.split('T')[0] : '',
      hireDate: staffMember.hireDate ? staffMember.hireDate.split('T')[0] : '',
      location: staffMember.location || '',
      roleIds: staffMember.roleIds || [],
    });
    setEditDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!editingStaff) return;
    
    // 验证必填字段
    if (!editForm.realName || !editForm.email) {
      toast({
        variant: 'destructive',
        title: '验证失败',
        description: '姓名和邮箱为必填项',
      });
      return;
    }

    setSaving(true);
    try {
      const response = await fetch(`/api/staff/${editingStaff.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          realName: editForm.realName,
          email: editForm.email,
          phone: editForm.phone || null,
          department: editForm.department || null,
          position: editForm.position || null,
          status: editForm.status,
          gender: editForm.gender || null,
          birthday: editForm.birthday || null,
          hireDate: editForm.hireDate || null,
          location: editForm.location || null,
          roleIds: editForm.roleIds, // 提交多选角色
        }),
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        toast({ title: '保存成功' });
        setEditDialogOpen(false);
        setEditingStaff(null);
        await fetchStaff();
        // 如果当前详情抽屉打开的是刚编辑的人员，更新显示
        if (selectedStaff?.id === editingStaff.id) {
          setSelectedStaff(null);
        }
      } else {
        // 正确提取错误消息 - result.error 可能是对象 {code, message} 或字符串
        const errorMsg = typeof result.error === 'object' && result.error !== null
          ? (result.error.message || JSON.stringify(result.error))
          : (result.error || '保存失败');
        throw new Error(errorMsg);
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: '保存失败',
        description: error instanceof Error ? error.message : '请稍后重试',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleCreate = async () => {
    // 验证必填字段
    if (!createForm.username || !createForm.realName || !createForm.email) {
      toast({
        variant: 'destructive',
        title: '验证失败',
        description: '用户名、姓名和邮箱为必填项',
      });
      return;
    }

    setCreating(true);
    try {
      const response = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: createForm.username,
          password: createForm.password || '123456',
          realName: createForm.realName,
          email: createForm.email,
          phone: createForm.phone || null,
          department: createForm.department || null,
          position: createForm.position || null,
          status: createForm.status,
          gender: createForm.gender || null,
          birthday: createForm.birthday || null,
          hireDate: createForm.hireDate || null,
          location: createForm.location || null,
          roleId: createForm.roleIds[0] || null,
        }),
      });

      const result = await response.json();

      if (response.ok && result.success) {
        toast({ title: '创建成功' });
        setCreateDialogOpen(false);
        // 重置表单
        setCreateForm({
          username: '',
          password: '',
          realName: '',
          email: '',
          phone: '',
          department: '',
          position: '',
          status: 'active',
          gender: '',
          birthday: '',
          hireDate: '',
          location: '',
          roleIds: [],
        });
        await fetchStaff();
      } else {
        const errorMsg = typeof result.error === 'object' && result.error !== null
          ? (result.error.message || JSON.stringify(result.error))
          : (result.error || '创建失败');
        throw new Error(errorMsg);
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: '创建失败',
        description: error instanceof Error ? error.message : '请稍后重试',
      });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-6" data-testid="staff-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">人员管理</h1>
          <p className="text-muted-foreground">管理售前团队成员信息</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          新增人员
        </Button>
      </div>

      {/* 筛选和搜索 */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索姓名、邮箱、电话..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-8"
              />
            </div>
            <DictSelect
              category="department"
              value={departmentFilter === 'all' ? '' : departmentFilter}
              onValueChange={(v) => setDepartmentFilter(v || 'all')}
              placeholder="部门筛选"
              allowClear
              className="w-[180px]"
            />
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="角色筛选" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部角色</SelectItem>
                <SelectItem value="admin">管理员</SelectItem>
                <SelectItem value="presale_manager">售前主管</SelectItem>
                <SelectItem value="hq_presale_engineer">总部售前</SelectItem>
                <SelectItem value="solution_engineer">解决方案</SelectItem>
                <SelectItem value="regional_presale_engineer">区域售前</SelectItem>
                <SelectItem value="sales_rep">销售代表</SelectItem>
                <SelectItem value="finance_specialist">财务专员</SelectItem>
              </SelectContent>
            </Select>
            <DictSelect
              category="user_status"
              value={statusFilter === 'all' ? '' : statusFilter}
              onValueChange={(v) => setStatusFilter(v || 'all')}
              placeholder="状态筛选"
              allowClear
              className="w-[150px]"
            />
          </div>
        </CardContent>
      </Card>

      {/* 人员列表 */}
      <Card>
        <CardHeader>
          <CardTitle>人员列表 ({filteredStaff.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">加载中...</div>
          ) : filteredStaff.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              暂无人员数据
            </div>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>姓名</TableHead>
                    <TableHead>角色</TableHead>
                    <TableHead>联系方式</TableHead>
                    <TableHead>部门</TableHead>
                    <TableHead>职位</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>最后登录</TableHead>
                    <TableHead>创建时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedStaff.map((member) => (
                    <TableRow 
                      key={member.id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => setSelectedStaff(member)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>{member.realName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{member.realName}</div>
                            <div className="text-sm text-muted-foreground">{member.username}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {member.roleIds && member.roleIds.length > 0 ? (
                            member.roleIds.map((roleId, index) => {
                              const role = rolesList.find((r) => r.id === roleId);
                              return (
                                <Badge key={roleId} variant="outline">
                                  {role?.roleName || member.roleNames?.[index] || '-'}
                                </Badge>
                              );
                            })
                          ) : (
                            <Badge variant="outline">{getRoleBadge(member.roleCode)}</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-1 text-sm">
                            <Mail className="h-3 w-3" />
                            {member.email}
                          </div>
                          {member.phone && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              {member.phone}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Building className="h-3 w-3 text-muted-foreground" />
                          {member.department || '-'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Briefcase className="h-3 w-3 text-muted-foreground" />
                          {member.position || '-'}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(member.status)}</TableCell>
                      <TableCell>
                        {member.lastLoginTime
                          ? new Date(member.lastLoginTime).toLocaleDateString('zh-CN')
                          : '从未登录'}
                      </TableCell>
                      <TableCell>
                        {new Date(member.createdAt).toLocaleDateString('zh-CN')}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedStaff(member);
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEdit(member);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(member.id);
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* 分页 */}
              {filteredStaff.length > ITEMS_PER_PAGE && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    显示 {(currentPage - 1) * ITEMS_PER_PAGE + 1} 到{' '}
                    {Math.min(currentPage * ITEMS_PER_PAGE, filteredStaff.length)} 条，共{' '}
                    {filteredStaff.length} 条
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      上一页
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage((p) => Math.min(Math.ceil(filteredStaff.length / ITEMS_PER_PAGE), p + 1))}
                      disabled={currentPage >= Math.ceil(filteredStaff.length / ITEMS_PER_PAGE)}
                    >
                      下一页
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* 人员详情抽屉 */}
      <Drawer open={!!selectedStaff} onOpenChange={(open) => !open && setSelectedStaff(null)} direction="right">
        <DrawerContent className="max-h-[85vh] w-[500px]">
          {selectedStaff && (
            <>
              <DrawerHeader>
                <DrawerTitle className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="text-lg">{selectedStaff.realName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-xl">{selectedStaff.realName}</div>
                    <div className="text-sm text-muted-foreground">{selectedStaff.username}</div>
                  </div>
                </DrawerTitle>
                <DrawerDescription>
                  {selectedStaff.department} · {selectedStaff.position}
                </DrawerDescription>
              </DrawerHeader>

              <ScrollArea className="flex-1 px-4 py-4">
                <div className="space-y-6">
                  {/* 基本信息 */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <User className="h-5 w-5" />
                      基本信息
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">姓名</div>
                        <div className="font-medium">{selectedStaff.realName}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">用户名</div>
                        <div className="font-medium">{selectedStaff.username}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">性别</div>
                        <div className="font-medium">{selectedStaff.gender || '-'}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">出生日期</div>
                        <div className="font-medium">
                          {selectedStaff.birthday ? new Date(selectedStaff.birthday).toLocaleDateString('zh-CN') : '-'}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 联系方式 */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <Mail className="h-5 w-5" />
                      联系方式
                    </h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span>{selectedStaff.email}</span>
                      </div>
                      {selectedStaff.phone && (
                        <div className="flex items-center gap-3">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{selectedStaff.phone}</span>
                        </div>
                      )}
                      {selectedStaff.location && (
                        <div className="flex items-center gap-3">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{selectedStaff.location}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* 职位信息 */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <Briefcase className="h-5 w-5" />
                      职位信息
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">部门</div>
                        <div className="font-medium flex items-center gap-2">
                          <Building className="h-4 w-4 text-muted-foreground" />
                          {selectedStaff.department || '-'}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">职位</div>
                        <div className="font-medium">{selectedStaff.position || '-'}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">角色</div>
                        <div className="font-medium">
                          <div className="flex flex-wrap gap-1">
                            {selectedStaff.roleIds && selectedStaff.roleIds.length > 0 ? (
                              selectedStaff.roleIds.map((roleId, index) => {
                                const role = rolesList.find((r) => r.id === roleId);
                                return (
                                  <Badge key={roleId} variant="outline">
                                    {role?.roleName || selectedStaff.roleNames?.[index] || '-'}
                                  </Badge>
                                );
                              })
                            ) : (
                              <Badge variant="outline">{getRoleBadge(selectedStaff.roleCode)}</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">状态</div>
                        <div className="font-medium">{getStatusBadge(selectedStaff.status)}</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">入职日期</div>
                        <div className="font-medium flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {selectedStaff.hireDate ? new Date(selectedStaff.hireDate).toLocaleDateString('zh-CN') : '-'}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">创建时间</div>
                        <div className="font-medium">{new Date(selectedStaff.createdAt).toLocaleDateString('zh-CN')}</div>
                      </div>
                    </div>
                  </div>

                  {/* 账户信息 */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg flex items-center gap-2">
                      <User className="h-5 w-5" />
                      账户信息
                    </h3>
                    <div className="grid grid-cols-1 gap-4">
                      <div className="space-y-1">
                        <div className="text-sm text-muted-foreground">最后登录时间</div>
                        <div className="font-medium">
                          {selectedStaff.lastLoginTime
                            ? new Date(selectedStaff.lastLoginTime).toLocaleString('zh-CN')
                            : '从未登录'}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollArea>

              <DrawerFooter>
                <Button variant="outline" onClick={() => setSelectedStaff(null)}>
                  关闭
                </Button>
                <Button onClick={() => {
                  setSelectedStaff(null);
                  handleEdit(selectedStaff);
                }}>
                  <Edit className="h-4 w-4 mr-2" />
                  编辑信息
                </Button>
              </DrawerFooter>
            </>
          )}
        </DrawerContent>
      </Drawer>

      {/* 编辑人员对话框 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>编辑人员信息</DialogTitle>
            <DialogDescription>
              修改人员的基本信息、联系方式和职位信息
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <User className="h-5 w-5" />
                基本信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="realName">姓名 *</Label>
                  <Input
                    id="realName"
                    value={editForm.realName}
                    onChange={(e) => setEditForm({ ...editForm, realName: e.target.value })}
                    placeholder="请输入姓名"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">性别</Label>
                  <DictSelect
                    category="gender"
                    value={editForm.gender}
                    onValueChange={(v) => setEditForm({ ...editForm, gender: v })}
                    placeholder="请选择性别"
                    allowClear
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthday">出生日期</Label>
                  <Input
                    id="birthday"
                    type="date"
                    value={editForm.birthday}
                    onChange={(e) => setEditForm({ ...editForm, birthday: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">状态</Label>
                  <DictSelect
                    category="user_status"
                    value={editForm.status}
                    onValueChange={(v) => setEditForm({ ...editForm, status: v })}
                    placeholder="请选择状态"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="roleIds">角色</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        className="w-full justify-between font-normal"
                      >
                        {editForm.roleIds.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {editForm.roleIds.map((roleId) => {
                              const role = rolesList.find((r) => r.id === roleId);
                              return role ? (
                                <Badge key={roleId} variant="secondary" className="mr-1">
                                  {role.roleName}
                                </Badge>
                              ) : null;
                            })}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">请选择角色</span>
                        )}
                        <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[300px] p-0" align="start">
                      <div className="p-2">
                        {rolesList.length === 0 ? (
                          <div className="py-2 text-center text-sm text-muted-foreground">
                            暂无角色
                          </div>
                        ) : (
                          <div className="space-y-1">
                            {rolesList.map((role) => {
                              const isSelected = editForm.roleIds.includes(role.id);
                              return (
                                <div
                                  key={role.id}
                                  className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-muted cursor-pointer"
                                  onClick={() => {
                                    const newRoleIds = isSelected
                                      ? editForm.roleIds.filter((id) => id !== role.id)
                                      : [...editForm.roleIds, role.id];
                                    setEditForm({ ...editForm, roleIds: newRoleIds });
                                  }}
                                >
                                  <Checkbox
                                    checked={isSelected}
                                    className="pointer-events-none"
                                  />
                                  <span className="flex-1">{role.roleName}</span>
                                  {isSelected && (
                                    <Check className="h-4 w-4 text-primary" />
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </div>

            {/* 联系方式 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Mail className="h-5 w-5" />
                联系方式
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">邮箱 *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    placeholder="请输入邮箱"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">电话</Label>
                  <Input
                    id="phone"
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    placeholder="请输入电话"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="location">所在地</Label>
                  <Input
                    id="location"
                    value={editForm.location}
                    onChange={(e) => setEditForm({ ...editForm, location: e.target.value })}
                    placeholder="请输入所在地"
                  />
                </div>
              </div>
            </div>

            {/* 职位信息 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                职位信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="department">部门</Label>
                  <DictSelect
                    category="department"
                    value={editForm.department}
                    onValueChange={(v) => setEditForm({ ...editForm, department: v })}
                    placeholder="请选择部门"
                    allowClear
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="position">职位</Label>
                  <Input
                    id="position"
                    value={editForm.position}
                    onChange={(e) => setEditForm({ ...editForm, position: e.target.value })}
                    placeholder="请输入职位"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hireDate">入职日期</Label>
                  <Input
                    id="hireDate"
                    type="date"
                    value={editForm.hireDate}
                    onChange={(e) => setEditForm({ ...editForm, hireDate: e.target.value })}
                  />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleSaveEdit} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  保存中...
                </>
              ) : (
                '保存'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 新增人员对话框 */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>新增人员</DialogTitle>
            <DialogDescription>
              添加新的售前团队成员
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <User className="h-5 w-5" />
                基本信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="username">用户名 *</Label>
                  <Input
                    id="username"
                    value={createForm.username}
                    onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                    placeholder="请输入用户名"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">密码</Label>
                  <Input
                    id="password"
                    type="password"
                    value={createForm.password}
                    onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                    placeholder="默认: 123456"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="realName">姓名 *</Label>
                  <Input
                    id="realName"
                    value={createForm.realName}
                    onChange={(e) => setCreateForm({ ...createForm, realName: e.target.value })}
                    placeholder="请输入姓名"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">性别</Label>
                  <DictSelect
                    category="gender"
                    value={createForm.gender}
                    onValueChange={(v) => setCreateForm({ ...createForm, gender: v })}
                    placeholder="请选择性别"
                    allowClear
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthday">出生日期</Label>
                  <Input
                    id="birthday"
                    type="date"
                    value={createForm.birthday}
                    onChange={(e) => setCreateForm({ ...createForm, birthday: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* 联系方式 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Mail className="h-5 w-5" />
                联系方式
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">邮箱 *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={createForm.email}
                    onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                    placeholder="请输入邮箱"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">电话</Label>
                  <Input
                    id="phone"
                    value={createForm.phone}
                    onChange={(e) => setCreateForm({ ...createForm, phone: e.target.value })}
                    placeholder="请输入电话"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">办公地点</Label>
                  <Input
                    id="location"
                    value={createForm.location}
                    onChange={(e) => setCreateForm({ ...createForm, location: e.target.value })}
                    placeholder="请输入办公地点"
                  />
                </div>
              </div>
            </div>

            {/* 职位信息 */}
            <div className="space-y-4">
              <h3 className="font-semibold flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                职位信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="department">部门</Label>
                  <DictSelect
                    category="department"
                    value={createForm.department}
                    onValueChange={(v) => setCreateForm({ ...createForm, department: v })}
                    placeholder="请选择部门"
                    allowClear
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="position">职位</Label>
                  <Input
                    id="position"
                    value={createForm.position}
                    onChange={(e) => setCreateForm({ ...createForm, position: e.target.value })}
                    placeholder="请输入职位"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hireDate">入职日期</Label>
                  <Input
                    id="hireDate"
                    type="date"
                    value={createForm.hireDate}
                    onChange={(e) => setCreateForm({ ...createForm, hireDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">状态</Label>
                  <Select
                    value={createForm.status}
                    onValueChange={(v) => setCreateForm({ ...createForm, status: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="请选择状态" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">启用</SelectItem>
                      <SelectItem value="inactive">禁用</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* 角色分配 */}
            <div className="space-y-4">
              <h3 className="font-semibold">角色分配</h3>
              <div className="grid grid-cols-2 gap-2">
                {rolesList.map((role) => (
                  <div key={role.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`create-role-${role.id}`}
                      checked={createForm.roleIds.includes(role.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setCreateForm({
                            ...createForm,
                            roleIds: [...createForm.roleIds, role.id],
                          });
                        } else {
                          setCreateForm({
                            ...createForm,
                            roleIds: createForm.roleIds.filter((id) => id !== role.id),
                          });
                        }
                      }}
                    />
                    <Label htmlFor={`create-role-${role.id}`} className="cursor-pointer">
                      {role.roleName}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={handleCreate} disabled={creating}>
              {creating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  创建中...
                </>
              ) : (
                '创建'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
