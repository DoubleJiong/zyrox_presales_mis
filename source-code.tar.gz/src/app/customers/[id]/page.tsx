'use client';

import { useState, useEffect, use } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { SearchableSelect } from '@/components/ui/searchable-select';
import { DictSelect } from '@/components/dictionary/dict-select';
import { SearchableDictSelect } from '@/components/dictionary/searchable-dict-select';
import { 
  ArrowLeft, 
  Phone, 
  Mail, 
  MapPin, 
  Plus, 
  Edit3, 
  FileText,
  Briefcase,
  Users,
  Sparkles,
  Calendar,
  Building2,
  DollarSign,
  Send,
  Upload,
  X,
  FileIcon,
  ChevronDown,
  ChevronRight,
  Clock
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { validatePhone, validateEmail, validateRequired, validateAmount, validateDateRange, validateLength } from '@/lib/validators';
import { extractErrorMessage } from '@/lib/api-response';
import { useFileUpload } from '@/hooks/use-file-upload';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2 } from 'lucide-react';

interface Customer {
  id: number;
  customerId: string;
  customerName: string;
  customerType: string;
  customerTypeId?: number;
  region: string;
  status: string;
  totalAmount: string;
  currentProjectCount: number;
  lastCooperationDate: string | null;
  maxProjectAmount: string;
  contactName: string | null;
  contactPhone: string | null;
  contactEmail: string | null;
  address: string | null;
  description: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Project {
  id: number;
  projectCode: string;
  projectName: string;
  projectType: string;
  status: string;
  priority: string;
  progress: number;
  estimatedAmount: string;
  startDate: string;
  endDate: string;
  createdAt: string;
}

interface SupportStaff {
  id: number;
  name: string;
  role: string;
}

interface FollowRecord {
  id: number;
  followContent: string;
  followTime: string;
  followType: string;
  followerName: string;
  projectId?: number;
  projectName?: string;
  attachmentUrl?: string;
  attachmentName?: string;
}

export default function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter();
  const resolvedParams = use(params);
  const { toast } = useToast();

  // 区域选项：除浙江省以外的所有省份 + 浙江省所有地市
  const regionOptions = [
    // 直辖市
    { value: '北京市', label: '北京市' },
    { value: '天津市', label: '天津市' },
    { value: '上海市', label: '上海市' },
    { value: '重庆市', label: '重庆市' },
    // 省份（不含浙江）
    { value: '河北省', label: '河北省' },
    { value: '山西省', label: '山西省' },
    { value: '辽宁省', label: '辽宁省' },
    { value: '吉林省', label: '吉林省' },
    { value: '黑龙江省', label: '黑龙江省' },
    { value: '江苏省', label: '江苏省' },
    { value: '安徽省', label: '安徽省' },
    { value: '福建省', label: '福建省' },
    { value: '江西省', label: '江西省' },
    { value: '山东省', label: '山东省' },
    { value: '河南省', label: '河南省' },
    { value: '湖北省', label: '湖北省' },
    { value: '湖南省', label: '湖南省' },
    { value: '广东省', label: '广东省' },
    { value: '海南省', label: '海南省' },
    { value: '四川省', label: '四川省' },
    { value: '贵州省', label: '贵州省' },
    { value: '云南省', label: '云南省' },
    { value: '陕西省', label: '陕西省' },
    { value: '甘肃省', label: '甘肃省' },
    { value: '青海省', label: '青海省' },
    { value: '台湾省', label: '台湾省' },
    // 自治区
    { value: '内蒙古自治区', label: '内蒙古自治区' },
    { value: '广西壮族自治区', label: '广西壮族自治区' },
    { value: '西藏自治区', label: '西藏自治区' },
    { value: '宁夏回族自治区', label: '宁夏回族自治区' },
    { value: '新疆维吾尔自治区', label: '新疆维吾尔自治区' },
    // 特别行政区
    { value: '香港特别行政区', label: '香港特别行政区' },
    { value: '澳门特别行政区', label: '澳门特别行政区' },
    // 浙江省地市
    { value: '杭州市', label: '杭州市（浙江）' },
    { value: '宁波市', label: '宁波市（浙江）' },
    { value: '温州市', label: '温州市（浙江）' },
    { value: '嘉兴市', label: '嘉兴市（浙江）' },
    { value: '湖州市', label: '湖州市（浙江）' },
    { value: '绍兴市', label: '绍兴市（浙江）' },
    { value: '金华市', label: '金华市（浙江）' },
    { value: '衢州市', label: '衢州市（浙江）' },
    { value: '舟山市', label: '舟山市（浙江）' },
    { value: '台州市', label: '台州市（浙江）' },
    { value: '丽水市', label: '丽水市（浙江）' },
  ];

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectsTotal, setProjectsTotal] = useState(0);
  const [projectsPage, setProjectsPage] = useState(1);
  const [projectsLoading, setProjectsLoading] = useState(false);
  const PROJECTS_PAGE_SIZE = 5;
  const [followRecords, setFollowRecords] = useState<FollowRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // 添加跟进记录相关
  const [addFollowDialogOpen, setAddFollowDialogOpen] = useState(false);
  const [usersList, setUsersList] = useState<Array<{ id: number; realName: string; username: string; department?: string; status?: string }>>([]);
  const [newFollow, setNewFollow] = useState({
    followerName: '', // 将在用户列表加载后设置
    followTime: new Date().toISOString().slice(0, 16),
    followType: '',
    projectId: 'none',
    followContent: '',
    attachment: null as File | null,
    isBusinessTrip: false
  });
  const [submittingFollow, setSubmittingFollow] = useState(false);
  
  // 分片上传相关状态
  const [attachmentUploading, setAttachmentUploading] = useState(false);
  const [attachmentUploadProgress, setAttachmentUploadProgress] = useState(0);
  const [uploadedAttachment, setUploadedAttachment] = useState<{
    key: string;
    name: string;
    size: number;
    type: string;
  } | null>(null);
  
  const { selectFile, upload, state: uploadState } = useFileUpload({
    targetPath: 'follows',
    chunkSize: 5 * 1024 * 1024, // 5MB
    concurrency: 3,
    onProgress: (progress) => {
      setAttachmentUploadProgress(progress.progress);
    },
    onSuccess: (result) => {
      setUploadedAttachment({
        key: result.key,
        name: result.file.name,
        size: result.file.size,
        type: result.file.type,
      });
      setAttachmentUploading(false);
    },
    onError: (error) => {
      console.error('Attachment upload failed:', error);
      setAttachmentUploading(false);
      toast({
        variant: 'destructive',
        title: '上传失败',
        description: '佐证物上传失败，请重试',
      });
    },
  });
  
  // 执行分片上传
  const doChunkUpload = async (file: File) => {
    const valid = selectFile(file);
    if (valid) {
      setAttachmentUploading(true);
      setAttachmentUploadProgress(0);
      await upload();
    }
  };

  // 时间轴展开状态
  const [expandedRecords, setExpandedRecords] = useState<Set<number>>(new Set());
  
  // 跟进记录分页状态
  const [displayCount, setDisplayCount] = useState(5); // 默认显示5条
  const RECORDS_PER_PAGE = 5; // 每次加载5条

  // 售前服务类型（从字典获取）
  const [serviceTypes, setServiceTypes] = useState<Array<{ id: number; serviceCode: string; serviceName: string }>>([]);

  // 客户类型（从字典获取）
  const [customerTypes, setCustomerTypes] = useState<Array<{ id: number; code: string; name: string }>>([]);

  // 状态评价
  const [statusEvaluation, setStatusEvaluation] = useState('');

  // 当前用户角色（模拟）
  const currentUserRole: string = 'admin'; // presale_staff, presale_manager, admin

  // 编辑客户信息相关
  const [isEditing, setIsEditing] = useState(false);
  const [editedCustomer, setEditedCustomer] = useState<Partial<Customer>>({});
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [savingCustomer, setSavingCustomer] = useState(false);

  // 客户类型和客户状态的选项通过字典系统获取，无需本地状态

  const fetchDictionaryOptions = async () => {
    try {
      const response = await fetch('/api/dictionary/options?categories=industry,customer_status,project_status,region,priority,service_type');
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          // 转换字典格式为兼容格式 - 客户类型使用行业分类
          if (result.data.industry) {
            setCustomerTypes(result.data.industry.map((item: any) => ({
              id: item.value,
              code: item.value,
              name: item.label,
            })));
          }
          // 加载跟进类型（使用 service_type）
          if (result.data.service_type) {
            setServiceTypes(result.data.service_type.map((item: any) => ({
              id: item.value,
              serviceCode: item.value,
              serviceName: item.label,
            })));
          }
        }
      }
    } catch (error) {
      console.error('Failed to fetch dictionary options:', error);
    }
  };

  const fetchCustomerDetail = async () => {
    try {
      const response = await fetch(`/api/customers/${resolvedParams.id}`);
      if (response.ok) {
        const result = await response.json();
        // API 返回格式: { success: true, data: {...} }
        const data = result.data;
        if (data) {
          setCustomer(data);
        }
      }
    } catch (error) {
      console.error('Failed to fetch customer:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchProjects = async (page: number = 1) => {
    setProjectsLoading(true);
    try {
      const response = await fetch(`/api/customers/${resolvedParams.id}/projects?page=${page}&pageSize=${PROJECTS_PAGE_SIZE}`);
      if (response.ok) {
        const result = await response.json();
        // API 返回格式: { success: true, data: [...], meta: { pagination: { total, page, pageSize } } }
        setProjects(result.data || []);
        setProjectsTotal(result.meta?.pagination?.total || 0);
        setProjectsPage(page);
      }
    } catch (error) {
      console.error('Failed to fetch projects:', error);
      setProjects([]);
      setProjectsTotal(0);
    } finally {
      setProjectsLoading(false);
    }
  };

  const fetchFollowRecords = async () => {
    try {
      const response = await fetch(`/api/customers/${resolvedParams.id}/follows`);
      if (response.ok) {
        const result = await response.json();
        // API 返回格式: { success: true, data: [...] }
        const data = result.data || [];
        if (Array.isArray(data)) {
          // API已经返回正确的字段名，直接设置
          setFollowRecords(data);
        } else {
          setFollowRecords([]);
        }
      } else {
        setFollowRecords([]);
      }
    } catch (error) {
      console.error('Failed to fetch follow records:', error);
      setFollowRecords([]);
    }
  };

  const fetchUsersList = async () => {
    try {
      const response = await fetch('/api/users');
      if (response.ok) {
        const result = await response.json();
        const users = result.data || result || [];
        if (Array.isArray(users) && users.length > 0) {
          setUsersList(users);
          // 设置默认跟进人为第一个用户（或当前登录用户）
          const firstUser = users[0];
          setNewFollow(prev => ({
            ...prev,
            followerName: firstUser.realName
          }));
        }
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
      // 如果获取失败，设置一个默认值
      setNewFollow(prev => ({
        ...prev,
        followerName: '系统管理员'
      }));
    }
  };

  // 初始化加载数据
  useEffect(() => {
    const initData = async () => {
      await Promise.all([
        fetchDictionaryOptions(),
        fetchCustomerDetail(),
        fetchProjects(1),
        fetchFollowRecords(),
        fetchUsersList(),
      ]);
    };
    initData();
  }, [resolvedParams.id]);

  // 当客户数据或项目数据变化时，更新状态评价
  useEffect(() => {
    if (customer) {
      const statusText = customer.status === 'active' ? '活跃' : 
                        customer.status === 'potential' ? '潜在' : 
                        customer.status === 'inactive' ? '非活跃' : '已流失';
      // 使用 projectsTotal（总项目数）而不是 currentProjectCount（进行中项目数）
      const projectCountText = projectsTotal > 0 ? `${projectsTotal} 个项目` : '暂无项目';
      setStatusEvaluation(`${statusText}客户，${projectCountText}`);
    }
  }, [customer, projectsTotal]);

  const handleAddFollow = async () => {
    if (!newFollow.followerName) {
      toast({
        variant: 'destructive',
        title: '验证失败',
        description: '请选择跟进人',
      });
      return;
    }
    if (!newFollow.followContent.trim()) {
      toast({
        variant: 'destructive',
        title: '验证失败',
        description: '请填写跟进内容',
      });
      return;
    }
    if (!newFollow.followType) {
      toast({
        variant: 'destructive',
        title: '验证失败',
        description: '请选择跟进类型',
      });
      return;
    }

    setSubmittingFollow(true);
    try {
      const formData = new FormData();
      formData.append('followContent', newFollow.followContent);
      formData.append('followType', newFollow.followType);
      formData.append('followTime', newFollow.followTime);
      formData.append('followerName', newFollow.followerName);
      formData.append('isBusinessTrip', newFollow.isBusinessTrip ? 'true' : 'false');
      if (newFollow.projectId) {
        formData.append('projectId', newFollow.projectId);
      }
      // 添加佐证文件
      // 如果已通过分片上传完成，则发送文件key；否则发送文件本身
      if (uploadedAttachment) {
        formData.append('attachmentKey', uploadedAttachment.key);
        formData.append('attachmentName', uploadedAttachment.name);
        formData.append('attachmentSize', String(uploadedAttachment.size));
      } else if (newFollow.attachment) {
        formData.append('attachment', newFollow.attachment);
      }

      const response = await fetch(`/api/customers/${resolvedParams.id}/follows`, {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setAddFollowDialogOpen(false);
        // 重置表单 - 使用当前用户列表的第一个用户作为默认值
        const defaultFollower = usersList.length > 0 ? usersList[0].realName : '';
        setNewFollow({
          followerName: defaultFollower,
          followTime: new Date().toISOString().slice(0, 16),
          followType: '',
          projectId: 'none',
          followContent: '',
          attachment: null,
          isBusinessTrip: false
        });
        setUploadedAttachment(null);
        setAttachmentUploadProgress(0);
        fetchFollowRecords();
        toast({
          title: '操作成功',
          description: '跟进记录添加成功',
        });
      } else {
        const error = await response.json();
        toast({
          variant: 'destructive',
          title: '操作失败',
          description: extractErrorMessage(error.error, '添加跟进记录失败'),
        });
      }
    } catch (error) {
      console.error('Failed to add follow record:', error);
      toast({
        variant: 'destructive',
        title: '操作失败',
        description: error instanceof Error ? error.message : '添加跟进记录失败',
      });
    } finally {
      setSubmittingFollow(false);
    }
  };

  const toggleExpand = (recordId: number) => {
    setExpandedRecords(prev => {
      const newSet = new Set(prev);
      if (newSet.has(recordId)) {
        newSet.delete(recordId);
      } else {
        newSet.add(recordId);
      }
      return newSet;
    });
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      active: { label: '活跃', variant: 'default' },
      potential: { label: '潜在', variant: 'secondary' },
      inactive: { label: '非活跃', variant: 'outline' },
      lost: { label: '已流失', variant: 'destructive' },
    };
    const statusInfo = statusMap[status] || { label: status, variant: 'default' as const };
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  const getTypeBadge = (type: string) => {
    // 颜色配置（保持视觉效果一致性）
    const colorMap: Record<string, string> = {
      education: 'bg-purple-100 text-purple-700',
      government: 'bg-blue-100 text-blue-700',
      enterprise: 'bg-green-100 text-green-700',
      medical: 'bg-red-100 text-red-700',
      other: 'bg-gray-100 text-gray-700',
    };
    
    // 从 customerTypes 中查找类型名称（优先使用系统设置中的名称）
    const matchedType = customerTypes.find(t => t.code === type);
    const displayLabel = matchedType?.name || type || '未知';
    
    // 使用硬编码颜色或默认颜色
    const color = colorMap[type] || 'bg-gray-100 text-gray-700';
    
    return <span className={`px-2 py-1 rounded-full text-xs font-medium ${color}`}>{displayLabel}</span>;
  };

  const formatCurrency = (amount: string) => {
    return `¥${Number(amount).toLocaleString()}`;
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '-';
    return new Date(dateStr).toLocaleDateString('zh-CN');
  };

  const formatDateTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleString('zh-CN');
  };

  // 跟进记录筛选
  const [filterStaff, setFilterStaff] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterYear, setFilterYear] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');

  // 获取所有筛选选项
  const allStaff = Array.from(new Set(followRecords.filter(r => r?.followerName).map(r => r.followerName)));
  const allTypes = Array.from(new Set(followRecords.filter(r => r?.followType).map(r => r.followType)));
  const allYears = Array.from(new Set(followRecords.filter(r => r?.followTime).map(r => new Date(r.followTime).getFullYear()))).sort((a, b) => b - a);

  // 筛选跟进记录
  const filteredFollowRecords = followRecords.filter((record) => {
    if (!record || !record.followTime) return false;
    
    const recordDate = new Date(record.followTime);

    const matchesStaff = filterStaff === 'all' || record.followerName === filterStaff;
    const matchesType = filterType === 'all' || record.followType === filterType;
    const matchesYear = filterYear === 'all' || recordDate.getFullYear().toString() === filterYear;
    const matchesMonth = filterMonth === 'all' || (recordDate.getMonth() + 1).toString() === filterMonth;
    const matchesProject = filterProject === 'all' ||
      (!record.projectId && filterProject === 'none') ||
      (record.projectId && filterProject === 'has') ||
      record.projectId?.toString() === filterProject;

    return matchesStaff && matchesType && matchesYear && matchesMonth && matchesProject;
  });

  // 重置筛选
  const resetFilters = () => {
    setFilterStaff('all');
    setFilterType('all');
    setFilterYear('all');
    setFilterMonth('all');
    setFilterProject('all');
  };

  // 加载更多跟进记录
  const loadMoreRecords = () => {
    setDisplayCount(prev => prev + RECORDS_PER_PAGE);
  };

  // 重置显示数量（当筛选条件变化时）
  useEffect(() => {
    setDisplayCount(RECORDS_PER_PAGE);
  }, [filterStaff, filterType, filterYear, filterMonth, filterProject]);

  const handleEditCustomer = () => {
    if (!customer) return;
    setEditedCustomer({ ...customer });
    setIsEditing(true);
  };

  const handleSaveCustomer = async () => {
    if (!customer) return;

    setSavingCustomer(true);
    try {
      // 构建请求数据，确保字段名正确
      const requestData = {
        customerName: editedCustomer.customerName || customer.customerName,
        customerTypeId: editedCustomer.customerTypeId || customer.customerTypeId,
        customerType: editedCustomer.customerType || customer.customerType, // 同时发送类型名称
        region: editedCustomer.region || customer.region,
        status: editedCustomer.status || customer.status,
        contactName: editedCustomer.contactName ?? customer.contactName,
        contactPhone: editedCustomer.contactPhone ?? customer.contactPhone,
        contactEmail: editedCustomer.contactEmail ?? customer.contactEmail,
        address: editedCustomer.address ?? customer.address,
        description: editedCustomer.description ?? customer.description,
      };

      const response = await fetch(`/api/customers/${customer.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData),
      });

      const result = await response.json();
      
      if (response.ok && result.success) {
        await fetchCustomerDetail();
        setIsEditing(false);
        setEditedCustomer({});
        toast({
          title: '操作成功',
          description: '客户信息更新成功',
        });
      } else {
        // 使用 extractErrorMessage 安全提取错误消息
        toast({
          variant: 'destructive',
          title: '操作失败',
          description: extractErrorMessage(result.error, '客户信息更新失败'),
        });
      }
    } catch (error) {
      console.error('Failed to update customer:', error);
      toast({
        variant: 'destructive',
        title: '操作失败',
        description: '客户信息更新失败，请检查网络连接',
      });
    } finally {
      setSavingCustomer(false);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedCustomer({});
  };

  const handleConfirmSave = () => {
    // 校验联系电话
    if (editedCustomer.contactPhone) {
      const phoneResult = validatePhone(editedCustomer.contactPhone);
      if (!phoneResult.valid) {
        toast({
          variant: 'destructive',
          title: '验证失败',
          description: phoneResult.message,
        });
        setShowConfirmDialog(false);
        return;
      }
    }
    
    // 校验联系邮箱
    if (editedCustomer.contactEmail) {
      const emailResult = validateEmail(editedCustomer.contactEmail);
      if (!emailResult.valid) {
        toast({
          variant: 'destructive',
          title: '验证失败',
          description: emailResult.message,
        });
        setShowConfirmDialog(false);
        return;
      }
    }
    
    setShowConfirmDialog(false);
    handleSaveCustomer();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-muted-foreground">加载中...</div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-muted-foreground">客户不存在</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面头部 */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          返回
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold tracking-tight">{customer.customerName}</h1>
          <p className="text-muted-foreground mt-1">{customer.customerId} • {customer.contactName}</p>
        </div>
        <div className="flex items-center gap-2">
          {getTypeBadge(customer.customerType)}
          {getStatusBadge(customer.status)}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* 左侧主要内容区域 */}
        <div className="lg:col-span-2 space-y-6">
          {/* 客户基本信息 */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>客户信息</CardTitle>
                {isEditing && (
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCancelEdit}
                    >
                      取消
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => setShowConfirmDialog(true)}
                    >
                      确认修改
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1">
                  <Label className="text-muted-foreground">客户名称</Label>
                  {isEditing ? (
                    <Input
                      value={editedCustomer.customerName || ''}
                      onChange={(e) => setEditedCustomer({ ...editedCustomer, customerName: e.target.value })}
                    />
                  ) : (
                    <p className="font-medium">{customer.customerName}</p>
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">客户类型</Label>
                  {isEditing ? (
                    <SearchableDictSelect
                      category="customer_type"
                      value={editedCustomer.customerType || customer.customerType}
                      onValueChange={(value) => setEditedCustomer({ ...editedCustomer, customerType: value })}
                      placeholder="请选择客户类型"
                      searchPlaceholder="搜索客户类型..."
                      notFoundText="未找到匹配的客户类型"
                    />
                  ) : (
                    getTypeBadge(customer.customerType)
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">客户状态</Label>
                  {isEditing ? (
                    <SearchableDictSelect
                      category="customer_status"
                      value={editedCustomer.status || customer.status}
                      onValueChange={(value) => setEditedCustomer({ ...editedCustomer, status: value })}
                      placeholder="请选择客户状态"
                      searchPlaceholder="搜索客户状态..."
                      notFoundText="未找到匹配的客户状态"
                    />
                  ) : (
                    getStatusBadge(customer.status)
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">所在区域</Label>
                  {isEditing ? (
                    <SearchableSelect
                      options={regionOptions}
                      value={editedCustomer.region || ''}
                      onValueChange={(value) => setEditedCustomer({ ...editedCustomer, region: value })}
                      placeholder="请选择地区"
                      emptyText="未找到匹配的地区"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <p className="font-medium">{customer.region || '-'}</p>
                    </div>
                  )}
                </div>
                <div className="space-y-1 md:col-span-2">
                  <Label className="text-muted-foreground">详细地址</Label>
                  {isEditing ? (
                    <Input
                      value={editedCustomer.address || ''}
                      onChange={(e) => setEditedCustomer({ ...editedCustomer, address: e.target.value })}
                      placeholder="请输入详细地址"
                    />
                  ) : (
                    <p className="font-medium">{customer.address || '-'}</p>
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">联系人</Label>
                  {isEditing ? (
                    <Input
                      value={editedCustomer.contactName || ''}
                      onChange={(e) => setEditedCustomer({ ...editedCustomer, contactName: e.target.value })}
                    />
                  ) : (
                    <p className="font-medium">{customer.contactName || '-'}</p>
                  )}
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">联系电话</Label>
                  {isEditing ? (
                    <Input
                      value={editedCustomer.contactPhone || ''}
                      onChange={(e) => setEditedCustomer({ ...editedCustomer, contactPhone: e.target.value })}
                      placeholder="支持手机号或座机号"
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <p className="font-medium">{customer.contactPhone || '-'}</p>
                    </div>
                  )}
                </div>
                <div className="space-y-1 md:col-span-2">
                  <Label className="text-muted-foreground">联系邮箱</Label>
                  {isEditing ? (
                    <Input
                      value={editedCustomer.contactEmail || ''}
                      onChange={(e) => setEditedCustomer({ ...editedCustomer, contactEmail: e.target.value })}
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <p className="font-medium">{customer.contactEmail || '-'}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 space-y-1">
                <Label className="text-muted-foreground">客户描述</Label>
                {isEditing ? (
                  <Textarea
                    value={editedCustomer.description || ''}
                    onChange={(e) => setEditedCustomer({ ...editedCustomer, description: e.target.value })}
                    rows={3}
                  />
                ) : (
                  <p className="text-sm whitespace-pre-wrap">{customer.description || '-'}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 历史数据统计 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                历史数据统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                  <div className="text-sm text-blue-600 mb-1">历史项目总额</div>
                  <div className="text-2xl font-bold text-blue-700">{formatCurrency(customer.totalAmount)}</div>
                </div>
                <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                  <div className="text-sm text-green-600 mb-1">历史最大项目</div>
                  <div className="text-2xl font-bold text-green-700">{formatCurrency(customer.maxProjectAmount)}</div>
                </div>
                <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                  <div className="text-sm text-purple-600 mb-1">历史项目数</div>
                  <div className="text-2xl font-bold text-purple-700">{projects.length}</div>
                </div>
              </div>

              {/* 历史支持人员名单 */}
              <div className="mt-4 p-4 rounded-lg border bg-muted/30">
                <div className="text-sm text-muted-foreground mb-3 flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  历史支持人员名单
                </div>
                <div className="flex flex-wrap gap-2">
                  {allStaff.filter(Boolean).map((staff, index) => (
                    <Badge key={index} variant="secondary" className="gap-1 items-center">
                      <div className="h-4 w-4 rounded-full bg-muted flex items-center justify-center text-xs flex-shrink-0">
                        {staff?.charAt(0) || '?'}
                      </div>
                      <span className="truncate max-w-[60px]">{staff}</span>
                    </Badge>
                  ))}
                  {allStaff.filter(Boolean).length === 0 && (
                    <span className="text-sm text-muted-foreground">暂无支持人员记录</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 跟进记录时间轴 */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    跟进记录
                  </CardTitle>
                  <CardDescription>
                    共 {filteredFollowRecords.length} 条记录
                    {(filterStaff !== 'all' || filterType !== 'all' || filterYear !== 'all' || filterMonth !== 'all' || filterProject !== 'all') && (
                      <span className="ml-2 text-muted-foreground">(已筛选)</span>
                    )}
                  </CardDescription>
                </div>
                <Dialog open={addFollowDialogOpen} onOpenChange={setAddFollowDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      添加跟进
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>添加跟进记录</DialogTitle>
                      <DialogDescription>
                        填写跟进信息，记录客户沟通情况
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="followerName">跟进人</Label>
                          <SearchableSelect
                            options={usersList.filter(user => user && user.realName && user.status !== 'inactive').map(user => ({
                              value: user.realName,
                              label: user.realName
                            }))}
                            value={newFollow.followerName}
                            onValueChange={(value) => setNewFollow({ ...newFollow, followerName: value })}
                            placeholder="请选择跟进人"
                            emptyText="未找到匹配的人员"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="followTime">跟进时间</Label>
                          <Input
                            id="followTime"
                            type="datetime-local"
                            value={newFollow.followTime}
                            onChange={(e) => setNewFollow({ ...newFollow, followTime: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="followType">跟进类型</Label>
                          <SearchableSelect
                            options={serviceTypes.filter(type => type && type.serviceCode && type.serviceName).map(type => ({
                              value: type.serviceCode,
                              label: type.serviceName
                            }))}
                            value={newFollow.followType}
                            onValueChange={(value) => setNewFollow({ ...newFollow, followType: value })}
                            placeholder="请选择跟进类型"
                            emptyText="未找到匹配的类型"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="project">关联项目</Label>
                          <SearchableSelect
                            options={[
                              { value: 'none', label: '无关联项目' },
                              ...projects.filter(project => project && project.id && project.projectName).map(project => ({
                                value: project.id.toString(),
                                label: project.projectName
                              }))
                            ]}
                            value={newFollow.projectId}
                            onValueChange={(value) => setNewFollow({ ...newFollow, projectId: value })}
                            placeholder="请选择关联项目（可选）"
                            emptyText="未找到匹配的项目"
                          />
                        </div>
                      </div>
                      {/* 是否出差 */}
                      <div className="flex items-center space-x-2 py-2">
                        <input
                          type="checkbox"
                          id="isBusinessTrip"
                          checked={newFollow.isBusinessTrip}
                          onChange={(e) => setNewFollow({ ...newFollow, isBusinessTrip: e.target.checked })}
                          className="h-4 w-4 rounded border-gray-300"
                        />
                        <Label htmlFor="isBusinessTrip" className="text-sm font-normal cursor-pointer">
                          是否出差
                        </Label>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="followContent">跟进内容</Label>
                        <Textarea
                          id="followContent"
                          placeholder="请输入跟进内容..."
                          value={newFollow.followContent}
                          onChange={(e) => setNewFollow({ ...newFollow, followContent: e.target.value })}
                          rows={4}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="attachment" className="flex items-center gap-2">
                          佐证物
                          <span className="text-xs text-muted-foreground font-normal">(最大100MB，支持分片上传)</span>
                        </Label>
                        <div className="border-2 border-dashed rounded-lg p-6">
                          {/* 上传进度显示 */}
                          {attachmentUploading ? (
                            <div className="space-y-2">
                              <div className="flex items-center gap-2">
                                <FileIcon className="h-4 w-4" />
                                <span className="text-sm">{newFollow.attachment?.name}</span>
                              </div>
                              <div className="w-full bg-muted rounded-full h-2">
                                <div 
                                  className="bg-primary h-2 rounded-full transition-all duration-300"
                                  style={{ width: `${attachmentUploadProgress}%` }}
                                />
                              </div>
                              <p className="text-xs text-muted-foreground text-center">
                                上传中... {attachmentUploadProgress.toFixed(0)}%
                              </p>
                            </div>
                          ) : uploadedAttachment ? (
                            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                              <div className="flex items-center gap-2">
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                                <span className="text-sm">{uploadedAttachment.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  ({(uploadedAttachment.size / 1024 / 1024).toFixed(2)} MB)
                                </span>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setUploadedAttachment(null);
                                  setNewFollow({ ...newFollow, attachment: null });
                                }}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : newFollow.attachment ? (
                            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                              <div className="flex items-center gap-2">
                                <FileIcon className="h-4 w-4" />
                                <span className="text-sm">{newFollow.attachment.name}</span>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setNewFollow({ ...newFollow, attachment: null })}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <div className="text-center">
                              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                              <p className="text-sm text-muted-foreground mb-2">
                                点击或拖拽文件到此处上传
                              </p>
                              <Input
                                id="attachment"
                                type="file"
                                className="hidden"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    // 检查文件大小
                                    const maxSize = 100 * 1024 * 1024; // 100MB
                                    if (file.size > maxSize) {
                                      toast({
                                        variant: 'destructive',
                                        title: '文件过大',
                                        description: '佐证物文件大小不能超过100MB',
                                      });
                                      return;
                                    }
                                    // 大于10MB使用分片上传
                                    const chunkThreshold = 10 * 1024 * 1024;
                                    if (file.size > chunkThreshold) {
                                      setNewFollow({ ...newFollow, attachment: file });
                                      doChunkUpload(file);
                                    } else {
                                      // 小文件直接设置，在提交时上传
                                      setNewFollow({ ...newFollow, attachment: file });
                                    }
                                  }
                                }}
                              />
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => document.getElementById('attachment')?.click()}
                              >
                                选择文件
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setAddFollowDialogOpen(false)}
                      >
                        取消
                      </Button>
                      <Button
                        onClick={handleAddFollow}
                        disabled={submittingFollow}
                      >
                        {submittingFollow ? '提交中...' : '提交'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {/* 筛选器 */}
              <div className="mb-6 p-4 rounded-lg bg-muted/30">
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">跟进人员</Label>
                    <Select value={filterStaff} onValueChange={setFilterStaff}>
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="全部人员" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部人员</SelectItem>
                        {allStaff.filter(Boolean).map(staff => (
                          <SelectItem key={staff} value={staff}>{staff}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">跟进类型</Label>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="全部类型" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部类型</SelectItem>
                        {allTypes.filter(Boolean).map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">年份</Label>
                    <Select value={filterYear} onValueChange={setFilterYear}>
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="全部年份" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部年份</SelectItem>
                        {allYears.filter(Boolean).map(year => (
                          <SelectItem key={year} value={year.toString()}>{year}年</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">关联项目</Label>
                    <Select value={filterProject} onValueChange={setFilterProject}>
                      <SelectTrigger className="h-8">
                        <SelectValue placeholder="全部项目" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部项目</SelectItem>
                        <SelectItem value="has">有关联项目</SelectItem>
                        <SelectItem value="none">无关联项目</SelectItem>
                        {projects.filter(project => project && project.id && project.projectName).map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.projectName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                {(filterStaff !== 'all' || filterType !== 'all' || filterYear !== 'all' || filterMonth !== 'all' || filterProject !== 'all') && (
                  <div className="mt-3 pt-3 border-t flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      筛选结果：{filteredFollowRecords.length} 条记录
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={resetFilters}
                      className="h-8 text-xs"
                    >
                      重置筛选
                    </Button>
                  </div>
                )}
              </div>

              {/* 时间轴内容 */}
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-muted" />

                {filteredFollowRecords.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    暂无跟进记录{followRecords.length > 0 ? '，或尝试调整筛选条件' : '，点击右上角"添加跟进"按钮添加'}
                  </div>
                ) : (
                  <>
                    {filteredFollowRecords.slice(0, displayCount).map((record, index) => {
                    const isExpanded = expandedRecords.has(record.id);
                    return (
                      <div key={record.id} className="relative pl-12 pb-8 last:pb-0">
                        <div className="absolute left-2 top-3 w-4 h-4 rounded-full bg-primary border-4 border-background cursor-pointer hover:scale-110 transition-transform" />
                        <div className="space-y-2">
                          {/* 简要信息（始终显示） */}
                          <div
                            className="flex items-center justify-between cursor-pointer hover:bg-muted/50 p-2 rounded-lg transition-colors"
                            onClick={() => toggleExpand(record.id)}
                          >
                            <div className="flex items-center gap-3">
                              <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                                <span className="text-xs font-medium">{record.followerName?.charAt(0) || '?'}</span>
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium text-sm truncate">{record.followerName}</span>
                                  <Badge variant="outline" className="text-xs flex-shrink-0">{record.followType}</Badge>
                                </div>
                                <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                                  <Clock className="h-3 w-3" />
                                  {formatDateTime(record.followTime)}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {record.projectName && record.projectName !== '无关联项目' && (
                                <Badge variant="secondary" className="text-xs">{record.projectName}</Badge>
                              )}
                              {isExpanded ? (
                                <ChevronDown className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <ChevronRight className="h-4 w-4 text-muted-foreground" />
                              )}
                            </div>
                          </div>

                          {/* 详细信息（展开时显示） */}
                          {isExpanded && (
                            <div className="mt-2 space-y-3 p-4 bg-muted/30 rounded-lg">
                              <div className="flex items-start gap-3">
                                <div className="flex-1">
                                  <Label className="text-xs text-muted-foreground">跟进内容</Label>
                                  <p className="text-sm mt-1 whitespace-pre-wrap line-clamp-6 max-h-40 overflow-hidden" title={record.followContent}>{record.followContent}</p>
                                </div>
                              </div>
                              {record.attachmentUrl && (
                                <div className="pt-2 border-t">
                                  <Label className="text-xs text-muted-foreground">佐证物</Label>
                                  <div className="flex items-center gap-2 mt-1">
                                    <Button variant="outline" size="sm" className="h-8">
                                      <FileIcon className="h-3 w-3 mr-2" />
                                      {record.attachmentName || '查看附件'}
                                    </Button>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                    
                    {/* 加载更多按钮 */}
                    {filteredFollowRecords.length > displayCount && (
                      <div className="relative pl-12 pt-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={loadMoreRecords}
                          className="w-full"
                        >
                          加载更多 ({filteredFollowRecords.length - displayCount} 条未显示)
                        </Button>
                      </div>
                    )}
                    
                    {/* 显示记录统计 */}
                    {filteredFollowRecords.length > 0 && (
                      <div className="relative pl-12 pt-4 text-center text-xs text-muted-foreground">
                        已显示 {Math.min(displayCount, filteredFollowRecords.length)} / {filteredFollowRecords.length} 条记录
                      </div>
                    )}
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧快速操作区域 */}
        <div className="space-y-6">
          {/* 快速操作 */}
          <Card>
            <CardHeader>
              <CardTitle>快速操作</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={handleEditCustomer}
                disabled={isEditing}
              >
                <Edit3 className="mr-2 h-4 w-4" />
                {isEditing ? '编辑中...' : '编辑客户信息'}
              </Button>
            </CardContent>
          </Card>

          {/* 客户状态评价 */}
          <Card>
            <CardHeader>
              <CardTitle>客户状态评价</CardTitle>
              <CardDescription>AI 驱动的智能分析</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-blue-50 border">
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-white shadow-sm">
                      <Sparkles className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-sm mb-2">AI 分析结果</div>
                      <p className="text-sm text-muted-foreground">
                        {statusEvaluation}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="p-4 rounded-lg bg-muted/50 border border-dashed">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Sparkles className="h-4 w-4" />
                    <span>AI 功能建设中</span>
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">
                    未来将支持智能推荐、风险预测、客户画像等功能
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 历史项目列表 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                关联项目
              </CardTitle>
              <CardDescription>
                {projectsTotal > 0 ? `共 ${projectsTotal} 个项目` : '暂无关联项目'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {projectsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="text-muted-foreground">加载中...</div>
                </div>
              ) : projects.length > 0 ? (
                <>
                  <div className="space-y-3">
                    {projects.filter(project => project && project.id).map((project) => (
                      <div 
                        key={project.id} 
                        className="p-3 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors"
                        onClick={() => router.push(`/projects/${project.id}`)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="font-medium text-sm">{project.projectName}</div>
                            <div className="text-xs text-muted-foreground mt-1">{project.projectCode}</div>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                <DollarSign className="h-3 w-3 mr-1" />
                                {formatCurrency(project.estimatedAmount)}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {formatDate(project.startDate)}
                              </Badge>
                            </div>
                          </div>
                          <Badge 
                            variant={project.status === 'completed' ? 'default' : 'secondary'}
                            className="text-xs"
                          >
                            {project.status === 'completed' ? '已完成' : 
                             project.status === 'in_progress' ? '进行中' : 
                             project.status === 'draft' ? '草稿' :
                             project.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* 分页控制 */}
                  {projectsTotal > PROJECTS_PAGE_SIZE && (
                    <div className="flex items-center justify-between mt-4 pt-4 border-t">
                      <div className="text-sm text-muted-foreground">
                        第 {(projectsPage - 1) * PROJECTS_PAGE_SIZE + 1}-{Math.min(projectsPage * PROJECTS_PAGE_SIZE, projectsTotal)} 项，共 {projectsTotal} 项
                      </div>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          disabled={projectsPage === 1}
                          onClick={() => fetchProjects(projectsPage - 1)}
                        >
                          上一页
                        </Button>
                        <div className="text-sm">
                          第 {projectsPage} / {Math.ceil(projectsTotal / PROJECTS_PAGE_SIZE)} 页
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          disabled={projectsPage >= Math.ceil(projectsTotal / PROJECTS_PAGE_SIZE)}
                          onClick={() => fetchProjects(projectsPage + 1)}
                        >
                          下一页
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {/* 跳转到项目管理 */}
                  <div className="mt-3 pt-3 border-t text-center">
                    <Button 
                      variant="link" 
                      size="sm" 
                      className="text-muted-foreground"
                      onClick={() => router.push(`/projects?customerId=${customer?.id}`)}
                    >
                      在项目管理中查看全部项目
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Building2 className="h-12 w-12 text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">暂无关联项目</p>
                  <p className="text-sm text-muted-foreground mt-1">可在项目管理模块中创建新项目</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 确认修改对话框 */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认修改</DialogTitle>
            <DialogDescription>
              确定要修改客户信息吗？修改后将更新客户资料。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
            >
              取消
            </Button>
            <Button
              onClick={handleConfirmSave}
              disabled={savingCustomer}
            >
              {savingCustomer ? '保存中...' : '确定'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
