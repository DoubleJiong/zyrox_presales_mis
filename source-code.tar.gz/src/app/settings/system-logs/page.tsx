'use client';

import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Download, RefreshCw, AlertCircle, Info, CheckCircle, XCircle } from 'lucide-react';

interface SystemLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  details: string;
  ip: string;
  status: 'success' | 'error' | 'warning';
  createdAt: string;
}

export default function SystemLogsSettings() {
  const { toast } = useToast();
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [moduleFilter, setModuleFilter] = useState<string>('all');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  // 模拟数据
  const mockLogs: SystemLog[] = [
    {
      id: '1',
      userId: '1',
      userName: '张三',
      action: '新增客户',
      module: '客户管理',
      details: '新增客户：某大学',
      ip: '192.168.1.100',
      status: 'success',
      createdAt: '2025-01-10 14:30:25',
    },
    {
      id: '2',
      userId: '2',
      userName: '李四',
      action: '修改项目',
      module: '项目管理',
      details: '修改项目状态：进行中',
      ip: '192.168.1.101',
      status: 'success',
      createdAt: '2025-01-10 14:28:15',
    },
    {
      id: '3',
      userId: '1',
      userName: '张三',
      action: '删除解决方案',
      module: '解决方案管理',
      details: '删除解决方案：教育信息化方案',
      ip: '192.168.1.100',
      status: 'warning',
      createdAt: '2025-01-10 14:25:00',
    },
    {
      id: '4',
      userId: '3',
      userName: '王五',
      action: '登录失败',
      module: '系统',
      details: '用户登录失败：密码错误',
      ip: '192.168.1.102',
      status: 'error',
      createdAt: '2025-01-10 14:20:00',
    },
    {
      id: '5',
      userId: '2',
      userName: '李四',
      action: '新增项目',
      module: '项目管理',
      details: '新增项目：智慧校园项目',
      ip: '192.168.1.101',
      status: 'success',
      createdAt: '2025-01-10 14:15:30',
    },
    {
      id: '6',
      userId: '1',
      userName: '张三',
      action: '导出数据',
      module: '报表管理',
      details: '导出客户统计数据',
      ip: '192.168.1.100',
      status: 'success',
      createdAt: '2025-01-10 14:10:00',
    },
    {
      id: '7',
      userId: '4',
      userName: '赵六',
      action: '修改权限',
      module: '权限管理',
      details: '修改用户角色：李四',
      ip: '192.168.1.103',
      status: 'success',
      createdAt: '2025-01-10 14:05:00',
    },
    {
      id: '8',
      userId: '3',
      userName: '王五',
      action: '登录成功',
      module: '系统',
      details: '用户登录成功',
      ip: '192.168.1.102',
      status: 'success',
      createdAt: '2025-01-10 14:00:00',
    },
    {
      id: '9',
      userId: '5',
      userName: '钱七',
      action: '新增分子公司',
      module: '系统管理',
      details: '新增分子公司：江苏分公司',
      ip: '192.168.1.104',
      status: 'success',
      createdAt: '2025-01-10 13:55:00',
    },
    {
      id: '10',
      userId: '1',
      userName: '张三',
      action: '删除客户',
      module: '客户管理',
      details: '删除客户：某公司',
      ip: '192.168.1.100',
      status: 'warning',
      createdAt: '2025-01-10 13:50:00',
    },
  ];

  useEffect(() => {
    loadLogs();
  }, []);

  useEffect(() => {
    filterLogs();
  }, [logs, searchTerm, statusFilter, moduleFilter]);

  const loadLogs = () => {
    setLoading(true);
    setTimeout(() => {
      setLogs(mockLogs);
      setLoading(false);
    }, 500);
  };

  const filterLogs = () => {
    let filtered = logs;

    if (searchTerm) {
      filtered = filtered.filter(
        (log) =>
          (log.userName?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
          (log.action?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
          (log.module?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
          (log.details?.toLowerCase() || '').includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter((log) => log.status === statusFilter);
    }

    if (moduleFilter !== 'all') {
      filtered = filtered.filter((log) => log.module === moduleFilter);
    }

    setFilteredLogs(filtered);
  };

  const handleExport = () => {
    // 模拟导出
    toast({
      title: '开始导出',
      description: '导出系统日志数据...',
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      default:
        return <Info className="h-4 w-4 text-blue-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge variant="default" className="bg-green-500">成功</Badge>;
      case 'error':
        return <Badge variant="destructive">失败</Badge>;
      case 'warning':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-500">警告</Badge>;
      default:
        return <Badge variant="secondary">信息</Badge>;
    }
  };

  const modules = Array.from(new Set(logs.map((log) => log.module)));

  const paginatedLogs = filteredLogs.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.ceil(filteredLogs.length / pageSize);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>系统日志</CardTitle>
            <CardDescription>查看系统操作日志和审计记录</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={loadLogs} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              刷新
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              导出
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Filters */}
        <div className="flex gap-4 mb-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索日志..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="success">成功</SelectItem>
              <SelectItem value="error">失败</SelectItem>
              <SelectItem value="warning">警告</SelectItem>
            </SelectContent>
          </Select>
          <Select value={moduleFilter} onValueChange={setModuleFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="模块" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部模块</SelectItem>
              {modules.map((module) => (
                <SelectItem key={module} value={module}>
                  {module}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Logs Table */}
        <ScrollArea className="h-[500px] rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">状态</TableHead>
                <TableHead className="w-[100px]">时间</TableHead>
                <TableHead className="w-[100px]">用户</TableHead>
                <TableHead className="w-[100px]">模块</TableHead>
                <TableHead>操作</TableHead>
                <TableHead>详情</TableHead>
                <TableHead className="w-[130px]">IP地址</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div className="flex items-center justify-center gap-2">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      <span>加载中...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : paginatedLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    暂无日志记录
                  </TableCell>
                </TableRow>
              ) : (
                paginatedLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(log.status)}
                        {getStatusBadge(log.status)}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{log.createdAt}</TableCell>
                    <TableCell className="text-sm">{log.userName}</TableCell>
                    <TableCell className="text-sm">{log.module}</TableCell>
                    <TableCell className="font-medium">{log.action}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{log.details}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{log.ip}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </ScrollArea>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground">
              共 {filteredLogs.length} 条记录，第 {page} / {totalPages} 页
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
              >
                上一页
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
